// Var
// String
var name = "Prasad"; 
// Number
var age = 24;
// Boolean
var canFly = false;
// Array
var languages = ['Hindi','English','Marathi'];
// Objects
var friends = {
    name:"Vishal",
    hobby:"Coding",
}

var a = 10;
console.log(a);

var a = null;
console.log(a);

// Let 
{
   let city;
   let name = "Sai Sir"; 
   name = "Viral Sir";
   console.log("Using Let: ", name);
}
console.log(name)

// const - Constant

const country = "India";
console.log(country);

// country = "UK";

const _fruits = ["mango", "apple"]
console.log(_fruits)
_fruits.push('banana');
console.log(_fruits)


/* Naming a variable
1. variable name cannot start with a number
2. It can start with letters, $, _.

3. $ is mainly used in JQuery

4. _  is used to declare private variables [OOPS in Javscript]
*/

/*
1. camelCase ************
2. kebab-case
3. snake_case
4. PascalCase
*/