console.log("Learning datatypes");

/*
Primitive
1. Number  
2. String
3. Boolean
4. Bigint
5. null 
6. undefined

Reference
1. Array  
2. Functions   
3. Objects  

*/

// Number

let num = 25;
console.log(num);

let num1 = 123.854;
// num1 = Number(num1);
// console.log(num1, typeof num1)
// console.log(Number(true));
// console.log(Number(false));

// console.log(parseFloat(num1));
// console.log(num1.toFixed(2));

// let strn = 500;
// console.log(typeof strn);
// console.log(typeof(strn));

// console.log(Number('123d457g'))

// String
// let str = "Prasad";
// console.log(typeof str);
// let str = 'LetsUpgrade';
// let str = `LetsUpgrade`;
// console.log(str);

// let numstr = 123;
// numstr = String(numstr)
// console.log(typeof(numstr))




// Boolean

// let canDrive = false;
// console.log(typeof canDrive);
// console.log(canDrive);



// Bigint
// let numb = 1235485n;
// console.log(typeof numb);
// console.log(numb);

// null
// let nullvar = null;
// console.log(typeof nullvar);
// console.log(nullvar);

// undefined
// let a;
// let a = undefined;
// console.log(typeof a);
// console.log(a)
