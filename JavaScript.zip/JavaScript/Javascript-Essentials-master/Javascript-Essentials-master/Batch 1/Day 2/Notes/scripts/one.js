// console.log("Hello")

// These all are modals. Modals are those popups, which dont allow you to interact with other part of the webpage unless you have interacted with the modal popup.

// Alert
// alert("hey I am an alert");

// Prompt
// syntax: prompt("title", "default value"[optional])
// let age = prompt("What is your age");
// console.log(age);

// Confirm
// return values : 
// OK -> true
// Cancel -> false
// let age = confirm("Are you over 18?");
// console.log(age)
