// function declaration

// function add(num1, num2) {
//   let result = num1 + num2;
//   return result;
// }

// let res = add(30);
// console.log(res);

// function expression
// const add = function (num1, num2) {
//   let result = num1 + num2;
//   console.log(result);
// };

// normal function

function doSomething(name) {
  console.log("hello " + name);
}

// arrow function
doSomething = (name) => {
  console.log("hello " + name);
};

doSomething("saurabh");
