function showPassword() {
  const eles = document.getElementsByClassName("input");
  eles[1].type = "text";
}

function hidePassword() {
  const eles = document.getElementsByClassName("input");
  eles[1].type = "password";
}
