// 1) Program to search for a parti	cular character in a string- Code1

// var inputString = "Home sweet home";
// var findme = "X";

// if ( inputString.indexOf(findme) > -1 ) {
//     console.log( "found it" );
// } else {
//     console.log( "not found" );
// }

// Code 2
// var inputString = "Home sweet home";
// var n = inputString.charAt('12');
// console.log(n);

// 2) Program to convert minutes to seconds

// let num = 3;
// let sec = Math.floor(num * 60);
// console.log(num + " Minutes is converted into " + sec + " Seconds");

// 3) Program to search for a element in a array of strings
  
// // let input = prompt("enter size");
// let a=new Array();
// // let find ="C++"
// // let output = input.indexOf(find);
// // //let output = input.includes("Apple"); 
// // console.log(input[output]);

// 4) Program to display only elements containing 'a' in them from a array
// let x=prompt("enter size");
// let a=new Array();
// for(var i=0;i<x;i++)
// {
// 	a[i]=prompt("enter the string");
// }
// for(i=0;i<x;i++)
// {
   
//    for(var j=0;j<(a[i].length);j++)
//    {
//       if(a[i][j]=='a')
// 	    {
// 	      console.log(a[i]);
// 		  break;
// 		} 
//    }

// }




// 5) reverse the array
    // let array1 = ["English", "no", "maybe", "always", "sometimes", "French", "if"];
    //  for (let i = array1.length - 1 ; i >= 0; i--) {
    //      console.log(array1[i])
    //  }
    
   // Method 2:
//    let array1 = ["English", "no", "maybe", "always", "sometimes", "French", "if"];
//    console.log(array1.reverse())