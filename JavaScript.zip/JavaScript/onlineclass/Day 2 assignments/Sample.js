// 1) Program to search for a particular character in a string- Code1

let x;
let p=0
x = prompt("enter a string:");
let y;
 y =prompt("enter a char need tobe search");
	   
       for(var i=0;i<(x.length);i++)
	   {
		   if(y==x[i])
		   {
		       p=p+1;
			   console.log("position is at"+i+"");
		   }
	   }		  
       if(p==0)
	       console.log("NOT FOUND");
 
       		  
       
    

// if ( inputString.indexOf(findme) > -1 ) {
//     console.log( "found it" );
// } else {
//     console.log( "not found" );
// }



// 2) Program to convert minutes to seconds

// let num = prompt("enter the minutes");
// let sec = Math.floor(num * 60);
// console.log(num + " Minutes is converted into " + sec + " Seconds");

// 3) Program to search for a element in a array of strings
  
// let input = prompt("enter size");
// let a = new Array();
// for(let i = 0; i<=input; i++){
//      a[i] = prompt("enter the string");
// }
// let finder = prompt("enter the data need to be search:");
// let output = input.indexOf(finder);
// if(output==-1)
// {
//     console.log(finder+ " data is not present")
// }
// else{
//     console.log("data is present " +output);
// }
// 4) Program to display only elements containing 'a' in them from a array
// let input=prompt("enter size");
// let a=new Array();
// for(var i=0;i<x;i++)
// {
// 	a[i]=prompt("enter the strings into array");
// }
// for(i=0;i<=input;i++)
// {
   
//    for(var j=0;j<(a[i].length);j++)
//    {
//       if(a[i][j]=='a')
// 	    {
// 	      console.log(a[i]);
// 		  break;
// 		} 
//    }

// }




// 5) reverse the array
// let x=prompt("enter size of the array");
// let a=new Array();
// for(var i=0;i<x;i++)
// {
// 	a[i]=prompt("enter the data need to reverse");
// }
// let b=new Array();
// b=a.reverse();
// for( i=0;i<x;i++)
// {
// 	console.log(b[i]);
// }

    