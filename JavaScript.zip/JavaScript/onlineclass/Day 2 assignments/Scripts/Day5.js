let superheroin=[
    {
        name:"Alya",
        age: 24,
        Planet: "Indisnndbhha",
        height: "6.4",
      },
      {
        name:"Alyaty",
        age: 2200,
        Planet: "Ipiundisnndbhha",
        height: "5,6",
      },
      {
        name:"Alyanmasnas",
        age: 2400,
        Planet: "snndbhha",
        height: "6.7",
      },
      {
        name:"Alyaprasde",
        age: 34,
        Planet: "yujml",
        height: "6.9",
      },
];

// we are creating dyanmic table in js
// superheroes- is the variable in function
function display(){
    let tableData="";
    let srno="1";

    superheroin.forEach(function(superheroes){ 
        let currentrow=`<tr>
        <td>${srno}</td>
        <td>${superheroes.name}</td>
        <td>${superheroes.age}</td>
        <td>${superheroes.Planet}</td>
        <td>${superheroes.height}</td>
        </tr>`
        tableData += currentrow; // if tableData += currentrow;- + is not there it will override the data. If we ahve +, will have current data + new data
        srno++;
    });
// By default class name will be array
// InnerHTML will manuplicate the data
    document.getElementsByClassName("tdata")[0].innerHTML=tableData;
    //innerText- Will give the data like text ..<tr>....</tr>
    //innerHTML- will give output as Tbale format
}
function addSuperhero(e){
    e.preventDefault(); // Stop the default function of submit action
    let hero ={};// balnk object
    let name = document.getElementById("12").value;
    let age = document.getElementById("13").value;
    let planet = document.getElementById("14").value;
    let height = document.getElementById("15").value;
    // hero.name = name;
    // hero.age = Number(age); // age is  converted tonumber
    // hero.planet = planet;
    // hero.height = Number(height);
    //  superheroin.push(superhero);
    

    console.log(hero);
    

}
display();