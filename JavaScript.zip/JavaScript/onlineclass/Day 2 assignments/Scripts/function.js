
// function add()
// {
// let a = 10;
// let b = 5;
// let c = a + b;
// console.log(c);
// }
//  add();
// function declaration
// function add(num1, num2)
// {
// let c = num1 + num2;
// console.log(c);
// }
//  add(10, 56);
//  add(10,20);

// function add(num1, num2)
// {
// let c = num1 + num2;
// console.log(c);
// }
// method 2 - function expression

// const addition = function (num1, num2)//pass by argument
// {
//     let c = num1 + num2;
// console.log(c);
// }
//  addition(10, 56);
// return the calue from function
// function add(num1, num2)
// {
// let c = num1 + num2;
// //console.log(c);
// return c;
// }
// let res= add(10,20);
// console.log(res);

// function add(num1, num2=10) // pass by value
// {
// let c = num1 + num2;
// //console.log(c);
// return c;
// }
// let res= add(10);
// console.log(res);
 
//normal function
//  function doSomething(name)
// {
//     console.log("helo " +name);
// }

// doSomething();
// doSomething("deepo");

// arrow function
// doSomething =() =>{
//     console.log("jekko");  // if it is singleline no need {}
// }

// doSomething("deepo");
doSomething =(name) => console.log("jekko "+name);  // if it is singleline no need {}  // array functions
doSomething("deepo");




















