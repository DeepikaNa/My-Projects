// 2) Program to convert minutes to seconds

let num = prompt("enter the minutes");
let sec = Math.floor(num * 60);
console.log(num + " Minutes is converted into " + sec + " Seconds");