<?php
//ini_set('display_errors', 'on');
ini_set('max_execution_time', 0);
require_once 'JSLikeHTMLElement.php';
//error_reporting(0);

//echo $_POST['access-type'];exit;

//update front matter in XSL - START
$xslContent = file_get_contents('bmjHTML2XML_test.xsl'); //original xsl
$dom = new DOMDocument();
$dom->loadXML($xslContent);
$XPath = new DOMXPath($dom);
$updateNodes = $XPath->query('//journal-meta//*');
foreach($updateNodes as $updateNode){
	if(isset($_POST[$updateNode->nodeValue])){
		$updateNode->nodeValue = $_POST[$updateNode->nodeValue];
	}
}
$updateNodesa = $XPath->query('//issue-title');
foreach($updateNodesa as $updateNode){
	if(isset($_POST[$updateNode->nodeValue])){
		$updateNode->nodeValue = $_POST[$updateNode->nodeValue];
	}
}

$updateNodesa = $XPath->query('//pub-date/month');
foreach($updateNodesa as $updateNode){
	if(isset($_POST[$updateNode->nodeValue])){
		$updateNode->nodeValue = $_POST[$updateNode->nodeValue];
	}
}


//updated by Deepika N

if($_POST['access-type']=='on'){
	$updateNodesa = $XPath->query('//custom-meta-group');
}
else{
	$accesstypes = $XPath->query('//custom-meta-group//custom-meta[meta-name[contains(.,"access-type")]]');
	foreach($accesstypes as $accesstype){
			$accesstype->parentNode->removeChild($accesstype);
	}
}
	//DOMRemove($accesstype);
	//$accesstype->parentNode->removeChild($accesstype);
/*
if(isset($_POST["access-type"]) && $_POST["FreeAccess"] == "true"){
		$updateNodesa = $XPath->query('//custom-meta-group');	
	}
else{ 
	$updateNodesa = $var->NULL;
}

*/
file_put_contents('updatedXSL.xsl', $dom->saveXML());

//save uploaded file
$uploadedFileName = $_FILES["fileName"]["name"]; //given file name
#$uploadedFileName = "Input.xml";#From_3b2_SGML.xml
$tempFileName = preg_replace('/\.xml$/','_output.xml', $uploadedFileName);
$downloadFileName = preg_replace('/\.xml$/','_final.xml', $uploadedFileName);
move_uploaded_file($_FILES["fileName"]["tmp_name"], $uploadedFileName);
move_uploaded_file($_FILES["logFileName"]["tmp_name"], 'logPageNumber.xml');

// set the stream to utf based
$opts = array(
  'http'=>array(
	'method'=>"GET",
	'header'=>"Accept-language: en\r\n" .
			  "Cookie: foo=bar\r\n" .
			  "Content-Type: text/html; charset=UTF-8"
  )
);
$context = stream_context_create($opts);
echo file_get_contents( 'logPageNumber.xml', false, $context);
die;
$logDoc = new DOMDocument();
$logDoc->loadHTML(file_get_contents( 'logPageNumber.xml', false, $context));
//$logDoc->loadHTMLFile(file_get_contents( 'logPageNumber.xml', false, $context));
$logXPath = new DOMXPath($logDoc);

	$url = $uploadedFileName;
	// read file contents
    $urlContent = file_get_contents($url, false, $context);
    $urlContent = str_replace(' lastClicked', '', $urlContent);
    $urlContent = preg_replace('/\n|\r/', '', $urlContent);
    $urlContent = preg_replace('/\s{2,}/', ' ', $urlContent);
//<RefJournalTitle class="RefJournalTitle">Clin Pharmacol Ther</RefJournalTitle> <RefYear class="
    $urlContent = str_replace('<RefJournalTitle class="RefJournalTitle">', '<italic>', $urlContent);
    $urlContent = str_replace('</RefJournalTitle>', '</italic>', $urlContent);
	$urlContent = str_replace('<RefYear class="RefYear">', ' ', $urlContent);
	$urlContent = str_replace('</RefYear>', '', $urlContent);
	//$urlContent = str_replace('</RefSlNo>.', '</RefSlNo>', $urlContent);
	//$urlContent = str_replace('<RefSlNo class="RefSlNo">', '<RefSlNo class="RefSlNo">', $urlContent);
	
#<RefYear class="RefYear">
    $urlContent = str_replace('&nbsp;', ' ', $urlContent);
    $urlContent = str_replace('&#x00A0;', ' ', $urlContent);
    $urlContent = str_replace('&#12289;', ', ', $urlContent);
    $urlContent = str_replace('&#65288;', ' (', $urlContent);
    $urlContent = str_replace('&#65288;', ') ', $urlContent);
    $urlContent = mb_convert_encoding($urlContent, 'HTML-ENTITIES', "UTF-8");
    // Create DOM from URL
    $doc = new DOMDocument();
    // the below line is required to get the innerHTML method working
    $doc->registerNodeClass('DOMElement', 'JSLikeHTMLElement');
    $doc->loadHTML($urlContent);
    //$doc->loadHTMLFile($urlContent);
    $XPath = new DOMXPath($doc);
    $XPath->registerNamespace('php', 'http://php.net/xpath');
    $XPath->registerPhpFunctions(array('preg_match', 'preg_split', 'preg_replace', 'sizeof', 'str_word_count'));
    
	/*
	//path script for reversing bmj node name to its class name
	$taggingArray = array('AbsSession'=>'h1,AbsSession','AbsRefHead'=>'h3','AbsRefHead','RefSlNo'=>'span','RefSlNo','RefAuthor'=>'span,RefAuthor','RefVolume'=>'span,RefVolume','RefIssue'=>'span,RefIssue','RefFPage'=>'span,RefFPage','RefLPage'=>'span,RefLPage','smallCaps'=>'span,smallCaps','RefPrefix'=>'span,RefPrefix','AbsTitle'=>'h2,AbsTitle','label'=>'span,label','body'=>'div,body','AbsKeywordPara'=>'p,AbsKeywordPara','AbsHead'=>'h3,AbsHead','AbsKeywordHead'=>'h3,AbsKeywordHead','AbsEmail'=>'span,AbsEmail','AbsFax'=>'span,AbsFax','AbsTelephone'=>'span,AbsTelephone','AbsCountry'=>'span,AbsCountry','RefSource'=>'span,RefSource','AbsAddrLine'=>'span,AbsAddrLine','AbsSubj'=>'h1,AbsSubj','Comments'=>'span,Comments','AbsAuthors'=>'p,AbsAuthors','RefYear'=>'span,RefYear','RefArticleTitle'=>'span,RefArticleTitle','RefJournalTitle'=>'span,RefJournalTitle','AbsRefText'=>'p,AbsRefText','AbsAuthor'=>'span,AbsAuthor','AbsAffRef'=>'span,AbsAffRef','AbsNumber'=>'span,AbsNumber','AbsGivenName'=>'span,AbsGivenName','AbsSurName'=>'span,AbsSurName','AbsTblFoot'=>'p,AbsTblFoot','AbsAff'=>'p,AbsAff','AbsCorrAff'=>'p,AbsCorrAff','disp-quote'=>'p,AbsEpiGraph','jrnlTblBlock'=>'div,jrnlTblBlock','TblCaption'=>'p,AbsTblCaption','jrnlFigBlock'=>'div,jrnlFigBlock','FigCaption'=>'p,AbsFigCaption');
	//remove all keys to lowercase
	foreach(array_keys($taggingArray) as $key){
		$value = $taggingArray[$key];
		$taggingArray[strtolower($key)] = $value;
		unset($taggingArray[$key]);
	}
	$nodes = $XPath->query('//*');
	foreach($nodes as $node){
		$nodeName = $node->nodeName;
		if( isset($taggingArray[$nodeName]) ){
			$tagging = explode( ',', $taggingArray[$nodeName] );
			$tagName = $tagging[0];
			$className = $tagging[1];
			$newNode = $doc->createElement($tagName);
			$newNode->setAttribute('class', $className);
			$node->parentNode->insertBefore($newNode, $node);
			$newNode->innerHTML = $node->innerHTML;
			$node->parentNode->removeChild($node);
		}
	}
	$nodes = $XPath->query('//abstract');
	foreach($nodes as $node){
		$tagName = 'div';
		$newNode = $doc->createElement($tagName);
		$newNode->setAttribute('type', 'content');
		$node->parentNode->insertBefore($newNode, $node);
		$newNode->innerHTML = $node->innerHTML;
		$node->parentNode->removeChild($node);
	}
	
	
	file_put_contents('test.xml', $doc->saveHTML());
	exit;
	*/
	
    
    $childNodes = $XPath->query('//span[contains(@class, "commentNode")]');
    foreach($childNodes as $childNode){
    	DOMRemove($childNode);
    }
    
    // unwrap the insertion nodes, i.e., remove the span tag but retain children
    $childNodes = $XPath->query('//span[contains(@title, "Inserted by ")]|//span[contains(@class, "ins ")]|//span[contains(@class, "hiddenSpellError")]|//span[contains(@class, "hiddenSuggestion")]|//span[contains(@class, "hiddenGrammarError")]|//span[@data-mce-type="bookmark"]');
    foreach($childNodes as $childNode){
    	DOMRemove($childNode);
    }
    
    // remove the deletion nodes and unwrap the insertions
    $childNodes = $XPath->query('//span[contains(@class, "del ")]|//span[contains(@title, "Deleted by ")]');
    foreach($childNodes as $childNode){
    	$childNode->parentNode->removeChild($childNode);
    }
    
    $childNodes = $XPath->query('//div[@id="queryDivNode_xxx"]|//div[@id="commentDivNode"]|//span[@data-mce-type="bookmark"]');
    foreach($childNodes as $childNode){
    	$childNode->parentNode->removeChild($childNode);
    }
    
    $unwantedDivs = $XPath->query('//*[contains(@node-type,"ancestor")]|//*[contains(@type,"proofs")]|//*[contains(@id,"mceResizeHandle")]|//*[contains(@id,"commentDivNode")]|//*[contains(@class,"del")][@data-time][@data-username]|//*[@id="referenceEditPanel"]|//script');
    foreach ($unwantedDivs as $unwantedDiv) {
    	$unwantedDiv->parentNode->removeChild($unwantedDiv);
    }
    
    
    
    $absTitles = $XPath->query('//abssession');
    foreach ($absTitles as $absTitle){
		$absTitle->setAttribute('class', 'AbsSession');
    	renameNode($absTitle, 'h1');
    }
    $absTitles = $XPath->query('//abstitle');
    foreach ($absTitles as $absTitle){
    	renameNode($absTitle, 'h2');
    }
    $absTitles = $XPath->query('//abshead|//absrefhead|//abskeywordhead');
    foreach ($absTitles as $absTitle){
    	renameNode($absTitle, 'h3');
    }
    $absTitles = $XPath->query('//absreftext/*[@class]');
    foreach ($absTitles as $absTitle){
    	renameNode($absTitle, 'span');
    }## Start Task Id - HF-2524
    $absTitles = $XPath->query('//abstblfoot');
    foreach ($absTitles as $absTitle){
    	$absTitle->setAttribute('class','AbsTblFoot');
    	renameNode($absTitle, 'p');
    }
    $absTitles = $XPath->query('//tblcaption');
    foreach ($absTitles as $absTitle){
    	$absTitle->setAttribute('class','AbsTblCaption');
    	renameNode($absTitle, 'p');
    }
    $absTitles = $XPath->query('//absauthors');
    foreach ($absTitles as $absTitle){
    	$absTitle->setAttribute('class','AbsAuthors');
    	renameNode($absTitle, 'p');
    }
    $absTitles = $XPath->query('//abssession|//absaff|//figcaption|//absreftext|//abstblfoot|//absfigfoot|//abskeywordpara');## End Task Id - HF-2524
    foreach ($absTitles as $absTitle){
    	renameNode($absTitle, 'p');
    }
    $absTitles = $XPath->query('//p[@wordspacing]|//p[@class="AbsAbsPara"]|//div[@class="jrnlAbsGroup"]/p[not(@class)]');
    foreach ($absTitles as $absTitle){
    	$absTitle->setAttribute('class', 'AbsPara');
    }
    $absTitles = $XPath->query('//absauthor|//abscollab|//absgivenname|//abssurname|//absaffref|//absnumber|//label');
    foreach ($absTitles as $absTitle){
    	renameNode($absTitle, 'span');
    }
    $absTitles = $XPath->query('//abstract');
    foreach ($absTitles as $absTitle){
    	$absTitle->setAttribute('type', 'content');
    	renameNode($absTitle, 'div');
    }
    $absTitles = $XPath->query('//jrnltblblock');
    foreach ($absTitles as $absTitle){
    	## Task Id - HF-2524
    	$absParas = $XPath->query('.//p[not(ancestor::tr) and not(@class="AbsTblFoot")]', $absTitle);
    	foreach ($absParas as $absPara){
    		$absPara->setAttribute('class', 'AbsTblCaption');
    	}
    	$absParas = $XPath->query('.//p[ancestor::tr]', $absTitle);
    	foreach ($absParas as $absPara){
    		$absPara->setAttribute('class', 'AbsTblPara');
    	}## End TAsk Id - HF-2524
    	$absTitle->setAttribute('class', 'AbsTblBlock');
    	renameNode($absTitle, 'div');
    }
    $absTitles = $XPath->query('//jrnlfigblock');
    foreach ($absTitles as $absTitle){
    	$absParas = $XPath->query('.//p', $absTitle);
    	foreach ($absParas as $absPara){
    		$absPara->setAttribute('class', 'AbsFigCaption');
    	}
    	$absTitle->setAttribute('class', 'AbsFigBlock');
    	renameNode($absTitle, 'div');
    }
    
    $absTitles = $XPath->query('//floatblock');
    foreach ($absTitles as $absTitle){
    	DOMRemove($absTitle);
    }
    
    
    $unwantedNodes = $XPath->query('//h1|//h2|//h3|//h4|//h5|//h6|//p');
    foreach ($unwantedNodes as $unwantedNode) {
    	$childNodes = $XPath->query('.//img', $unwantedNode);
    	if ($childNodes-> length > 0) continue;
    	if (preg_match('/^[\s\r\n\t]*$/u', $unwantedNode->nodeValue)){
    		$unwantedNode->parentNode->removeChild($unwantedNode);
    	}
    }
	
	//add fpage and lpage for articles
	$articles = $XPath->query('//span[contains(@class, "AbsNumber")]');
	foreach($articles as $article){
		$log = $logXPath->query('//abstitle[contains(@absnumber, "'.$article->nodeValue.'")]');
		if($log->length == 1){
			$log = $log->item(0);
			$article->parentNode->setAttribute('firstpage', $log->getAttribute('firstpage') ); //parent node is article title
			$article->parentNode->setAttribute('lastpage', $log->getAttribute('lastpage') );
			$article->parentNode->setAttribute('seq', $log->getAttribute('seq') );
		}
	}
	
    
    
    //remove div without attributes
    $uselessDivs = $XPath->query('//div[not(@*)]');
    foreach($uselessDivs as  $uselessDiv){
    	DOMRemove($uselessDiv);
    }
    
    // wrap author and affiliation ref intro contrib node
    $deletedNodes = $XPath->query('//span[contains(@class, "del")]');
    foreach($deletedNodes as $deletedNodeIndex => $deletedNode){
    	$deletedNode->parentNode->removeChild($deletedNode);
    }
    $insertedNodes = $XPath->query('//span[contains(@class, "ins")]');
    foreach($insertedNodes as $insertedNodeIndex => $insertedNode){
    	DOMRemove($insertedNode);
    }
    
    $insertedNodes = $XPath->query('//div[@class="editingCompleted"]');
    foreach($insertedNodes as $insertedNodeIndex => $insertedNode){
    	DOMRemove($insertedNode);
    }
    
    $insertedNodes = $XPath->query('//div[@class="WordSection1"]|//*[@class="tblfn"]');
    foreach($insertedNodes as $insertedNodeIndex => $insertedNode){
    	DOMRemove($insertedNode);
    }
    
    $insertedNodes = $XPath->query('//div[@class="Section1"]');
    foreach($insertedNodes as $insertedNodeIndex => $insertedNode){
    	DOMRemove($insertedNode);
    }
    
    
    $insertedNodes = $XPath->query('//div[@id="contentDivNode"]');
    foreach($insertedNodes as $insertedNodeIndex => $insertedNode){
    	DOMRemove($insertedNode);
    }
    
    
    
  $bodyNodes = $doc->getElementsByTagName('body');
    if ($bodyNodes->length == 0) return;
    $bodyNode = $bodyNodes->item(0);
     loopThroughContentNodes($XPath, './div[@type="content"]|.//div[@type="publication"]/div[@type="content"]', $bodyNode, $bodyNode);
    
    function loopThroughContentNodes($XPath, $xpathString, $parentNode, $bodyNode){
    	$contentNodes = $XPath->query($xpathString, $parentNode);
    	//echo '<br/>Content : ' . $contentNodes->length;
    	foreach ($contentNodes as $contentNodeIndex => $contentNode ){
    		loopThroughContentNodes($XPath, './div[@type="content"]', $contentNode, $bodyNode);
    		//$contentType = $XPath->query('./div[@type="content"]', $contentNode);
    		//echo '<br/>Content : ' . $contentNodeIndex . ' => ' . $contentType->length;
    		if($contentNode->previousSibling->nodeType == 1 && $contentNode->previousSibling->hasAttribute('class') && $contentNode->previousSibling->getAttribute('class') == 'AbsSubj'){
    			$bodyNode->appendChild($contentNode->previousSibling);
    		}
    		$contentNode->setAttribute('class', 'Abstract');
    		$bodyNode->appendChild($contentNode);
    	}
    } 
	
	
    //remove empty nodes
    $emptyRegex = '/^$/';
    $emptyNodes = $XPath->query("//*[php:functionString('preg_match', '$emptyRegex', .) > 0]");
    foreach($emptyNodes as  $emptyNode){
    	if(!preg_match('/td|img/',$emptyNode->nodeName)){
    		DOMRemove($emptyNode);
    	}
    }
    

    
    
    //******************//
    
    $insertedNodes = $XPath->query('//p[@class="AbsAuthors"]/strong');
    foreach($insertedNodes as $insertedNodeIndex => $insertedNode){
    	DOMRemove($insertedNode);
    }
	
    $keyWordHeads = $XPath->query('//*[@class="AbsHead"][@data-keyword="yes"]');
    foreach($keyWordHeads as $keyWordHead){
		$keyWordHead->setAttribute('class', 'AbsKeywordHead');
	}
	
    $keyWordHeads = $XPath->query('//*[@class="AbsPara"][@data-keyword="yes"]');
    foreach($keyWordHeads as $keyWordHead){
		$keyWordHead->setAttribute('class', 'AbsKeywordPara');
	}
	
	$styleNodes = $XPath->query('//*[@style]');
    foreach($styleNodes as $styleNode){
    	$styleNode->removeAttribute('style');
    	$styleNode->removeAttribute('data-mce-style');
    }
	
	$styleNodes = $XPath->query('//span[@class="AbsNumber"]');
    foreach($styleNodes as $styleNode){
		if (($styleNode->parentNode->nodeName != 'h2') && ($styleNode->nextSibling->nodeName == 'h2')){
			$styleNode->nextSibling->insertBefore($styleNode, $styleNode->nextSibling->firstChild);
		}
	}
	
	//remove anchor tags
	$aNodes = $XPath->query('//a');
	foreach($aNodes as $aNode){
		DOMRemove($aNode);
	}
	
    $authors = $XPath->query('//*[@class="AbsAuthor"]');
    foreach($authors as $absIndex => $author){
    	
        // Create the new element
    	$contrib = $doc->createElement('contrib');
        $author->parentNode->insertBefore($contrib, $author);
        if($author->getAttribute('data-corresp')){
        $contrib->setAttribute('corresp', 'yes');}
        $contrib->appendChild($author);
        
       
        $sups = $XPath->query('.//sup', $author);
        foreach($sups as $sup){
        	if($sup->nodeValue == '#'){   //remove <sup>#</sup> and add <contrib> tag attribute has corresp="yes" 
        		$sup->parentNode->removeChild($sup);
        		$contrib->setAttribute('corresp', 'yes');
        	}else {   //if have <sup> inside <AbsAuthor> then paste before it
        		$author->parentNode->insertBefore($sup,$author);
        	}
        }
        
        $prevNode = $contrib->previousSibling;
        $prevNodeName = $prevNode->nodeName;
        
        $follwingNode = $contrib->nextSibling;
        $followingNodeName = $follwingNode->nodeName;
        $follwingFollNode = $follwingNode->nextSibling;
        $followingFollNodeName = $follwingFollNode->nodeName;
        $followingNodeValue = $follwingNode->nodeValue;
        
        $prevPrevNode = $prevNode->previousSibling;
        $prevPrevNodeName = $prevPrevNode->nodeName;
        //the following node is a text node and if it is followed by a sup tag then move both inside contrib
        if (($prevNodeName == '#text') && ($prevPrevNodeName == 'sup')){
            $contrib->appendChild($prevNode);
            $contrib->appendChild($prevPrevNode);
        }else if ($prevNodeName == 'sup'){// if the following node is a sup node then move it inside contrib
            $contrib->appendChild($prevNode);
        }
        else if (($follwingNode == '#text') && ($followingFollNodeName == 'sup')){
            $contrib->appendChild($follwingNode);
            $contrib->appendChild( $follwingFollNode);
			$follwingNode = $follwingNode->nextSibling;
        }else if ($followingNodeName == 'sup'){// if the following node is a sup node then move it inside contrib
            $contrib->appendChild($follwingNode);
			$follwingNode = $follwingNode->nextSibling;
        }
        if (preg_match('/\*/', $followingNodeValue)){
        	$contrib->setAttribute('corresp', 'yes');
        }else if (preg_match('/\*/', $author->nodeValue)){
        	$contrib->setAttribute('corresp', 'yes');
		}
    }
	## Start Task Id - HF-2524 - Dhatshayani . D June 21, 2017
    $contribNodes = $XPath->query('//contrib');
    foreach ($contribNodes as $contribNode){
    	$follAffRrefNodes = $XPath->query('following-sibling::*[@class="AbsAffRef"][1]',$contribNode);
    	if($follAffRrefNodes->length > 0){
    		$follAffRrefNode = $follAffRrefNodes->item(0);
    		$contribNode->appendChild($follAffRrefNode);
    	}
    }## End Task ID - HF-2524
    
    $affRefs = $XPath->query('//contrib/sup|//contrib/*[@class="AbsAffRef"]');
    foreach($affRefs as $affRef){
    	$affRefValArray = explode(',', $affRef->nodeValue);
        $ridVal = "";
        foreach ($affRefValArray as $affRefVal){
            if (preg_match('/\x{2012}|\-/u', $affRefVal)){
                $affRefRange = split('/\x{2012}|\-/u', $affRefVal);
                for ($i = $affRefRange[0]; $i <= $affRefRange[1]; $i++){
                    $ridVal = $ridVal . " " . 'AF' . sprintf("%04d", $i);
                }
            }else{
                $affRIDTag = $doc->createElement('sup', $affRefVal);
				$ridVal = 'AF' . sprintf("%04d", $affRefVal);
				$affRIDTag->setAttribute('rid', preg_replace('/^ /', '', $ridVal));
				$affRef->parentNode->insertBefore($affRIDTag, $affRef);
            }
        }
        //$affRef->setAttribute('rid', preg_replace('/^ /', '', $ridVal));
		$affRef->parentNode->removeChild($affRef);
    }
	
    $index = 1;
	//$publications = $XPath->query('//div[@type="publication"]');
	//foreach($publications as $publication){
		
		$contents = $XPath->query('//div[@type="content"]');
		
		foreach($contents as $abstractSection){
			
			$absGroups = $XPath->query('.//*[@class="jrnlAbsGroup"]', $abstractSection);
			foreach ($absGroups as $absGroup){
				DOMRemove($absGroup);
			}
			
			
			//remove withdraw
			$articleTitle = $XPath->query('.//*[@class="AbsTitle"]', $abstractSection);
			if($articleTitle->length > 0){
				$articleTitle = $articleTitle->item(0);
				if(preg_match('/^[A-Z\d\-\s\x{00A0}]*WITHDRAWN$/ui', $articleTitle->nodeValue)){
					//echo $articleTitle->nodeValue.'<br/>';
					$abstractSection->parentNode->removeChild($abstractSection);
					//echo '<pre>' . $abstractSection->innerHTML.'</pre>';
					continue;
				}
			}
			## Start Task Id - HF-2524 - Dhatshayani . D June 21, 2017
			$affNodes = $XPath->query('.//*[@class="AbsAff"]|.//*[@class="AbsAuthAff"]',$abstractSection);
			if($affNodes->length == 1){
				$ridVal = 'AF' . sprintf("%04d", 1);
				$contribNodes = $XPath->query('.//contrib[not(sup)]',$abstractSection);
				foreach ($contribNodes as $contribNode){
					$affRIDTag = $doc->createElement('sup');
					$affRIDTag->setAttribute('rid', preg_replace('/^ /', '', $ridVal));
					$contribNode->appendChild($affRIDTag);
				}
			}## End Task Id - HF-2524
			
			//add doi
			## Start TAsk Id - HF-2524 - Dhatshayani . D June 21, 2017 - To generate the article DOI dynamically from the input content
			$dataDoi = $XPath->query('//html/@data-doi')->item(0)->nodeValue;
			if(!$dataDoi || $dataDoi == ""){
				$dataDoi = '10.1136/heartjnl-2014-307109';
			}
			$text = $dataDoi.'.'.($index);
			//$text = '10.1136/heartjnl-2014-307109.'.($index); ## End Task Id - HF-2524
			$doi = $doc->createElement('p');
			$doi->setAttribute('class','AbsDoi');
			$textNode = $doc->createTextNode($text);
			$doi->appendChild($textNode);
			$contentFirstChild = $XPath->query('.//h3|.//p[@class="AbsPara"]',$abstractSection);
			if($contentFirstChild->length > 0){
				$contentFirstChild->item(0)->parentNode->insertBefore($doi, $contentFirstChild->item(0));
				//echo $text.'<br>';
				$index++;
			}
			
			
			
			$abstractSection->setAttribute('class','Abstract');
			
			// group all affiliations
			$absAffElements = $XPath->query('./p[@class="AbsAff"]|./p[@class="AbsAuthAff"]',$abstractSection);
			// Create the new element
			$absAffGroup = $doc->createElement('div');
			$absAffGroup->setAttribute('class', 'AbsAffGroup');
			// Insert the new element
			foreach ($absAffElements as $absAffIndex => $absAffElement ) {
				if ($absAffIndex == 0){
					$absAffElement->parentNode->insertBefore($absAffGroup, $absAffElement);
				}
				$absAffElement->setAttribute('id', 'AF' . sprintf("%04d", $absAffIndex + 1));
				$absAffGroup->appendChild($absAffElement);
			}
			## Start Task Id - HF-2524
			$absKwdWithoutHeadNodes = $XPath->query('.//*[@class="AbsKeywordPara"][not(parent::*[@class="AbsKeywordHead"])]',$abstractSection);
			if($absKwdWithoutHeadNodes->length > 0){
				$absKwdWithoutHeadNode = $absKwdWithoutHeadNodes->item(0);
				$absKwdWithoutHeadNodeValue = $absKwdWithoutHeadNode->nodeValue;
				$kwdTitle = "";
				/* if(preg_match('/^(keywords|key words)(.*)/i',$absKwdWithoutHeadNodeValue)){
					$kwdTitle = preg_replace('/^(keywords|key words)(.*)/i','$1',$absKwdWithoutHeadNodeValue);
					$kwdTitle = '<h3 class="AbsKeywordHead">'.$kwdTitle.'</h3>';
				} */
				$kwdText = preg_replace('/^(keywords|key words)\s*\:\s*(.*)/i','$2',$absKwdWithoutHeadNodeValue);
				$kwdTextArray = preg_split('/[,;]/',$kwdText);
				foreach ($kwdTextArray as $kwdIndex => $kwdTextVal){
					if($kwdTextVal != ""){
						$kwdTextVal = preg_replace('/^[\s\x{A0}]|[\s\x{A0}]$/','',$kwdTextVal);
						$kwdTextVal = '<span class="jrnlKeyword">'.$kwdTextVal.'</span>';
						$kwdTextArray[$kwdIndex] = $kwdTextVal;
					}
				}
				
				$newKwdText = implode('',$kwdTextArray);
				$kwdHeadNodes = $XPath->query('preceding-sibling::*[@class="AbsKeywordHead"]',$absKwdWithoutHeadNode);
				if($kwdHeadNodes->length == 0){
					$kwdHTML = '<div class="jrnlKeyword">'.$kwdTitle.$newKwdText.'</div>';
				}else{
					$kwdHTML = $kwdTitle.$newKwdText;
				}
				$absKwdWithoutHeadNode->innerHTML = $kwdHTML;
				DOMRemove($absKwdWithoutHeadNode);
			}
			## End TAsk Id - HF-2524
			// group all Abstract Body Elements
			$absBodyElements = $XPath->query('.//p[@class="AbsDoi"]|.//p[@class="AbsAff"]|.//p[@class="AbsAuthAff"]',$abstractSection);
			if ($absBodyElements->length > 0){
				$l = $absBodyElements->length - 1;
				$absBodyElements = $XPath->query('./following-sibling::*',$absBodyElements->item($l));
			}
			// Create the new element
			$absBody = $doc->createElement('div');
			$absBody->setAttribute('class', 'AbsBody');
			// Insert the new element
			$absBodyElementName = ""; $absBodyElementClass = "";
			$sec = $doc->createElement('sec1');
			foreach ($absBodyElements as $absBodyIndex => $absBodyElement ) {
				if ($absBodyIndex == 0){
					$absBodyElement->parentNode->insertBefore($absBody, $absBodyElement);
					$absBody->appendChild($sec);
				}
				$absBodyElementName = $absBodyElement->nodeName;
				$absBodyElementClass = $absBodyElement->getAttribute('class');
				if (($absBodyElementName == 'h3') && ($absBodyElementClass == 'AbsHead')){
					$sec = $doc->createElement('sec');
					$absBody->appendChild($sec);
				}
				if (($absBodyElementName == 'div') && ($absBodyElementClass == 'H3Group')){
					$sec = $doc->createElement('sec');
					$absBody->appendChild($sec);
				}
				if (($absBodyElementName == 'div') && ($absBodyElementClass == 'H3Group dontsplit')){
					$sec = $doc->createElement('sec');
					$absBody->appendChild($sec);
				}
				if (($absBodyElementName == 'h3') && ($absBodyElementClass == 'AbsRefHead')){
					$sec = $doc->createElement('sec');
					$absBody->appendChild($sec);
				}
				if ($absBodyElementClass == 'AbsKeywordHead'){
					$sec = $doc->createElement('kwd-group');
					$absBody->appendChild($sec);
				}
				if (($absBodyElementName == 'p') && ($absBodyElementClass == 'AbsPara') && ($sec->nodeName == 'sec1')){
					$sec = $doc->createElement('sec');
					$absBody->appendChild($sec);
				}
				$sec->appendChild($absBodyElement);
			}
			
			
			$keywordElements = $XPath->query('./*[@class="AbsKeywordHead"]|./p[@class="AbsKeywordPara"]', $abstractSection);
			// Create the new element
			$keywordGroup = $doc->createElement('div');
			$keywordGroup->setAttribute('class', 'jrnlKeyword');
			// Insert the new element
			foreach ($keywordElements as $keyElementIndex => $keywordElement ) {
				if ($keyElementIndex == 0){
					$keywordElement->parentNode->insertBefore($keywordGroup, $keywordElement);
				}
				$keywordGroup->appendChild($keywordElement);
			}
			
			$affRefs = $XPath->query('.//p[@class="AbsKeywordPara"]', $abstractSection);
			foreach($affRefs as $affRef){
				$affRefValArray = preg_split('/\s?,\s?/', $affRef->nodeValue);
				$affRefParent = $affRef->parentNode;
				$affRefPatentNodeVal = $affRefParent->nodeValue;
				foreach ($affRefValArray as $affRefVal){
					$newAffRef = $doc->createElement('span', $affRefVal);
					$newAffRef->setAttribute('class', 'jrnlKeyword');
					$affRefParent->insertBefore($newAffRef, $affRef);
				}
				$affRef->parentNode->removeChild($affRef);
			}
			
			$absFloats = $XPath->query('.//p[@class="AbsFigCaption"]', $abstractSection);
			foreach($absFloats as $absIndex => $absFloat){
				## Start Task Id - HF-2524
				$absFloatParentNodes = $XPath->query('ancestor::*[@class="AbsFigBlock"]',$absFloat);
				if($absFloatParentNodes->length == 0){
					// Create the new element
					$abstractFig = $doc->createElement('div');
					$abstractFig->setAttribute('class', 'AbsFigBlock');
					// Insert the new element
					$absFloat->parentNode->insertBefore($abstractFig, $absFloat);
					$newnode = $abstractFig->appendChild($absFloat);
					
					$labelNodeValue = $XPath->query('.//span[@class="label"]',$abstractFig)->item(0)->nodeValue;
					if($labelNodeValue && $labelNodeValue != "" && preg_match('/(figure\s*([0-9]+))/i',$labelNodeValue,$labelMatches)){
						$figId = 'F'.$labelMatches[2];
						$abstractFig->setAttribute('id',$figId);
					}
				}## End Task Id - HF-2524
				$absFigLabels = $XPath->query('./span[@class="label"]',$absFloat);
				foreach ($absFigLabels as $absFigLabel){
					$absFloat->parentNode->insertBefore($absFigLabel, $absFloat);
					$figLabelValue = $absFigLabel->nodeValue;
					$figLabelValue = preg_replace('/.*Figure (\d+)$/', 'F$1', $figLabelValue);
					$absFloat->parentNode->setAttribute('id', $figLabelValue);
				}
				$absFloatValue = $absFloat->nodeValue;
				$absFloatValue = preg_replace('/^\s*/', '', $absFloatValue);
			}
			
			$absTabFloats = $XPath->query('.//table', $abstractSection);
			foreach($absTabFloats as $absIndex => $absTabFloat){
				## Start Task Id - HF-2524
				$absFloatParentNodes = $XPath->query('ancestor::*[@class="AbsTblBlock"]',$absTabFloat);
				if($absFloatParentNodes->length == 0){
					$precedingSibNodes = $XPath->query('preceding-sibling::*',$absTabFloat);
					// Create the new element
					$abstractTbl = $doc->createElement('div');
					$abstractTbl->setAttribute('class', 'AbsTblBlock');
					// Insert the new element
					$absTabFloat->parentNode->insertBefore($abstractTbl, $absTabFloat);
					foreach ($precedingSibNodes as $precedingSibNode){
						if($precedingSibNode->nodeType == 1 && $precedingSibNode->hasAttribute('class') && $precedingSibNode->getAttribute('class') == "AbsTblCaption"){
							$newnode = $abstractTbl->appendChild($precedingSibNode);
						}else{
							break;
						}
					}
					$newnode = $abstractTbl->appendChild($absTabFloat);
					$labelNodeValue = $XPath->query('.//span[@class="label"]',$abstractTbl)->item(0)->nodeValue;
					if($labelNodeValue && $labelNodeValue != "" && preg_match('/(table\s*([0-9]+))/i',$labelNodeValue,$labelMatches)){
						$tblId = 'T'.$labelMatches[2];
						$abstractTbl->setAttribute('id',$tblId);
					}
				}## End TAsk Id - HF-2524
				$continue = 1;
				while ($continue == 1){
					if($abstractTbl){
						$nextSibling = $abstractTbl->nextSibling;
					}else{
						$nextSibling = $absTabFloat->parentNode->nextSibling;
					}
					if ($nextSibling){
						$nextSiblingName = $nextSibling->nodeName;
						if ($nextSiblingName == '#text'){
							$continue = 0;
							//$abstractSection->appendChild($nextSibling);
						}else{
							if($nextSibling->nodeType == 1) $nextSiblingClassName = $nextSibling->getAttribute('class');
							else $nextSiblingClassName  = '';
							if (($nextSiblingClassName == 'tblfn') || ($nextSiblingClassName == 'AbsTblFoot')){
								if($abstractTbl){
									$abstractTbl->appendChild($nextSibling);
								}else{
									$absTabFloat->parentNode->appendChild($nextSibling);
								}
							}else{$continue = 0;}
						}
					}else{$continue = 0;}
				}
			}
			
			$theads = $XPath->query('.//thead', $abstractSection);
			foreach ($theads as $thead){
				$rows = $XPath->query('./tr', $thead);
				$rCnt = $rows->length;
				if ($rCnt > 0){
					$row = $rows->item(0);
					$columns = $XPath->query('./td|./th', $row);
					$colCnt = 0;
					foreach ($columns as $col){
						if ($col->hasAttribute('colspan')) {
							$colSpan = $col->getAttribute('colspan');
							$colCnt = $colCnt + $colSpan;
						}else{$colCnt = $colCnt + 1;}
					}
				}
				foreach ($rows as $row){
					$newRow = $doc->createElement('tr');
					$row->parentNode->insertBefore($newRow, $row);
					$newRow->parentNode->insertBefore($row, $newRow);
					$newRow->innerHTML = '<th colspan="' . $colCnt .'"><hr/></th>';
				}
			}///***end of thead tr***//
			
			$absTblCaptions = $XPath->query('.//p[@class="AbsTblCaption"]', $abstractSection);
			foreach($absTblCaptions as $absIndex => $absTblCaption){
				// Create the new element
				// Insert the new element
				$continue = 1;
				while ($continue == 1){
					$nextSibling = $absTblCaption->nextSibling;
					if ($nextSibling){
						$nextSiblingName = $nextSibling->nodeName;
						if ($nextSiblingName == '#text'){
							$continue = 0;
							//$abstractSection->appendChild($nextSibling);
						}else{
							$nextSiblingClassName = $nextSibling->getAttribute('class');
							if (($nextSiblingName == 'div') && ($nextSiblingClassName == 'AbsTblBlock')){
								$absTbl = $nextSibling->firstChild;
								$absTbl->parentNode->insertBefore($absTblCaption, $absTbl);
								$continue = 0;
							}else{$continue = 0;}
						}
					}else{$continue = 0;}
				}
				$parentNode = $absTblCaption->parentNode;
				$parentNodeClassName = $parentNode->getAttribute('class');
				if (($parentNodeName != 'div') && ($parentNodeClassName != 'AbsTblBlock')){
					$abstractTbl = $doc->createElement('div');
					$imgNodes = $XPath->query('.//img', $absTblCaption);
					if ($imgNodes->length != 0){
						$abstractTbl->setAttribute('class', 'AbsFigBlock');
					}else{
						$abstractTbl->setAttribute('class', 'AbsTblBlock');
					}
					// Insert the new element
					$absTblCaption->parentNode->insertBefore($abstractTbl, $absTblCaption);
					$newnode = $abstractTbl->appendChild($absTblCaption);
				}
			
				$absTblLabels = $XPath->query('./span[@class="label"]',$absTblCaption);
				foreach ($absTblLabels as $absTblLabel){
					$absTblCaption->parentNode->insertBefore($absTblLabel, $absTblCaption);
					$tblLabelValue = $absTblLabel->nodeValue;
					$tblLabelValue = preg_replace('/.*Table (\d+)$/', 'T$1', $tblLabelValue);
					$absTblCaption->parentNode->setAttribute('id', $tblLabelValue);
				}
				$absTblCaptionValue = $absTblCaption->nodeValue;
				$absTblCaptionValue = preg_replace('/^\s*/', '', $absTblCaptionValue);
				//$absTblCaption->innerHTML = $absTblCaptionValue;
			}
		}
	//}
		
	//remove spaces in attribute ID
	$IDNodes = $XPath->query('//*[@id or @rid]');
	foreach($IDNodes as  $IDNode){
		if($IDNode->hasAttribute('id')){
			$idValue = preg_replace('/\s/','_',$IDNode->getAttribute('id'));
			$idValue = preg_replace('/\.$/','',$idValue);
			$IDNode->setAttribute('id', $idValue);
		}else {
			$idValue = preg_replace('/\s/','_',$IDNode->getAttribute('rid'));
			$idValue = preg_replace('/\.$/','',$idValue);
			$IDNode->setAttribute('rid', $idValue);
		}
	}
	
	//move <kwd-group> outside <abstract>
	$abstracts  = $XPath->query('//div[@class="Abstract"]'); 
	foreach($abstracts as $abstract){
		$kwdGroups = $XPath->query('.//kwd-group', $abstract);
		if($kwdGroups->length < 1){
			continue;
		}
		$abstract->appendChild($kwdGroups->item(0));
		//$kwdGroups->item(0)->parentNode->insertBefore($abstract, $kwdGroups->item(0));
		
	}
	
	/* list tag for references with serial no
	example
	<sec><title>References</title><p>1. ICH Q5E: Comparabil...</p><p>2. Schneide...</p>
	as
	<sec><title>References</title><list list-type="order"><list-item><p>ICH Q5E: Comparabil...</p>..... */
	foreach($XPath->query('//h3[@class="AbsRefHead"]') as $heading){
		if(preg_match('/^ref[a-z]+$/i', $heading->nodeValue)){ //get reference title
			$list = $doc->createElement('list');
			$list->setAttribute('list-type', 'order');
			$listTagAdded = false;
			$absRefText = $heading->nextSibling;
			while($absRefText){
				if($absRefText->nodeType == 1 && $absRefText->hasAttribute('class') && $absRefText->getAttribute('class') == 'AbsRefText'){
					if(!$listTagAdded){
						$absRefText->parentNode->insertBefore($list, $absRefText); //add list node
						$listTagAdded = true;
					}
					$slno = $XPath->query('.//span[@class="RefSlNo"]', $absRefText); //remove serial number node
					if($slno->length > 0){
						$slno->item(0)->parentNode->removeChild($slno->item(0));
					}
					
					
					$listItem = $doc->createElement('list-item');  //add list item node
					$list->appendChild($listItem);
					$nextSibling = $absRefText->nextSibling;
					$listItem->appendChild($absRefText);
					$absRefText = $nextSibling;
				}else {
					break;
				}
			}
		}
	}
	
	//senetence  case for abs title
	/*foreach($XPath->query('//h2[@class="AbsTitle"]') as $absTitle){
		$childNodes = $absTitle->childNodes;
		$ucfirstDone = false;
		foreach($childNodes as $childNode){
			if($childNode->nodeType == 1){
				if($childNode->hasAttribute('class') &&  $childNode->getAttribute('class') == 'AbsNumber'){
					continue;
				}else {
					if(!$ucfirstDone){
						$childNode->nodeValue = ucfirst(preg_replace('/^[\s\x{A0}]/ui','',strtolower($childNode->nodeValue)));
						$ucfirstDone = true;
					}else {
						$childNode->nodeValue = strtolower($childNode->nodeValue);
					}
				}
			}else if($childNode->nodeType == 3){
				if(!$ucfirstDone){
					$childNode->nodeValue = ucfirst(preg_replace('/^[\s\x{A0}]/ui','',strtolower($childNode->nodeValue)));
					$ucfirstDone = true;
				}else {
					$childNode->nodeValue = strtolower($childNode->nodeValue);
				}
			}
		}
	}*/
	## Start Task Id - HF-2524
	
	$articleAbsNodes = $XPath->query('//div[@class="Abstract"][*[@class="AbsSession"]]');
	foreach ($articleAbsNodes as $articleAbsNode){
		$absSecNodes = $XPath->query('.//*[@class="AbsSession"]',$articleAbsNode);
		if($absSecNodes->length > 0){
			//$absSecNode = $absSecNodes->item(0);
			
			$followingAbsNodes = $XPath->query('following-sibling::div[@class="Abstract"]',$articleAbsNode);
			foreach ($followingAbsNodes as $followingAbsNode){
				$follAbsSecNodes = $XPath->query('.//*[@class="AbsSession"]',$followingAbsNode);
				$follFirstChild = $followingAbsNode->firstChild;
				if($follAbsSecNodes->length == 0){
					foreach ($absSecNodes as $absSecNode){
						$newAbsSecNode = $absSecNode->cloneNode(true);
						if($follFirstChild){
							$follFirstChild->parentNode->insertBefore($newAbsSecNode,$follFirstChild);
						}
					}
				}else{
					break;
				}
			
			}
		}
	}
	
	$articleAbsNodes = $XPath->query('//div[@class="AbsBody"][not(div[@class="jrnlKeyword"]) and .//div[@class="jrnlKeyword"]]');
	foreach ($articleAbsNodes as $articleAbsNode){
		$keyWordNodes = $XPath->query('.//div[@class="jrnlKeyword"]',$articleAbsNode);
		foreach ($keyWordNodes as $keyWordNode){
			$articleAbsNode->appendChild($keyWordNode);
		}
	}
	$articleAbsNodes = $XPath->query('//div[@class="AbsBody"][not(div[@class="jrnlKeyword"]) and preceding-sibling::div[@class="jrnlKeyword"]]');
	foreach ($articleAbsNodes as $articleAbsNode){
		$keyWordNodes = $XPath->query('receding-sibling::div[@class="jrnlKeyword"]',$articleAbsNode);
		foreach ($keyWordNodes as $keyWordNode){
			$articleAbsNode->appendChild($keyWordNode);
		}
	}
	$removeabs = $XPath->query('//div[@class="Abstract"][contains(., "abstract withdrawn")]');
	foreach ($removeabs as $removeabs){
			$removeabs->parentNode->removeChild($removeabs);
		}
	## End TAsk Id - HF-2524
	//$articleAbsNodes = $XPath->query('//Abstract');
    //echo $doc->saveXML(); exit;
    //echo $url . '<br/>';
    $url = str_replace('.htm', '.xml', $url);
	
    //$doc->save("E:\My Box Files\ExeterAuthoringSystem\jobs\ExportToXML\posters_output.xml");
    //$doc->save($url);
	$processedData = $doc->saveXML();
    $processedData = str_replace('<?xml version="1.0" standalone="yes"?>', '<?xml version="1.0" encoding="utf-8"?>', $processedData);
    $processedData = str_replace('<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">', '', $processedData);
    //$processedData = str_replace('<!DOCTYPE article PUBLIC "-//NLM//DTD Journal Publishing DTD v2.3 20070202//EN" "C:/Documents and Settings/kanna/Desktop/journal-publishing-dtd-2.3/journalpublishing.dtd">', '', $processedData);
    $processedData = str_replace('<?xml version="1.0" encoding="utf-8"??>', '', $processedData);
    if ($url){
    	$url = str_replace('.xml', '_output.xml', $url);
    	file_put_contents($url, $processedData, null, $context);
		//chmod( $url, 0777);

    }
	
    //echo $url.'<br>';
    
	$xsl = new DOMDocument();
    $xsl->load("updatedXSL.xsl");
    //$xsl->load("D:/PhP/ihcJournalsHTML2XML.xsl");

    $proc = new XSLTProcessor();
    $xsl = $proc->importStylesheet($xsl);
    //$proc->setParameter(null, "", "");

    $newdom = $proc->transformToDOC($doc);
    ## Start TAsk Id - HF-2524
    if($newdom){
    	$newXpath = new DOMXPath($newdom);
    	
    	$kwdGroupNodes = $newXpath->query('//abstract/preceding-sibling::kwd-group');
    	foreach ($kwdGroupNodes as $kwdGroupNode){
    		$kwdGroupNode->parentNode->removeChild($kwdGroupNode);
    	}
    }## End TAsk Id - HF-2524
	
    $processedData = $newdom->saveXML();
    $processedData = str_replace('<?xml version="1.0" standalone="yes"?>', '<?xml version="1.0" encoding="utf-8"?>', $processedData);
    
    $processedData = str_replace('<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">', '', $processedData);
    $processedData = str_replace('<?xml version="1.0" encoding="utf-8"??>', '', $processedData);
    $processedData = str_replace('<!DOCTYPE article PUBLIC "-//NLM//DTD Journal Publishing DTD v2.3 20070202//EN" "journal-publishing-dtd-2.3\journalpublishing.dtd">', '<!DOCTYPE article PUBLIC "-//NLM//DTD Journal Publishing DTD v2.3 20070202//EN" "C:/Documents and Settings/kanna/Desktop/journal-publishing-dtd-2.3/journalpublishing.dtd">', $processedData);
$processedData = str_replace('<list-item><p>.', '<list-item><p>', $processedData);
    if ($url){
        $url = str_replace('_output.xml', '_final.xml', $url);
        file_put_contents($url, $processedData, null, $context);
		//chmod( $url, 0777);
    }
    header('Content-Type: text/xml; charset=UTF-8');
 	//echo $processedData;
  //force download output file
	header('Content-Type: application/octet-stream');
	header("Content-Transfer-Encoding: Binary"); 
	header("Content-disposition: attachment; filename=\"" . basename($downloadFileName) . "\""); 
	readfile($downloadFileName); 
	//$removeFiles = array( 'logPageNumber.xml', 'updatedXSL.xsl', $uploadedFileName, $tempFileName, $downloadFileName);
	foreach($removeFiles as $removeFile){
		unlink($removeFile);
	} 
	exit;
    //http://stackoverflow.com/questions/4675460/php-dom-remove-element-leave-contents
    /*
     *   function to remove the node sent as argument and retain its children
    */
    function DOMRemove(DOMNode $from) {
    	$sibling = $from->firstChild;
    	do {
    		$next = $sibling->nextSibling;
    		if ($sibling != null){
    			$from->parentNode->insertBefore($sibling, $from);
    		}
    	} while (($sibling != null) && ($next != null) && ($sibling = $next));
    	$from->parentNode->removeChild($from);
    }
    
    
    /**
     * Renames a node in a DOM Document.
     *
     * @param DOMElement $node
     * @param string     $name
     * @see url http://php.undmedlibrary.org/function.dom-domdocument-renamenode
     *
     * @return DOMNode
     */
    function renameNode(DOMElement $node, $name) {
    	$renamed = $node->ownerDocument->createElement($name);
    
    	foreach ($node->attributes as $attribute) {
    		$renamed->setAttribute($attribute->nodeName, $attribute->nodeValue);
    	}
    
    	while ($node->firstChild) {
    		$renamed->appendChild($node->firstChild);
    	}
    
    	return $node->parentNode->replaceChild($renamed, $node);
    }
    
?>
