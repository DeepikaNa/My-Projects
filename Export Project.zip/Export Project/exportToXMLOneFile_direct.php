<?php
//ini_set('display_errors', 'on');
ini_set('max_execution_time', 0);
require_once 'JSLikeHTMLElement.php';

//update front matter in XSL - START
$xslContent = file_get_contents('bmjHTML2XML.xsl'); //original xsl
$dom = new DOMDocument();
$dom->loadXML($xslContent);
$XPath = new DOMXPath($dom);
$updateNodes = $XPath->query('//journal-meta/*');
foreach($updateNodes as $updateNode){
	if(isset($_POST[$updateNode->nodeValue])){
		$updateNode->nodeValue = $_POST[$updateNode->nodeValue];
	}
}
file_put_contents('updatedXSL.xsl', $dom->saveXML());

//save uploaded file
$uploadedFileName = 'BMJ-gut-abs-ext_ext.xml'; //given file name
$tempFileName = preg_replace('/\.xml$/','_output.xml', $uploadedFileName);
$downloadFileName = preg_replace('/\.xml$/','_final.xml', $uploadedFileName);
move_uploaded_file($_FILES["fileName"]["tmp_name"], $uploadedFileName);

// set the stream to utf based
$opts = array(
  'http'=>array(
	'method'=>"GET",
	'header'=>"Accept-language: en\r\n" .
			  "Cookie: foo=bar\r\n" .
			  "Content-Type: text/html; charset=UTF-8"
  )
);
$context = stream_context_create($opts);
	
	$url = $uploadedFileName;
	// read file contents
    $urlContent = file_get_contents($url, false, $context);
    $urlContent = str_replace(' lastClicked', '', $urlContent);
    $urlContent = preg_replace('/\n|\r/', '', $urlContent);
    $urlContent = preg_replace('/\s{2,}/', ' ', $urlContent);
    $urlContent = str_replace('&nbsp;', ' ', $urlContent);
    $urlContent = str_replace('&#x00A0;', ' ', $urlContent);
    $urlContent = str_replace('&#12289;', ', ', $urlContent);
    $urlContent = str_replace('&#65288;', ' (', $urlContent);
    $urlContent = str_replace('&#65288;', ') ', $urlContent);
    $urlContent = mb_convert_encoding($urlContent, 'HTML-ENTITIES', "UTF-8");
    // Create DOM from URL
    $doc = new DOMDocument();
    // the below line is required to get the innerHTML method working
    $doc->registerNodeClass('DOMElement', 'JSLikeHTMLElement');
    $doc->loadHTML($urlContent);
    $XPath = new DOMXPath($doc);
    $XPath->registerNamespace('php', 'http://php.net/xpath');
    $XPath->registerPhpFunctions(array('preg_match', 'preg_split', 'preg_replace', 'sizeof', 'str_word_count'));
    
	/*
	//path script for reversing bmj node name to its class name
	$taggingArray = array('AbsSession'=>'h1,AbsSession','AbsRefHead'=>'h3','AbsRefHead','RefSlNo'=>'span','RefSlNo','RefAuthor'=>'span,RefAuthor','RefVolume'=>'span,RefVolume','RefIssue'=>'span,RefIssue','RefFPage'=>'span,RefFPage','RefLPage'=>'span,RefLPage','smallCaps'=>'span,smallCaps','RefPrefix'=>'span,RefPrefix','AbsTitle'=>'h2,AbsTitle','label'=>'span,label','body'=>'div,body','AbsKeywordPara'=>'p,AbsKeywordPara','AbsHead'=>'h3,AbsHead','AbsKeywordHead'=>'h3,AbsKeywordHead','AbsEmail'=>'span,AbsEmail','AbsFax'=>'span,AbsFax','AbsTelephone'=>'span,AbsTelephone','AbsCountry'=>'span,AbsCountry','RefSource'=>'span,RefSource','AbsAddrLine'=>'span,AbsAddrLine','AbsSubj'=>'h1,AbsSubj','Comments'=>'span,Comments','AbsAuthors'=>'p,AbsAuthors','RefYear'=>'span,RefYear','RefArticleTitle'=>'span,RefArticleTitle','RefJournalTitle'=>'span,RefJournalTitle','AbsRefText'=>'p,AbsRefText','AbsAuthor'=>'span,AbsAuthor','AbsAffRef'=>'span,AbsAffRef','AbsNumber'=>'span,AbsNumber','AbsGivenName'=>'span,AbsGivenName','AbsSurName'=>'span,AbsSurName','AbsTblFoot'=>'p,AbsTblFoot','AbsAff'=>'p,AbsAff','AbsCorrAff'=>'p,AbsCorrAff','disp-quote'=>'p,AbsEpiGraph','jrnlTblBlock'=>'div,jrnlTblBlock','TblCaption'=>'p,AbsTblCaption','jrnlFigBlock'=>'div,jrnlFigBlock','FigCaption'=>'p,AbsFigCaption');
	//remove all keys to lowercase
	foreach(array_keys($taggingArray) as $key){
		$value = $taggingArray[$key];
		$taggingArray[strtolower($key)] = $value;
		unset($taggingArray[$key]);
	}
	$nodes = $XPath->query('//*');
	foreach($nodes as $node){
		$nodeName = $node->nodeName;
		if( isset($taggingArray[$nodeName]) ){
			$tagging = explode( ',', $taggingArray[$nodeName] );
			$tagName = $tagging[0];
			$className = $tagging[1];
			$newNode = $doc->createElement($tagName);
			$newNode->setAttribute('class', $className);
			$node->parentNode->insertBefore($newNode, $node);
			$newNode->innerHTML = $node->innerHTML;
			$node->parentNode->removeChild($node);
		}
	}
	$nodes = $XPath->query('//abstract');
	foreach($nodes as $node){
		$tagName = 'div';
		$newNode = $doc->createElement($tagName);
		$newNode->setAttribute('type', 'content');
		$node->parentNode->insertBefore($newNode, $node);
		$newNode->innerHTML = $node->innerHTML;
		$node->parentNode->removeChild($node);
	}
	
	
	file_put_contents('test.xml', $doc->saveHTML());
	exit;
	*/
    
    
    //remove div without attributes
    $uselessDivs = $XPath->query('//div[not(@*)]');
    foreach($uselessDivs as  $uselessDiv){
    	DOMRemove($uselessDiv);
    }
    
    // wrap author and affiliation ref intro contrib node
    $deletedNodes = $XPath->query('//span[contains(@class, "del")]');
    foreach($deletedNodes as $deletedNodeIndex => $deletedNode){
    	$deletedNode->parentNode->removeChild($deletedNode);
    }
    $insertedNodes = $XPath->query('//span[contains(@class, "ins")]');
    foreach($insertedNodes as $insertedNodeIndex => $insertedNode){
    	DOMRemove($insertedNode);
    }
    
   /*  $insertedNodes = $XPath->query('//div[@class="editingCompleted"]');
    foreach($insertedNodes as $insertedNodeIndex => $insertedNode){
    	DOMRemove($insertedNode);
    } */
    
    $insertedNodes = $XPath->query('//div[@class="WordSection1"]|//*[@class="tblfn"]');
    foreach($insertedNodes as $insertedNodeIndex => $insertedNode){
    	DOMRemove($insertedNode);
    }
    
    $insertedNodes = $XPath->query('//div[@class="Section1"]');
    foreach($insertedNodes as $insertedNodeIndex => $insertedNode){
    	DOMRemove($insertedNode);
    }
    
    
    $insertedNodes = $XPath->query('//div[@id="contentDivNode"]');
    foreach($insertedNodes as $insertedNodeIndex => $insertedNode){
    	DOMRemove($insertedNode);
    } 
    
	$bodyNodes = $doc->getElementsByTagName('body');
	if ($bodyNodes->length == 0) return;
	$bodyNode = $bodyNodes->item(0);
	loopThroughContentNodes($XPath, './div[@type="content"]|.//div[@type="publication"]/div[@type="content"]', $bodyNode, $bodyNode);
    
    function loopThroughContentNodes($XPath, $xpathString, $parentNode, $bodyNode){
    	$contentNodes = $XPath->query($xpathString, $parentNode);
    	//echo '<br/>Content : ' . $contentNodes->length;
    	foreach ($contentNodes as $contentNodeIndex => $contentNode ){
    		loopThroughContentNodes($XPath, './div[@type="content"]', $contentNode, $bodyNode);
    		//$contentType = $XPath->query('./div[@type="content"]', $contentNode);
    		//echo '<br/>Content : ' . $contentNodeIndex . ' => ' . $contentType->length;
    		if($contentNode->previousSibling->nodeType == 1 && $contentNode->previousSibling->hasAttribute('class') && $contentNode->previousSibling->getAttribute('class') == 'AbsSubj'){
    			$bodyNode->appendChild($contentNode->previousSibling);
    		}
    		$contentNode->setAttribute('class', 'Abstract');
    		$bodyNode->appendChild($contentNode);
    	}
    } 
	
	
    //remove empty nodes
    $emptyRegex = '/^$/';
    $emptyNodes = $XPath->query("//*[php:functionString('preg_match', '$emptyRegex', .) > 0]");
    foreach($emptyNodes as  $emptyNode){
    	if(!preg_match('/td|img/',$emptyNode->nodeName)){
    		DOMRemove($emptyNode);
    	}
    }
    

    
    
    //******************//
    
    $insertedNodes = $XPath->query('//p[@class="AbsAuthors"]/strong');
    foreach($insertedNodes as $insertedNodeIndex => $insertedNode){
    	DOMRemove($insertedNode);
    }
	
    $keyWordHeads = $XPath->query('//*[@class="AbsHead"][@data-keyword="yes"]');
    foreach($keyWordHeads as $keyWordHead){
		$keyWordHead->setAttribute('class', 'AbsKeywordHead');
	}
	
    $keyWordHeads = $XPath->query('//*[@class="AbsPara"][@data-keyword="yes"]');
    foreach($keyWordHeads as $keyWordHead){
		$keyWordHead->setAttribute('class', 'AbsKeywordPara');
	}
	
	$styleNodes = $XPath->query('//*[@style]');
    foreach($styleNodes as $styleNode){
    	$styleNode->removeAttribute('style');
    	$styleNode->removeAttribute('data-mce-style');
    }
	
	$styleNodes = $XPath->query('//span[@class="AbsNumber"]');
    foreach($styleNodes as $styleNode){
		if (($styleNode->parentNode->nodeName != 'h2') && ($styleNode->nextSibling->nodeName == 'h2')){
			$styleNode->nextSibling->insertBefore($styleNode, $styleNode->nextSibling->firstChild);
		}
	}
	
	//remove anchor tags
	$aNodes = $XPath->query('//a');
	foreach($aNodes as $aNode){
		DOMRemove($aNode);
	}
	
    $authors = $XPath->query('//span[@class="AbsAuthor"]');
    foreach($authors as $absIndex => $author){
    	
        // Create the new element
    	$contrib = $doc->createElement('contrib');
        $author->parentNode->insertBefore($contrib, $author);
        $contrib->appendChild($author);
        
       
        $sups = $XPath->query('.//sup', $author);
        foreach($sups as $sup){
        	if($sup->nodeValue == '#'){   //remove <sup>#</sup> and add <contrib> tag attribute has corresp="yes" 
        		$sup->parentNode->removeChild($sup);
        		$contrib->setAttribute('corresp', 'yes');
        	}else {   //if have <sup> inside <AbsAuthor> then paste before it
        		$author->parentNode->insertBefore($sup,$author);
        	}
        }
        
        $prevNode = $contrib->previousSibling;
        $prevNodeName = $prevNode->nodeName;
        
        $follwingNode = $contrib->nextSibling;
        $followingNodeName = $follwingNode->nodeName;
        $follwingFollNode = $follwingNode->nextSibling;
        $followingFollNodeName = $follwingFollNode->nodeName;
        $followingNodeValue = $follwingNode->nodeValue;
        
        $prevPrevNode = $prevNode->previousSibling;
        $prevPrevNodeName = $prevPrevNode->nodeName;
        //the following node is a text node and if it is followed by a sup tag then move both inside contrib
        if (($prevNodeName == '#text') && ($prevPrevNodeName == 'sup')){
            $contrib->appendChild($prevNode);
            $contrib->appendChild($prevPrevNode);
        }else if ($prevNodeName == 'sup'){// if the following node is a sup node then move it inside contrib
            $contrib->appendChild($prevNode);
        }
        else if (($follwingNode == '#text') && ($followingFollNodeName == 'sup')){
            $contrib->appendChild($follwingNode);
            $contrib->appendChild( $follwingFollNode);
			$follwingNode = $follwingNode->nextSibling;
        }else if ($followingNodeName == 'sup'){// if the following node is a sup node then move it inside contrib
            $contrib->appendChild($follwingNode);
			$follwingNode = $follwingNode->nextSibling;
        }
        if (preg_match('/\*/', $followingNodeValue)){
        	$contrib->setAttribute('corresp', 'yes');
        }else if (preg_match('/\*/', $author->nodeValue)){
        	$contrib->setAttribute('corresp', 'yes');
		}
    }

    $affRefs = $XPath->query('//contrib/sup');
    foreach($affRefs as $affRef){
    	$affRefValArray = explode(',', $affRef->nodeValue);
        $ridVal = "";
        foreach ($affRefValArray as $affRefVal){
            if (preg_match('/\x{2012}|\-/u', $affRefVal)){
                $affRefRange = split('/\x{2012}|\-/u', $affRefVal);
                for ($i = $affRefRange[0]; $i <= $affRefRange[1]; $i++){
                    $ridVal = $ridVal . " " . 'AF' . sprintf("%04d", $i);
                }
            }else{
                $affRIDTag = $doc->createElement('sup', $affRefVal);
				$ridVal = 'AF' . sprintf("%04d", $affRefVal);
				$affRIDTag->setAttribute('rid', preg_replace('/^ /', '', $ridVal));
				$affRef->parentNode->insertBefore($affRIDTag, $affRef);
            }
        }
        //$affRef->setAttribute('rid', preg_replace('/^ /', '', $ridVal));
		$affRef->parentNode->removeChild($affRef);
    }
	
    $index = 1;
	//$publications = $XPath->query('//div[@type="publication"]');
	//foreach($publications as $publication){
		
		$contents = $XPath->query('//div[@type="content"]');
		
		foreach($contents as $abstractSection){
			//remove withdraw
			$articleTitle = $XPath->query('.//*[@class="AbsTitle"]', $abstractSection);
			if($articleTitle->length > 0){
				$articleTitle = $articleTitle->item(0);
				if(preg_match('/^[A-Z\d\-\s\x{00A0}]*WITHDRAWN$/ui', $articleTitle->nodeValue)){
					//echo $articleTitle->nodeValue.'<br/>';
					$abstractSection->parentNode->removeChild($abstractSection);
					//echo '<pre>' . $abstractSection->innerHTML.'</pre>';
					continue;
				}
			}
			
			//add doi
			$text = '10.1136/heartjnl-2014-307109.'.($index);
			$doi = $doc->createElement('p');
			$doi->setAttribute('class','AbsDoi');
			$textNode = $doc->createTextNode($text);
			$doi->appendChild($textNode);
			$contentFirstChild = $XPath->query('.//h3|.//p[@class="AbsPara"]',$abstractSection);
			if($contentFirstChild->length > 0){
				$contentFirstChild->item(0)->parentNode->insertBefore($doi, $contentFirstChild->item(0));
				//echo $text.'<br>';
				$index++;
			}
			
			
			
			$abstractSection->setAttribute('class','Abstract');
			
			// group all affiliations
			$absAffElements = $XPath->query('./p[@class="AbsAff"]',$abstractSection);
			// Create the new element
			$absAffGroup = $doc->createElement('div');
			$absAffGroup->setAttribute('class', 'AbsAffGroup');
			// Insert the new element
			foreach ($absAffElements as $absAffIndex => $absAffElement ) {
				if ($absAffIndex == 0){
					$absAffElement->parentNode->insertBefore($absAffGroup, $absAffElement);
				}
				$absAffElement->setAttribute('id', 'AF' . sprintf("%04d", $absAffIndex + 1));
				$absAffGroup->appendChild($absAffElement);
			}
			
			// group all Abstract Body Elements
			$absBodyElements = $XPath->query('./p[@class="AbsDoi"]/following-sibling::*',$abstractSection);
			// Create the new element
			$absBody = $doc->createElement('div');
			$absBody->setAttribute('class', 'AbsBody');
			// Insert the new element
			$absBodyElementName = ""; $absBodyElementClass = "";
			$sec = $doc->createElement('sec1');
			foreach ($absBodyElements as $absBodyIndex => $absBodyElement ) {
				if ($absBodyIndex == 0){
					$absBodyElement->parentNode->insertBefore($absBody, $absBodyElement);
					$absBody->appendChild($sec);
				}
				$absBodyElementName = $absBodyElement->nodeName;
				$absBodyElementClass = $absBodyElement->getAttribute('class');
				if (($absBodyElementName == 'h3') && ($absBodyElementClass == 'AbsHead')){
					$sec = $doc->createElement('sec');
					$absBody->appendChild($sec);
				}
				if (($absBodyElementName == 'div') && ($absBodyElementClass == 'H3Group')){
					$sec = $doc->createElement('sec');
					$absBody->appendChild($sec);
				}
				if (($absBodyElementName == 'div') && ($absBodyElementClass == 'H3Group dontsplit')){
					$sec = $doc->createElement('sec');
					$absBody->appendChild($sec);
				}
				if (($absBodyElementName == 'h3') && ($absBodyElementClass == 'AbsRefHead')){
					$sec = $doc->createElement('sec');
					$absBody->appendChild($sec);
				}
				if ($absBodyElementClass == 'AbsKeywordHead'){
					$sec = $doc->createElement('kwd-group');
					$absBody->appendChild($sec);
				}
				if (($absBodyElementName == 'p') && ($absBodyElementClass == 'AbsPara') && ($sec->nodeName == 'sec1')){
					$sec = $doc->createElement('sec');
					$absBody->appendChild($sec);
				}
				$sec->appendChild($absBodyElement);
			}
			
			
			$keywordElements = $XPath->query('./*[@class="AbsKeywordHead"]|./p[@class="AbsKeywordPara"]', $abstractSection);
			// Create the new element
			$keywordGroup = $doc->createElement('div');
			$keywordGroup->setAttribute('class', 'jrnlKeyword');
			// Insert the new element
			foreach ($keywordElements as $keyElementIndex => $keywordElement ) {
				if ($keyElementIndex == 0){
					$keywordElement->parentNode->insertBefore($keywordGroup, $keywordElement);
				}
				$keywordGroup->appendChild($keywordElement);
			}
			
			$affRefs = $XPath->query('.//p[@class="AbsKeywordPara"]', $abstractSection);
			foreach($affRefs as $affRef){
				$affRefValArray = preg_split('/\s?,\s?/', $affRef->nodeValue);
				$affRefParent = $affRef->parentNode;
				$affRefPatentNodeVal = $affRefParent->nodeValue;
				foreach ($affRefValArray as $affRefVal){
					$newAffRef = $doc->createElement('span', $affRefVal);
					$newAffRef->setAttribute('class', 'jrnlKeyword');
					$affRefParent->insertBefore($newAffRef, $affRef);
				}
				$affRef->parentNode->removeChild($affRef);
			}
			
			$absFloats = $XPath->query('.//p[@class="AbsFigCaption"]', $abstractSection);
			foreach($absFloats as $absIndex => $absFloat){
				// Create the new element
				$abstractFig = $doc->createElement('div');
				$abstractFig->setAttribute('class', 'AbsFigBlock');
				// Insert the new element
				$absFloat->parentNode->insertBefore($abstractFig, $absFloat);
				$newnode = $abstractFig->appendChild($absFloat);
				$absFigLabels = $XPath->query('./span[@class="label"]',$absFloat);
				foreach ($absFigLabels as $absFigLabel){
					$absFloat->parentNode->insertBefore($absFigLabel, $absFloat);
					$figLabelValue = $absFigLabel->nodeValue;
					$figLabelValue = preg_replace('/.*Figure (\d+)$/', 'F$1', $figLabelValue);
					$absFloat->parentNode->setAttribute('id', $figLabelValue);
				}
				$absFloatValue = $absFloat->nodeValue;
				$absFloatValue = preg_replace('/^\s*/', '', $absFloatValue);
			}
			
			$absTabFloats = $XPath->query('.//table', $abstractSection);
			foreach($absTabFloats as $absIndex => $absTabFloat){
				// Create the new element
				$abstractTbl = $doc->createElement('div');
				$abstractTbl->setAttribute('class', 'AbsTblBlock');
				// Insert the new element
				$absTabFloat->parentNode->insertBefore($abstractTbl, $absTabFloat);
				$newnode = $abstractTbl->appendChild($absTabFloat);
				$continue = 1;
				while ($continue == 1){
					$nextSibling = $abstractTbl->nextSibling;
					if ($nextSibling){
						$nextSiblingName = $nextSibling->nodeName;
						if ($nextSiblingName == '#text'){
							$continue = 0;
							//$abstractSection->appendChild($nextSibling);
						}else{
							if($nextSibling->nodeType == 1) $nextSiblingClassName = $nextSibling->getAttribute('class');
							else $nextSiblingClassName  = '';
							if (($nextSiblingClassName == 'tblfn') || ($nextSiblingClassName == 'AbsTblFoot')){
								$abstractTbl->appendChild($nextSibling);
							}else{$continue = 0;}
						}
					}else{$continue = 0;}
				}
			}
			
			$theads = $XPath->query('.//thead', $abstractSection);
			foreach ($theads as $thead){
				$rows = $XPath->query('./tr', $thead);
				$rCnt = $rows->length;
				if ($rCnt > 0){
					$row = $rows->item(0);
					$columns = $XPath->query('./td|./th', $row);
					$colCnt = 0;
					foreach ($columns as $col){
						if ($col->hasAttribute('colspan')) {
							$colSpan = $col->getAttribute('colspan');
							$colCnt = $colCnt + $colSpan;
						}else{$colCnt = $colCnt + 1;}
					}
				}
				foreach ($rows as $row){
					$newRow = $doc->createElement('tr');
					$row->parentNode->insertBefore($newRow, $row);
					$newRow->parentNode->insertBefore($row, $newRow);
					$newRow->innerHTML = '<th colspan="' . $colCnt .'"><hr/></th>';
				}
			}///***end of thead tr***//
			
			$absTblCaptions = $XPath->query('.//p[@class="AbsTblCaption"]', $abstractSection);
			foreach($absTblCaptions as $absIndex => $absTblCaption){
				// Create the new element
				// Insert the new element
				$continue = 1;
				while ($continue == 1){
					$nextSibling = $absTblCaption->nextSibling;
					if ($nextSibling){
						$nextSiblingName = $nextSibling->nodeName;
						if ($nextSiblingName == '#text'){
							$continue = 0;
							//$abstractSection->appendChild($nextSibling);
						}else{
							$nextSiblingClassName = $nextSibling->getAttribute('class');
							if (($nextSiblingName == 'div') && ($nextSiblingClassName == 'AbsTblBlock')){
								$absTbl = $nextSibling->firstChild;
								$absTbl->parentNode->insertBefore($absTblCaption, $absTbl);
								$continue = 0;
							}else{$continue = 0;}
						}
					}else{$continue = 0;}
				}
				$parentNode = $absTblCaption->parentNode;
				$parentNodeClassName = $parentNode->getAttribute('class');
				if (($parentNodeName != 'div') && ($parentNodeClassName != 'AbsTblBlock')){
					$abstractTbl = $doc->createElement('div');
					$imgNodes = $XPath->query('.//img', $absTblCaption);
					if ($imgNodes->length != 0){
						$abstractTbl->setAttribute('class', 'AbsFigBlock');
					}else{
						$abstractTbl->setAttribute('class', 'AbsTblBlock');
					}
					// Insert the new element
					$absTblCaption->parentNode->insertBefore($abstractTbl, $absTblCaption);
					$newnode = $abstractTbl->appendChild($absTblCaption);
				}
			
				$absTblLabels = $XPath->query('./span[@class="label"]',$absTblCaption);
				foreach ($absTblLabels as $absTblLabel){
					$absTblCaption->parentNode->insertBefore($absTblLabel, $absTblCaption);
					$tblLabelValue = $absTblLabel->nodeValue;
					$tblLabelValue = preg_replace('/.*Table (\d+)$/', 'T$1', $tblLabelValue);
					$absTblCaption->parentNode->setAttribute('id', $tblLabelValue);
				}
				$absTblCaptionValue = $absTblCaption->nodeValue;
				$absTblCaptionValue = preg_replace('/^\s*/', '', $absTblCaptionValue);
				//$absTblCaption->innerHTML = $absTblCaptionValue;
			}
		}
	//}
	
	//remove spaces in attribute ID
	$IDNodes = $XPath->query('//*[@id or @rid]');
	foreach($IDNodes as  $IDNode){
		if($IDNode->hasAttribute('id')){
			$idValue = preg_replace('/\s/','_',$IDNode->getAttribute('id'));
			$idValue = preg_replace('/\.$/','',$idValue);
			$IDNode->setAttribute('id', $idValue);
		}else {
			$idValue = preg_replace('/\s/','_',$IDNode->getAttribute('rid'));
			$idValue = preg_replace('/\.$/','',$idValue);
			$IDNode->setAttribute('rid', $idValue);
		}
	}
	
	//move <kwd-group> outside <abstract>
	$abstracts  = $XPath->query('//div[@class="Abstract"]'); 
	foreach($abstracts as $abstract){
		$kwdGroups = $XPath->query('.//kwd-group', $abstract);
		if($kwdGroups->length < 1){
			continue;
		}
		$abstract->appendChild($kwdGroups->item(0));
		//$kwdGroups->item(0)->parentNode->insertBefore($abstract, $kwdGroups->item(0));
		
	}
	
	/* list tag for references with serial no
	example
	<sec><title>References</title><p>1. ICH Q5E: Comparabil...</p><p>2. Schneide...</p>
	as
	<sec><title>References</title><list list-type="order"><list-item><p>ICH Q5E: Comparabil...</p>..... */
	foreach($XPath->query('//h3[@class="AbsRefHead"]') as $heading){
		if(preg_match('/^ref[a-z]+$/i', $heading->nodeValue)){ //get reference title
			$list = $doc->createElement('list');
			$list->setAttribute('list-type', 'order');
			$listTagAdded = false;
			$absRefText = $heading->nextSibling;
			while($absRefText){
				if($absRefText->nodeType == 1 && $absRefText->hasAttribute('class') && $absRefText->getAttribute('class') == 'AbsRefText'){
					if(!$listTagAdded){
						$absRefText->parentNode->insertBefore($list, $absRefText); //add list node
						$listTagAdded = true;
					}
					$slno = $XPath->query('.//span[@class="RefSlNo"]', $absRefText); //remove serial number node
					if($slno->length > 0){
						$slno->item(0)->parentNode->removeChild($slno->item(0));
					}
					
					
					$listItem = $doc->createElement('list-item');  //add list item node
					$list->appendChild($listItem);
					$nextSibling = $absRefText->nextSibling;
					$listItem->appendChild($absRefText);
					$absRefText = $nextSibling;
				}else {
					break;
				}
			}
		}
	}
	
	//senetence  case for abs title
	foreach($XPath->query('//h2[@class="AbsTitle"]') as $absTitle){
		$childNodes = $absTitle->childNodes;
		$ucfirstDone = false;
		foreach($childNodes as $childNode){
			if($childNode->nodeType == 1){
				if($childNode->hasAttribute('class') &&  $childNode->getAttribute('class') == 'AbsNumber'){
					continue;
				}else {
					if(!$ucfirstDone){
						$childNode->nodeValue = ucfirst(strtolower($childNode->nodeValue));
						$ucfirstDone = true;
					}else {
						$childNode->nodeValue = strtolower($childNode->nodeValue);
					}
				}
			}else if($childNode->nodeType == 3){
				if(!$ucfirstDone){
					$childNode->nodeValue = ucfirst(strtolower($childNode->nodeValue));
					$ucfirstDone = true;
				}else {
					$childNode->nodeValue = strtolower($childNode->nodeValue);
				}
			}
		}
	}
	
    
    //echo $url . '<br/>';
    $url = str_replace('.htm', '.xml', $url);
	
    //$doc->save("E:\My Box Files\ExeterAuthoringSystem\jobs\ExportToXML\posters_output.xml");
    //$doc->save($url);
	$processedData = $doc->saveXML();
    $processedData = str_replace('<?xml version="1.0" standalone="yes"?>', '<?xml version="1.0" encoding="utf-8"?>', $processedData);
    $processedData = str_replace('<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">', '', $processedData);
    //$processedData = str_replace('<!DOCTYPE article PUBLIC "-//NLM//DTD Journal Publishing DTD v2.3 20070202//EN" "C:/Documents and Settings/kanna/Desktop/journal-publishing-dtd-2.3/journalpublishing.dtd">', '', $processedData);
    $processedData = str_replace('<?xml version="1.0" encoding="utf-8"??>', '', $processedData);
    if ($url){
    	$url = str_replace('.xml', '_output.xml', $url);
    	file_put_contents($url, $processedData, null, $context);
		//chmod( $url, 0777);

    }
	
    //echo $url.'<br>';
    
	$xsl = new DOMDocument();
    $xsl->load("updatedXSL.xsl");
    //$xsl->load("D:/PhP/ihcJournalsHTML2XML.xsl");

    $proc = new XSLTProcessor();
    $xsl = $proc->importStylesheet($xsl);
    //$proc->setParameter(null, "", "");

    $newdom = $proc->transformToDOC($doc);

    $processedData = $newdom->saveXML();
    $processedData = str_replace('<?xml version="1.0" standalone="yes"?>', '<?xml version="1.0" encoding="utf-8"?>', $processedData);
    $processedData = str_replace('<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">', '', $processedData);
    $processedData = str_replace('<?xml version="1.0" encoding="utf-8"??>', '', $processedData);
    $processedData = str_replace('<!DOCTYPE article PUBLIC "-//NLM//DTD Journal Publishing DTD v2.3 20070202//EN" "journal-publishing-dtd-2.3\journalpublishing.dtd">', '<!DOCTYPE article PUBLIC "-//NLM//DTD Journal Publishing DTD v2.3 20070202//EN" "C:/Documents and Settings/kanna/Desktop/journal-publishing-dtd-2.3/journalpublishing.dtd">', $processedData);
    if ($url){
        $url = str_replace('_output.xml', '_final.xml', $url);
        file_put_contents($url, $processedData, null, $context);
		//chmod( $url, 0777);
    }
    
 
  //force download output file
	header('Content-Type: application/octet-stream');
	header("Content-Transfer-Encoding: Binary"); 
	header("Content-disposition: attachment; filename=\"" . basename($downloadFileName) . "\""); 
	readfile($downloadFileName); 
	$removeFiles = array('updatedXSL.xsl', $uploadedFileName, $tempFileName, $downloadFileName);
	foreach($removeFiles as $removeFile){
		//unlink($removeFile);
	} 
	exit;
    //http://stackoverflow.com/questions/4675460/php-dom-remove-element-leave-contents
    /*
     *   function to remove the node sent as argument and retain its children
    */
    function DOMRemove(DOMNode $from) {
    	$sibling = $from->firstChild;
    	do {
    		$next = $sibling->nextSibling;
    		if ($sibling != null){
    			$from->parentNode->insertBefore($sibling, $from);
    		}
    	} while (($sibling != null) && ($next != null) && ($sibling = $next));
    	$from->parentNode->removeChild($from);
    }
    
    
?>
