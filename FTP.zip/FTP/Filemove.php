<html>

<style>
.tableheader {
  background-color: #0EB9CA;
  color:white;
  font-weight:bold;
}
.tablerow {
  background-color: #142852;
  color:white;
}
.message {
  color: #FF0000;
  font-weight: bold;
  text-align: center;
  width: 100%;
  padding: 10;
}

.h3{
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  color:#142852;
}
</style>
<!-- Image setting on browser tab-->
<link rel="icon" href="favicon-new-32x32.png"></link>


<?php if (!empty($_POST)) {
ini_set('max_execution_time', 0);	
/* Updated by Deepika on 02-08-2021*/
// ftp details
$server = 'exeterpremedia.exavault.com';
$ftp_user_name = 'client40';
$ftp_user_pass = 'cL!3nT40bmJ';
$folder_name =  $_POST['folder_name'];

$src_dir = str_ireplace("\\", "/", $_POST['src_dir']);
//echo $src_dir;
$parent_dir = explode("/", $src_dir);
$parent_dir_name = $parent_dir[count($parent_dir)-1];
//echo $parent_dir_name; die;


// config from input excel data
$maping = array('THE BMJ'=>array('/BMJ Local Editions/Medicom/The BMJ','/BMJ Local Editions/IMed Korea/The BMJ','/BMJ Local Editions/Continuing Medical Communication/The BMJ','/BMJ Local Editions/CCM/The BMJ','/BMJ Local Editions/Anejo Producciones S.A./The BMJ','/BMJ Local Editions/Chinese Medical Association/The BMJ','/BMJ Local Editions/National Talking Newpapers and Books/The BMJ','/BMJ Local Editions/RNIB/The BMJ','/BMJ Local Editions/Tarus/The BMJ'), 
				'GUT'=>array('/BMJ Local Editions/Medicom/Gut','/BMJ Local Editions/Focus-Insight/Gut','/BMJ Local Editions/MNCS Systems/Gut','/BMJ Local Editions/ContentEd/Gut','/BMJ Local Editions/Blackwell Wiley/Gut'),
				'BJO'=>array('/BMJ Local Editions/CCM/British Journal of Ophthalmology'),
				'ARD'=>array('/BMJ Local Editions/Continuing Medical Communication/Annals of the Rheumatic Diseases','/BMJ Local Editions/Infomedica/Annals of the Rheumatic Diseases','/BMJ Local Editions/Questis/Annals of the Rheumatic Diseases'),
				'Thorax'=>array('/BMJ Local Editions/Continuing Medical Communication/Thorax','/BMJ Local Editions/Medjournal/Thorax','/BMJ Local Editions/Focus-Insight/Thorax Local Edition'),
				'BJSM'=>array('/BMJ Local Editions/Focus-Insight/BJSM'),
				'Heart'=>array('/BMJ Local Editions/Medicom/Heart','/BMJ Local Editions/IMed Korea/Heart', '/BMJ Local Editions/Medjournal/Heart'),
				'ADC'=>array('/BMJ Local Editions/Medjournal/ADC'),
				'IP'=>array('/BMJ Local Editions/Medjournal/In Practice'),
				'JNNP'=>array('/BMJ Local Editions/Medjournal/JNNP'),
				'PN'=>array('/BMJ Local Editions/Medjournal/Practical Neurology'),
				'EBM'=>array('/BMJ Local Editions/Technomics/Evidence-Based Medicine'),
				'EBMENTAL'=>array('/BMJ Local Editions/Technomics/Evidence-Based Mental Health'),
				'EJHP'=>array('/BMJ Local Editions/Continuing Medical Communication/EJHP'),
				'EMJ'=>array('/BMJ Local Editions/Continuing Medical Communication/EMJ'),
				'VETREC'=>array('/BMJ Local Editions/Medjournal/Veterinary Record')
);

$conn_id  = ftp_connect($server);
$login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);
$dst_dirs = $maping[$folder_name];
foreach($dst_dirs as  $dst_dir) {
	$new_dst_dir = $dst_dir . "/" . $parent_dir_name;
	echo 'Folder copied to ' . $new_dst_dir . '<br>';
	ftp_putAll($conn_id, $src_dir, $new_dst_dir);
}
}

else { ?>
<div>
	<form enctype="multipart/form-data" method="post" action="Uploadlocal.php">
		<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
			<tr class="h3">
				<td align="left" colspan="2"><img src="kriyadocsTrademark.png" alt="img" style="width:25%;"></td>
			</tr>
			<tr class="tableheader">
				<td align="center" colspan="4">Uploading the ZIP file to the Local</td>
			</tr>
			<tr class="tablerow">
				<td align="center" colspan="4">
				<label>Choose a zip file to upload: <input type="file" name="zip_file" /></label>
				<br />
				</td>
			</tr>
			<tr class="tableheader">
				<td align="center" colspan="2"><input type="submit" name="submit" value="Upload ZIP File"></td>
			</tr>
		</table>
	</form>
	<form action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> method="post">
  	<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
    <tr class="tableheader">
		<td align="center" colspan="2">BMJ Local Edition - FTP Transfer</td>
	</tr>
  	<tr class="tablerow">
    	<td align="right">Select the folder</td>
    	<td>
     		<select id="folder_name" name="folder_name">
				<option value="THE BMJ">THE BMJ</option>
				<option value="GUT">GUT</option>
				<option value="BJO">BJO</option>
				<option value="ARD">ARD</option>
				<option value="Thorax">Thorax</option>
				<option value="BJSM">BJSM</option>
				<option value="Heart">Heart</option>
				<option value="ADC">ADC</option>
				<option value="IP">IP</option>
				<option value="JNNP">JNNP</option>
				<option value="PN">PN</option>
				<option value="EBM">EBM</option>
				<option value="EBMENTAL">EBMENTAL</option>
				<option value="EJHP">EJHP</option>
				<option value="EMJ">EMJ</option>
				<option value="VETREC">VETREC</option>
    		</select>
  		</td>
  		</td>
	</tr>
	<tr class="tablerow">
		<td align="right">Enter Source Path</td>
		<td><input type="text" name="src_dir"></td>
	</tr>
	<tr class="tableheader">
		<td align="center" colspan="2"><input type="submit" name="submit" value="Upload"></td>
	</tr>
	</table>
  	</form>
</div>
<div>
	<form enctype="multipart/form-data" method="post" action="delete.php">
		<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
		<tr class="tablerow">
			<td align="center" colspan="2">Delete the local files from the System</td>
		</tr>
		<tr class="tableheader">
			<td align="center" colspan="2"><input type="submit" name="delete" value="Delete ZIP File"></td>
		</tr>
		</table>
	</form>
</div>
<?php } ?>
</body>
</html>
<?php 
function ftp_putAll($conn_id, $src_dir, $dst_dir) {
	$d = dir($src_dir);
	while($file = $d->read()) { // do this for each file in the directory
		if ($file != "." && $file != "..") { // to prevent an infinite loop
			if (is_dir($src_dir."/".$file)) { // do the following if it is a directory
				if (!@ftp_chdir($conn_id, $dst_dir."/".$file)) {
					ftp_mkdir($conn_id, $dst_dir."/".$file); // create directories that do not yet exist
				}
				ftp_putAll($conn_id, $src_dir."/".$file, $dst_dir."/".$file); // recursive part
			} else {
				$upload = ftp_put($conn_id, $dst_dir."/".$file, $src_dir."/".$file, FTP_BINARY); // put the files
			}
		}
	}
	$d->close();
}
?>