console.log("Date");

let today = new Date();

// today = new Date(2012,5,12,11,20,5,0);


console.log(today);

// console.log(today.toDateString());
// console.log(today.toString());
// // console.log(today.toString().split(' '));

// console.log(today.getDate());
// console.log(today.getDay());
// console.log(today.getHours());
//.getTime() return milliseconds from Jan 1 1970
// console.log(today.getTime());
console.log(today.setDate(21));
console.log(today.setMonth(7));
console.log(today);
