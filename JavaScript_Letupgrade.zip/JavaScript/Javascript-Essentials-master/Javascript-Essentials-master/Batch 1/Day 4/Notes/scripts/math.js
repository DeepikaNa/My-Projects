console.log("Math Object")

//Math.min
// console.log(Math.min(1,2,3,4,5));

// console.log(Math.max(1,2,3,4,5));

// console.log(Math.pow(10,3))

// console.log(Math.abs(-5))

// console.log(Math.sqrt(10));

// console.log(Math.PI);

// console.log(Math.PI * Math.pow(2,2))


// let num = 52.6578;

// console.log(Math.round(num))
// console.log(Math.ceil(num))
// console.log(Math.floor(num))

// console.log(num.toFixed(10))

// Math.random()
// It wil generate a number between 0 to 1 (1 is excluded)

console.log(Math.random());

// Number between 0-9
console.log(Math.floor(Math.random()*10));

// Number from 1-10
console.log(Math.floor(Math.random()*10)+1)


// min, max
// To generate a random number between min(included) & max(excluded)
// console.log(Math.floor(Math.random()*(max-min))+min)
console.log(Math.floor(Math.random()*(10-1))+1)


// To generate a random number between min(included) & max(included)
// console.log(Math.floor(Math.random()*(max-min+1))+min)
console.log(Math.floor(Math.random()*(25-10+1))+10)