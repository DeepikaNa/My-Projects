// alert("Click me to Proceed");
console.log("hey I am a javascript code");

// Comments in javascript
// Single line comments are written using //
// Multine Comments are written using /* */

/*console.log("Hello");
console.log("Hello");
console.log("Hello");
console.log("Hello");*/

var a = {name:"Prasad", age:"24", city:"Mexico"}
var b = {name:"Sai Sir", age:"24", city:"Mexico"}
var c = {name:"Viral Sir", age:"24", city:"Mexico"}

console.time('Time taken');
console.log("Hey")
console.error("an error occured!");
console.warn("Hey this is a warning!!");
// console.log(a);
// console.log(b);
// console.log(c);
// console.log({a ,b ,c})
console.table({a ,b ,c})
console.log('%c Custom message','color:blue;')
console.timeEnd('Time taken');

