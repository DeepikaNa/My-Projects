console.log("Unary , binary, operand");

// let x = 10;

// x = -x;
// console.log(x);

// let y = 5;

// console.log(x-y)


/*
1. Addition + 
2. Subtraction - 
3. Multiplication * 
4. Division /
5. Remainder %
6. Exponent **
*/

console.log( 2 + 3 );
console.log( 2 - 6 );
console.log( 2 * 3 );
console.log( 4 / 2 );
console.log( 12 % 5 );
console.log(6 ** 2);


console.log( 1 + '2' );
console.log( '1' + 2 );
console.log(10 + 20 + '5');


console.log(1 - '2');
console.log('6' / '3');

let x;
let y;
let z;

x = y = z = 'LetsUpgrade';
console.log(x,y,z)

let n = 5;
// n = n + 1;.
n += 1;
// n =+ 1;
console.log(n)

let p = 5;
p -= 1;
console.log(p)

