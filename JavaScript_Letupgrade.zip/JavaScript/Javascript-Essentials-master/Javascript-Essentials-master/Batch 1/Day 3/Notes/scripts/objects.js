console.log("Objects")


// let name = { key : value }

let person = {
    name:'Professor',
    skills: ['planning','mind games'],
    teamCount:8,
    canFly:false,
};

console.log(person)

console.log(person.name);
console.log(person['skills']);

