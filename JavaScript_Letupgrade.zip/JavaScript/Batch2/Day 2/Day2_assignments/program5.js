// 5) reverse the array
let x=prompt("enter size of the array");
let a=new Array();
for(var i=0;i<x;i++)
{
	a[i]=prompt("enter the data need to reverse");
}
let b=new Array();
b=a.reverse();
for( i=0;i<x;i++)
{
	console.log(b[i]);
}