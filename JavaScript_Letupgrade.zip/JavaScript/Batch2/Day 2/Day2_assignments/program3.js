// 3) Program to search for a element in a array of strings
  
let input = prompt("enter size");
let a = new Array();
for(let i = 0; i<input; i++){
     a[i] = prompt("enter the string");
}
let finder = prompt("enter the data need to be search:");
let output = input.indexOf(finder);
if(output==-1)
{
    console.log(finder+ " data is present")
}
else{
    console.log("data is not present " +output);
}