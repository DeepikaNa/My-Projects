// let avenger ={
//     name:"Deepik",
//     age:"500"

// };
// let key = "name";
// let dynamickey = "age";
//console.log(avenger);
//console.log(`The name ${avenger.name} and age is ${avenger.age}`);// templating 
//console.log(avenger["name"]);// Access the object elemnts
// console.log(avenger[key]);
// console.log(avenger["name"]);
// console.log(avenger[dynamickey]);
//console.log(avenger.dynamickey); -- undefined

// let avenger ={
//     name:"Deepik",
//     age:500,
//     weapons: ["mjoin", "thuder", "strom"],  //array an object
//     address:{
//         planet:"mars",                    // objectt inside object
//         home:"APS",
//     },
// };
// console.log(avenger.address.home);
// // avenger.weapons.forEach(function (weapons) {
// //     console.log(weapons);
// // });


// let avenger ={
//     name:"Deepik",
//     age:500,
//     weapons: ["mjoin", "thuder", "strom"],  //array an object
//     address:{
//         planet:"mars",                    // object inside object
//         home:"APS",
//     },
//     printWeapon:function(){
//         //console.log(this);// curent object
//         //console.log(this.weapons);// access inside the objects(this refere to avenger here)
//         // console.log(this.address);
//         // console.log(this);- Entire object will display
//         this.weapons.forEach(function(weapons){
//             console.log(weapons);
//         });
//         console.log(this.age);
//     },
// };
// //console.log(avenger.weapons);//access outside the objects
// avenger.printWeapon();
// console.log(avenger.address.home);

// Array of objects

// let avengers =[
//     {
//         name :"thor",
//         age : 13,
//     },
//     {
//         name :"Sheepoe",
//         age : 1345,
//     },
//     {
//         name :"tprdfor",
//         age : 133445,
//     },
// ];
// for (let i=0;i<=avengers.length;i++){
// console.log(avengers[i].name);
// }
// //console.log(avengers[1]);

// // avengers.forEach(function (avengers)
// // {
// //     console.log(avengers.name);
// // });

demo={
    name: "LAptop",
    printName:function(){
        console.log(this);
    }
    // printName: () => {
    //     console.log(this);  // in arrow thiswill not give current object
    // },
};


demo.printName();
























