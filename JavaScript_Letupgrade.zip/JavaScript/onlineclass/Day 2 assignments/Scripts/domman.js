// window // window is inbuilt- act  like parent

// child of window
// console
// document
// screen

// console.log("jhegur");
// window.console.log("kskhhdv");
//window.alert("jerlll");// functions of window
//alert("smbdhd"); // just show message to user
// prompt -take the input from the user
// let na = prompt('smmhidshf');
// console.log(na);
// let a = confirm("do you wnt to continue");
// if(a== false)
// {
//     console.log("pik");
// }
// else{
//     //window.location = "http://www.google.co.in"; // bring to page provide to the location
//     location = "http://www.google.co.in";
// }

// How to fetch element by tag name- will provide result in array
// const docu = document.getElementsByTagName("p");
// console.log(docu);


// How to fetch element by class  name- will provide result in array(can have multiple class name with different values )
// const docu = document.getElementsByClassName("french");
// //console.log(docu[0]); // provide the tag with data <p class="french">hiii</p>
// console.log(docu); // HTMLCollection(2) [p.french, p.french] output

// How to fetch element by id- will provide result in array
// if you have multiple elements with same IDBCursor, browser will give first id only
// const docu = document.getElementById("s1");
// console.log(docu);

//by querying
// queryselector will give only 1 elemwnt as output

//const docu = document.querySelector("p");// by default it will take tag name -it will fetch only 1 element
//const docu = document.querySelector(".french") // fetching by classname
//const docu = document.querySelector("#spanish") // fetch bt id
// const docu = document.querySelector("h1") 
// console.log(docu); // <p class="english" id="s1"> hello</p>

// Using queryselectorAll can fetch multiple elements
// const docu = document.querySelectorAll("p") 
// console.log(docu); // NodeList(4) [p#s1.english, p#s2.french, p#spanish.random, p#s4.french]

// working with text
// const docu = document.getElementsByClassName("english")
// //console.log(docu[0].innerText); // hii
// let a = docu[0].innerText;
// console.log(a); // we are pronting from documents
//docu[0].innerText = "Anyting";   //console - History, browser le Anyting , then changed to browser(cahning the value)

// function doSomething()
// {
//     console.log("hello");
// }
// doSomething();

// function doSomething()
// {
//     const docu = document.getElementsByClassName("english")
//     let a = docu[0].innerText;
//     console.log(a);
// }
// doSomething();

// function doSomething()
// {
//     const docu = document.getElementsByClassName("english")
//     docu[0].innerText="JS Devp"
    
// }
// doSomething();

// function doSomething()
// {
//     const docu = document.getElementById("TP");
//     //docu.innerText="<h1>JS Devp</h1>" // output <h1>JS Devp</h1>
//     docu.innerHTML="<h1>JS Devp</h1>" // output will have the output in h1 
    
// }
// doSomething();

//Fetching text + html - value from inputs
function changeImage()
{
    const docu = document.getElementById("image");
    console.log(docu.id); // Will give id value as output
    //docu.innerText="<h1>JS Devp</h1>" // output <h1>JS Devp</h1>
   // docu.innerHTML="<h1>JS Devp</h1>" // output will have the output in h1 
    const newurl="google.co.in"
    docu.scr=newurl;
}

// function Printvalue()
// {
//     const docu = document.getElementsByClassName("name");
//     console.log(docu[0].value);
    
// }
// Printvalue();






















