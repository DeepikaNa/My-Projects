// let weapon ="streambreaker";
// console.log(weapon[3]); // Substrings
// Arrays
// let data = ["laptop","mouse","keyboard","monitor","speaker","ups"];
// let numbers = [23, 45, 65, 89];
// console.log(data[1]);
// console.log(data.slice(0 , 2));

// Control statements

// while- entry control loop
// let i=0;
// while(i<13){
//     console.log(i);
//     i++;
// }
// do while Exit control  loop
// let i = 6;
// do{
//     console.log(i);
//     i++
// }while(i<4);  //Output 6 , violiation error
// for
// for(let i=1; i<10; i++){
//     console.log(i);
// }
// post increment -- first execute operator
// let a = 3;
//  let b = a++;
//  console.log(b); // output 3

//  // pre increment--  first execute operand

//  let d = 5;
//  let e = ++d;
//  console.log(e); // output 6
// Forloop with arrays concept

//  let data = ["laptop","mouse","keyboard","monitor","speaker","ups","camera","canon"];
//  data.push('mic');
//  let numbers = [23, 45, 65, 89];
//  for(let i=0;i<data.length;i++)
//  {
// console.log(data[i]);
//  }
// let data = ["laptop","mouse","keyboard","monitor","speaker","ups","camera","canon"];
//  data.push('mic'); //data.push("mic")
//  let numbers = [23, 45, 65, 89];
//  for(let i=0;i<data.length;i++)
//  {
// console.log(data[i]);
//  }

// data.forEach(function(a){
//     console.log(a);
// });

// Booleans -returns true or false

// let a = 14;
// let b = 6;
// console.log(a == b); // false(4,5)
// console.log(a == b); // true(4,4)
// console.log(a>b);

// if(a<b){
//     console.log("hello"); // excute only when the condition is true
// }
// else{
//     console.log("check");
// }

// let grade =70;
// if(grade >= 70 && grade<= 50)
// {
//     console.log("Pass");
// }
// else if(grade>50){

//     console.log("Fails");
// }
// else{
//     console.log(" fialee")
// }


// class Demo{
//   static  int  a = 23;  //object will create and used for all the variables
//   int b = 98;

// }

// Demo d = new Demo();
// Demo b = new Demo();
// Demo e = new Demo();// normal variable will create object for every time, memory waste.


// undefined
// let a;
// console.log(a);

// Typecasting
// let number = Number("1.5");
// console.log(number);
// Tpecasting string to num
// let number = Number("erhfb");
// console.log(number);  // NaN Output