 let weapon ="streambreaker";
 console.log(weapon[3]); // Substrings
