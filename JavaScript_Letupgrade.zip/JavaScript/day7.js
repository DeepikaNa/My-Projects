// Set Interval---> called infinite times,user needs to stop
// let counter = 1;
// function doS(){
//     console.log("deepi");
//     counter++;
//     if(counter==10)
//     {
//         clearInterval(timer); // clearing the timer interval
//     }
// }
// let timer=setInterval("doS()", 1000);

// let data=[1,2,3,4]

// data.forEach(function(d){

// })

// Second method
// let timer=setInterval(function doS(){
//     let counter = 1; // call back function
//     console.log("deepi");
//     counter++;
//     if(counter==10)
//     {
//         clearInterval(timer); // clearing the timer interval
//     }
// }, 1000);


// SetTimeout-->Called only 1 once

function doS(){
    console.log("deepi");
}
let a = setTimeout("doS()", 6000);

clearTimeout(a);