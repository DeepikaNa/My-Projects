var fs = require("fs"),
    http = require('http');
    path = require('path');
    const excelToJson = require('convert-excel-to-json');
    var format = require('xml-beautifier');
const result = excelToJson({
    //sourceFile:  'D:/Deepika/BSAVA/ExcelToJats/input.xlsx'
    sourceFile:  'D:/Deepika/Projects/BSAVA/ExcelToJats/input.xlsx'
});

console.log("Completed");
for (var sheetname in result){
    for (var rowindex in result[sheetname]){
        if(rowindex == 0){
            continue;
        }
    var xmldata = '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE book PUBLIC "-//NLM//DTD BITS Book Interchange DTD v2.0 20151225//EN" "BITS-book2.dtd"><book xmlns:mml="http://www.w3.org/1998/Math/MathML" xmlns:xlink="http://www.w3.org/1999/xlink"><book-meta><book-id book-id-type="publisher-id">bsava</book-id><book-id book-id-type="doi">10.22233/9781913859008</book-id><subj-group subj-group-type="content-type"><subject>Proceedings</subject></subj-group><book-title-group><book-title>BSAVA Congress Proceedings 2021</book-title></book-title-group><pub-date><month>May</month><year>2021</year></pub-date><isbn content-type="epub">978-1-913859-00-8</isbn><publisher><publisher-name>British Small Animal Veterinary Association</publisher-name></publisher><edition>1st</edition><permissions><copyright-statement>© 2021 British Small Animal Veterinary Association</copyright-statement><copyright-year>2021</copyright-year><copyright-holder>British Small Animal Veterinary Association</copyright-holder></permissions><abstract><p>BSAVA is pleased to provide recordings of more than 170 lectures from its 2021 virtual Congress. Lectures consist of both ‘on-demand’ pre-recorded sessions and live-recorded sessions, which typically include two speakers presenting their viewpoints on the topic and followed by a recording of a live discussion or Q&A. Many lectures have additional resources, available via the Podcasts tab, providing further reading or other information. Most lectures are suitable for the whole practice team. You can purchase access to the full 2021 lecture package via the ‘buy online access’ button above, or you can buy an individual lecture by clicking on an individual lecture and purchasing access. If you have a library pass you can use this to access lectures – go to a lecture and click on the ‘use pass’ button. BSAVA members receive a discount on all purchases. See our<ext-link ext-link-type="uri" xlink:href="https://pages/congressondemand">Congress On Demand information page</ext-link>for more details of purchasing options. Please note that lecture recordings are as supplied by our virtual event provider.</p></abstract><counts><book-page-count count="1">1</book-page-count></counts></book-meta>'
    //var xmldata = "";
    xmldata+='<book-part book-part-type="chapter" specific-use="audio-video" id='+result[sheetname][rowindex]["A"]+'><book-part-id book-part-id-type="doi">10.22233/9781913859008.1</book-part-id>'
    xmldata+='<subj-group subj-group-type="chapter-section"><subject>'+result[sheetname][rowindex]["C"]+'</subject></subj-group>'
    xmldata+='<subj-group subj-group-type="chapter-stream-name"><subject>'+result[sheetname][rowindex]["D"]+'</subject></subj-group>'
    xmldata+='<subj-group subj-group-type="chapter-product-type"><subject>'+result[sheetname][rowindex]["E"]+'</subject></subj-group>'
    xmldata+='<subj-group subj-group-type="chapter-content-type"><subject>'+result[sheetname][rowindex]["F"]+'</subject></subj-group>'
    xmldata+='<subj-group subj-group-type="chapter-index-type"><subject>'+result[sheetname][rowindex]["G"]+'</subject></subj-group>'
    xmldata+='<subj-group subj-group-type="topic-type"><subject>'+result[sheetname][rowindex]["H"]+'</subject></subj-group>'
    xmldata+='<subj-group subj-group-type="resource-type"><subject>'+result[sheetname][rowindex]["I"]+'</subject></subj-group>'
    xmldata+='<subj-group subj-group-type="animal-type"><subject>'+result[sheetname][rowindex]["J"]+'</subject></subj-group>'
    xmldata+='<title-group><title>'+result[sheetname][rowindex]["K"]+'</title></title-group>'
    xmldata+='<subj-group subj-group-type="animal-type"><subject>'+result[sheetname][rowindex]["J"]+'</subject></subj-group>'
    xmldata+='<contrib-group><contrib>'
    xmldata+='<name><surname>'+result[sheetname][rowindex]["L"].split(" ")[1]+'</surname><given-names>'+result[sheetname][rowindex]["L"].split(" ")[0]+'</given-names></name>'
    xmldata+='</contrib></contrib-group>'
    xmldata+='<pub-date><year>'+result[sheetname][rowindex]["N"]+'</year></pub-date>'
    xmldata+='<elocation-id>'+result[sheetname][rowindex]["B"]+'</elocation-id>'
    xmldata+='<permissions><copyright-statement>© 2021 British Small Animal Veterinary Association</copyright-statement><copyright-year>2021</copyright-year><copyright-holder>British Small Animal Veterinary Association</copyright-holder></permissions>'
    xmldata+='<abstract><p>'+result[sheetname][rowindex]["M"]+'</p></abstract>'
    xmldata+='<custom-meta-group><custom-meta><meta-name>elocation-id</meta-name><meta-value>e1</meta-value></custom-meta></custom-meta-group>'
    xmldata+='</book-part-meta>'
    xmldata+='<back>'
    xmldata+='<sec><title/><supplementary-material xmlns:xlink="http://www.w3.org/1999/xlink" xlink:title="local_file" xlink:href="'+result[sheetname][rowindex]["O"]+'" mimetype="application/video/mp4">'
    xmldata = format(xmldata);// this line for giving indentation in xml file
    console.log(xmldata);
    fs.writeFile('D:/Deepika/Projects/BSAVA/ExcelToJats/outputBSAVA.xml', [xmldata], function (data, err){
        if(err) console.log(err);
        if(!err)console.log("success");
    });
 }
}

 console.log("Completed12");


    http.createServer(function (req, res) {

    }).listen(5555);
