 var xslt = require("xslt-processor");
 
 var xsltProcessor = new XSLTProcessor();

  // Load the xsl file using synchronous (third param is set to false) XMLHttpRequest
  var myXMLHTTPRequest = new XMLHttpRequest();
  myXMLHTTPRequest.open("GET", "D:/Deepika/BSAVA/ExcelToJats/Congress_proceedings_2021_FINAL_060521__1_ .xlsx", false);
  myXMLHTTPRequest.send(null);

  var xslRef = myXMLHTTPRequest.responseXML;

  // Finally import the .xsl
  xsltProcessor.importStylesheet(xslRef);
   // create a new XML document in memory
   var xmlRef = document.implementation.createDocument("", "", null);

   // we want to move a part of the DOM from an HTML document to an XML document.
   // importNode is used to clone the nodes we want to process via XSLT - true makes it do a deep clone
   var myNode = document.getElementById("example");
   var clonedNode = xmlRef.importNode(myNode, true);
 
   // add the cloned DOM into the XML document
   xmlRef.appendChild(clonedNode);
   var parser = new DOMParser();
   var doc = parser.parseFromString(aStr, "text/xml");
   var fragment = xsltProcessor.transformToFragment(xmlRef, document);
