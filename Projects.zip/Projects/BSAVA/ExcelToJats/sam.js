var xlsxrd = require("node-xlsx");
var _ = require("./lib/underscore-min.js");
var fs = require('fs');
var xml2js = require('xml2js');
//excel file name, the test case document under the Excel folder of the parent directory
var excelFilePath = 'Congress_proceedings_2021_FINAL_060521__1_ .xlsx';
var xmlFilePath = '../excel/xmlCase.xml';
 
 //Analyze the attribute value of the xml structure
var parser = new xml2js.Parser({
        explicitArray: false,
        attrkey:'$',
        trim:false,
        childkey:'$$',
        attrNameProcessors: null,
        attrValueProcessors:null
    });
         //Build the structure of the xml file
 
    // jons -> xml
var jsonBuilder = new xml2js.Builder({
      rootName:'testsuite',
      cdata: true,
      renderOpts: { 'pretty': true, 'indent': '', 'newline': '\n' },
      xmldec:{
          'version':'1.0',
          'encoding': 'UTF-8'}}); 
 
 
 //Call the conversion method:
excel2xml(excelFilePath,xmlFilePath);
xml2Json(xmlFilePath);
function excel2xml(excelFilePath,xmlFilePath) {
         // Encapsulation function...
         //Get the data file of excel, put the excel file in the superior Excel directory
         //The sample xml file keeps the path:'../excel/xmlCase.xml'
    var excelData = xlsxrd.parse("../excel/" + excelFilePath);
 
    console.log(excelData.length);
    
         var testsuites = {'$':{'name':''},"testcase":[]};//test suites,
    _.each(excelData,function(testsuite,i) {
                 console.log("Test Suite-----start-------------");
                 //Process all test suites and get the suite name and data.
        testsuites.$.name = excelData[i].name;
        _.each(excelData[i].data,function(testcase,x) {
                         //To traverse the test cases in the suite        
                           console.log("Test case-------start-----------");
            console.log(testcase);
            if(x>0){
                let tmpcase = {
                    '$':{'name':testcase[0]},
                    'summary':'<p>'+testcase[1]+'</p>',
                    'preconditions':'<p>'+testcase[2]+'</p>' ,
                    'steps':{"step":[]}
                };
                                 //Construction ideas:
                                   //Search for use cases based on name to find out whether you can find use cases with the same name, summary, and preset
                                 //If found, splice the step, push the steps.step,
                                 //If not found, splice the steps information
                                 //Building steps
                let step = {
                        'step_number':testcase[3]||'',
                        'actions':'<p>'+testcase[4]+'</p>',
                        'expectedresults':'<p>'+testcase[5]+'</p>',
                        "execution_type":"1"
                        };
                let casename = testcase[0];
                
                
                                 //Filter out the use cases with the same use case name (there can always be only one use case with the same name, and if there are two, the first one is used)
                let tempCases = _.find(testsuites.testcase,function(item) {
                    // body...
                    return item.$.name === casename;
                });
               
                                 //Judging that the screening result is not defined or empty. If the result is not found, add the result directly
                if(!_.isUndefined(tempCases)){
                   
 
 
                                         //Find the object, add steps to this object
                     _.find(testsuites.testcase,function(item) {
                                                         //Find the object with the same name, and then merge the steps into one use case.
                        return item.$.name === casename;
                    }).steps.step.push(step);
                }else{
                                         //Cannot find a use case with the same name
                    tmpcase.steps.step.push(step);
                                         //Add a use case
                    testsuites.testcase.push(tmpcase);
                }
                                 console.log("Test case-----end-------------");
                
            }
        });
                 console.log("Test suite-----end-------------");
 
    });
 
 
 
         //Change to testsuites use case format 
         //Use fixed mode jsond as data source when debugging
    var json2xml = jsonBuilder.buildObject(testsuites);
    fs.writeFileSync('../excel/xmlCase.xml', json2xml, 'utf-8');
}
 
 
function nameToUpperCase(name){
   return name.toUpperCase();
}
 
function xml2Json(FilePath){
         // xml -> json'../excel/TEST1.testsuite-deep.xml'
    fs.readFile(FilePath,'utf-8',function(err,result){
                 //Convert xml file
       parser.parseString(result, function (err, result) {
                 console.log('xml parsed into json:'+'\n'+JSON.stringify(result));
        });
    });
 
}
