const libxml = require("libxmljs");
const fs = require("fs");
var dirFields = fs.readdirSync("./input");
if(dirFields.length){
    for(var j=0;j<dirFields.length;j++){
        writeFile(dirFields[j]);
    }
}
function writeFile(dirFile){
    if(dirFile.match(".xml")){
        fs.readFile("./input/"+dirFile,"utf-8",function(err,inputdata){
            try{
                var Rdata = replaceSymbols(inputdata);
                var data = Rdata.xmlData;
                let dom = libxml.parseXmlString(data);
                let fnNodes = dom.find("//fn");
                fnNodes.forEach(fnNode => {
                    let fnPNodes =  fnNode.find("p");
                    for(var i=0;i<fnPNodes.length;i++){
                        if(fnNode.attr("id")){
                            let id = fnNode.attr("id").value()+"-p"+(i+1);
                            fnPNodes[i].attr("id",id);
                        }
                    }
                });
                let output = replaceEntity(dom.toString(),Rdata.matchs);
                fs.writeFile("./output/"+dirFile,output,function(err){
                    if(err) throw err;
                });
            }catch(e){
                console.log(dirFile);
            }
        });
    }
}

