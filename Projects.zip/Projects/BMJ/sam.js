const libxml = require("libxmljs");
const fs = require("fs");
var dirFields = fs.readdirSync("./input");
if(dirFields.length){
    for(var j=0;j<dirFields.length;j++){
        writeFile(dirFields[j]);
    }
}
function writeFile(dirFile){
    if(dirFile.match(".xml")){
        fs.readFile("./input/"+dirFile,"utf-8",function(err,inputdata){
            try{
                let dom = libxml.parseXmlString(inputdata);
                let fnNodes = dom.find("//abstract[.//AbsTitle//AbsNumber][.//jrnlFigBlock]");
                fnNodes.forEach(function(ele, i){
                    var figBlockNodes = ele.find('.//jrnlFigBlock');
                    var absNumberNode = ele.find('.//AbsTitle//AbsNumber');
                    if(absNumberNode.length > 0){
                        figBlockNodes.forEach(function(figBlock, index){                        
                            var absNumber = absNumberNode[0].text();
                            figBlock.attr('id', absNumber+'F'+(index+1));
                        })
                    }
                })
                var tblNodes = dom.find("//abstract[.//AbsTitle//AbsNumber][.//jrnlTblBlock]");
                tblNodes.forEach(function(tbl, j){
                var tblBlockNodes = tbl.find('.//jrnlTblBlock')
                var absNumberNode = tbl.find('.//AbsTitle//AbsNumber');
                if(absNumberNode.length > 0){
                    tblBlockNodes.forEach(function(tableBlk, index){
                        var absNumber = absNumberNode[0].text();
                        tableBlk.attr('id', absNumber+'T'+(index+1))
                    })
                }
                })
                var refNodes = dom.find("//abstract[.//AbsTitle//AbsNumber][.//AbsRefText]");
                refNodes.forEach(function(ref, j){
                var refBlockNodes = ref.find('.//AbsRefText')
                var absNumberNode = ref.find('.//AbsTitle//AbsNumber');
                if(absNumberNode.length > 0){
                    refBlockNodes.forEach(function(refBlk, index){
                        var absNumber = absNumberNode[0].text();
                        refBlk.attr('id', absNumber+'R'+(index+1))
                    })
                }
                })
                var outputString = dom.toString();
                fs.writeFile("./output/"+dirFile, outputString,function(err){
                    if(err) console.log(err);
                });
            }catch(e){
                console.log(e);
            }
        });
    }
}
