const libxml = require("libxmljs");
const fs = require("fs");
var dirFields = fs.readdirSync("./input");
if(dirFields.length){
    for(var j=0;j<dirFields.length;j++){
        writeFile(dirFields[j]);
    }
}
function writeFile(dirFile){
    if(dirFile.match(".xml")){
        fs.readFile("./input/"+dirFile,"utf-8",function(err,inputdata){
                //let dom = libxml.parseXmlString(inputdata);
                //let fnNodes = dom.find("//abstract");
                let output = inputdata;
                fs.writeFile("./output/"+dirFile,output,function(err){
                    if(err) throw err;
                    if(!err)console.log("success");
                });
        });
    }
}
