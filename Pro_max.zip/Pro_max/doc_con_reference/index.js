const fs = require('fs')
const path = require('path')
const mammoth = require('mammoth')
var options = {
    styleMap: [
        "p[style-name='Abstracthead'] => abstractHead",
        "p[style-name='Author'] => Author",
            "p[style-name='degree'] => degree",
                "p[style-name='Aff'] => Aff",
                    "p[style-name='articletitle'] => articletitle",
                        "p[style-name='Abshead'] => Abshead",
                            "p[style-name='Abspara'] => Abspara",
                            "p[style-name='ArticleType'] => ArticleType",
                            "p[style-name='Subject'] => Subject",
                            "p[style-name='AuthorName'] => AuthorName",
                             "p[style-name='kwdhead']=> kwdhead",
                             "p[style-name='kwdPara']=> kwdPara"
        // "p => p:fresh"
    ]
};

fs.readdir('Documents/', (err, files) => {
  files.forEach(file => {
    if (path.extname(file) === '.docx') {
      // If its a docx file
      mammoth
        .convertToHtml({ path: `Documents/${file}` }, options)
        .then(function(resultObject) {
          // Now get the basename of the filename
          const filename = path.basename(file)
          // Replace output/ with where you want the file
          fs.writeFile(`output/${filename}.html`, resultObject.value, function (err) {
            if (err) return console.log(err);
          });
        })
    }
  })
})
