var mammoth = require("mammoth");
var glob = require("glob");
const path = require("path");
fs = require("fs");
console.log("start")
function readAllFiles(dir){
  return new Promise((resolve, reject) => {
    glob(dir, (err, files) => {
      if(err) {
        return reject(err)
      }
      var options = {
        styleMap: [
            "p[style-name='Abstracthead'] => abstractHead",
            "p[style-name='Author'] => Author",
                "p[style-name='degree'] => degree",
                    "p[style-name='Aff'] => Aff",
                        "p[style-name='articletitle'] => articletitle",
                            "p[style-name='Abshead'] => Abshead",
                                "p[style-name='Abspara'] => Abspara",
                                "p[style-name='ArticleType'] => ArticleType",
                                "p[style-name='Subject'] => Subject",
                                "p[style-name='AuthorName'] => AuthorName",
                                 "p[style-name='kwdhead']=> kwdhead",
                                 "p[style-name='kwdPara']=> kwdPara"
            // "p => p:fresh"
        ]
    };
      return Promise.all(files.map((file) => mammoth.convertToHtml({ path: file }, options)))
        .then((results) => {
          let data = ''
          results.forEach((result) => {
        var html = result.value; // The generated HTML
        console.log(html);
        var messages = result.messages; // Any messages, such as warnings during conversion
        console.log(messages)
        //fs.writeFile('D:/Deepika/Projects/doctohtml/test.html', html)
        fs.writeFile("./Documents/"+path.basename(dir).html, html, function (data, err){
            if(err) console.log(err);
            if(!err)console.log("success");
        });
          })
          resolve(data)
        })
        .catch(reject)
    })
  })
}

async function test() {
  const data = await readAllFiles('./Documents/**/*.docx') // All my docx files are in the test directory
  console.log(data) // Print data
}
console.log("done")
test()
