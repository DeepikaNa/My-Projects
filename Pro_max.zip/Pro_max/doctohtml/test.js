var xsltproc = require('xsltproc')
var format = require('xml-beautifier');
fs = require("fs")
http = require('http');

xsltproc.transform('front.xsl', 'testwe.html', {
  "profile": true,
  "output": "testie.xml",
  "stringparam": [
    {
      "key": 'title',
      "val": 'This is a single parameter passed as subtitle----anvidsahviulasdhvklasdbcuw'
    },
    {
      "key": 'anotherTitle',
      "val": 'This is a another single parameter passed'
    }
  ],
});
console.log("Completed Successfully!!");
http.createServer(function (req, res) {

}).listen(5555);
