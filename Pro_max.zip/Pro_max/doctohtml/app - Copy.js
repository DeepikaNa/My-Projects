var mammoth = require("mammoth"),
     fs = require("fs");


// mammoth.embedStyleMap({path: "test.docx"}, "p[style-name='Section Title'] => h1:fresh")
    // .then(function(docx) {
    //    // fs.writeFile("D:\Deepika\Projects\doctohtml\test.html", docx.toBuffer(), callback);
    //    fs.writeFile('D:/Deepika/Projects/doctohtml/test.html', [xmldata], function (data, err){
    //     if(err) console.log(err);
    //     if(!err)console.log("success");
    // });

// mammoth.convertToHtml({path: "test.docx"},)
//     .then(function(result){
//         var html = result.value; // The generated HTML
//         console.log(html);
//         var messages = result.messages; // Any messages, such as warnings during conversion
//         //fs.writeFile('D:/Deepika/Projects/doctohtml/test.html', html)
//         fs.writeFile('D:/Deepika/Projects/doctohtml/test2.html', html, function (data, err){
//             if(err) console.log(err);
//             if(!err)console.log("success");
//         });
//     }).done();

var options = {
    styleMap: [
        "p[style-name='Abstracthead'] => abstractHead",
        "p[style-name='Author'] => Author",
            "p[style-name='degree'] => degree",
                "p[style-name='Aff'] => Aff",
                    "p[style-name='articletitle'] => articletitle",
                        "p[style-name='Abshead'] => Abshead",
                            "p[style-name='Abspara'] => Abspara",
                            "p[style-name='ArticleType'] => ArticleType",
                            "p[style-name='Subject'] => Subject",
                            "p[style-name='AuthorName'] => AuthorName",
                             "p[style-name='kwdhead']=> kwdhead",
                             "p[style-name='kwdPara']=> kwdPara"
        // "p => p:fresh"
    ]
};
mammoth.convertToHtml({path: "jrnms_90-1.docx"}, options)
    .then(function(result){
        var html = result.value; // The generated HTML
        console.log(html);
        var messages = result.messages; // Any messages, such as warnings during conversion
        console.log(messages)
        //fs.writeFile('D:/Deepika/Projects/doctohtml/test.html', html)
        fs.writeFile('D:/Deepika/Projects/doctohtml/jrnms_90-11.html', html, function (data, err){
            if(err) console.log(err);
            if(!err)console.log("success");
        });
    }).done();