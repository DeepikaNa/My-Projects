var fs = require("fs"),
    http = require('http');
    const excelToJson = require('convert-excel-to-json');
    var format = require('xml-beautifier');
const results = excelToJson({
    sourceFile: 'D:/Deepika/Projects/MBS-XL-XML/inputs/Abstract_new.xlsx'
});
var result = results["Sheet1"]
for(var data in result){
        if(data == 0){
            continue;
        }
    var xmldata = '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE article PUBLIC "-//NLM//DTD JATS (Z39.96) Journal Archiving and Interchange DTD v1.1 20151215//EN" "JATS-archivearticle1.dtd"><article xmlns:mml="http://www.w3.org/1998/Math/MathML" xmlns:xlink="http://www.w3.org/1999/xlink" article-type="meeting-report" dtd-version="1.1" xml:lang="EN"><front><journal-meta><journal-id journal-id-type="nlm-ta">Access Microbiology</journal-id><journal-id journal-id-type="hwp">acmi</journal-id><journal-id journal-id-type="publisher-id">acmi</journal-id><journal-title-group><journal-title>Access Microbiology</journal-title><abbrev-journal-title abbrev-type="pubmed">acmi</abbrev-journal-title></journal-title-group><issn pub-type="epub">2516-8290</issn><publisher><publisher-name>Microbiology Society</publisher-name></publisher></journal-meta><article-meta>'
    xmldata+='<article-id pub-id-type="publisher-id">'+result[data]["B"].replace(/10.1099\//,'')+'</article-id>'
    xmldata+='<article-id pub-id-type="doi">'+result[data]["A"]+'</article-id>'
    xmldata+='<article-categories><subj-group subj-group-type="heading"><subject>'+result[data]["I"]+'</subject></subj-group><subj-group subj-group-type="heading"><subject>'+result[data]["H"]+'</subject></subj-group></article-categories>'
    xmldata+='<title-group><article-title>'+result[data]["F"]+'</article-title><alt-title alt-title-type="recto-page-foot"><ext-link ext-link-type="uri" xlink:type="simple" xlink:href="http://jmmcr.microbiologyresearch.org">http://jmmcr.microbiologyresearch.org</ext-link></alt-title></title-group>'
    xmldata+='<contrib-group><contrib contrib-type="author">'
    xmldata+='<name><surname>'+result[data]["K"].split(" ")[1]+'</surname><given-names>'+result[data]["K"].split(" ")[0]+'</given-names></name>'
    var aff=result[data]["AP"].split(',');
    for(var affno in aff){
    xmldata+='<xref ref-type="aff" rid="aff'+aff[affno]+'"/>'
    
    }
    if(result[data]["K"] == result[data]["D"]){
        xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    if(result[data]["K"] != ""){
    xmldata+='<name><surname>'+result[data]["K"].split(" ")[1]+'</surname><given-names>'+result[data]["K"].split(" ")[0]+'</given-names></name>'
    if(result[data]["AP"] != ""){
    xmldata+='<xref ref-type="aff" rid="aff1"/>'
    }
    if(result[data]["BU"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff2"/>'
        } 
    if(result[data]["CZ"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff3"/>'
        } 
    if(result[data]["EF"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff4"/>'
        } 
    if(result[data]["K"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
        }
    }
    if(result[data]["L"] != ""){
    xmldata+='<name><surname>'+result[data]["L"].split(" ")[1]+'</surname><given-names>'+result[data]["L"].split(" ")[0]+'</given-names></name>'
    if(result[data]["AQ"] != ""){
    xmldata+='<xref ref-type="aff" rid="aff1"/>'
    }
    if(result[data]["BV"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff2"/>'
        } 
    if(result[data]["DA"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff3"/>'
        } 
    if(result[data]["EF"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff4"/>'
        } 
    if(result[data]["L"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
        }
    }
    if(result[data]["M"] != ""){
    xmldata+='<name><surname>'+result[data]["M"].split(" ")[1]+'</surname><given-names>'+result[data]["M"].split(" ")[0]+'</given-names></name>'
    if(result[data]["AR"] != ""){
    xmldata+='<xref ref-type="aff" rid="aff1"/>'
    }
    if(result[data]["BW"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff2"/>'
        } 
    if(result[data]["DB"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff3"/>'
        } 
    if(result[data]["EG"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff4"/>'
        } 
    if(result[data]["M"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["N"] != ""){
    xmldata+='<name><surname>'+result[data]["N"].split(" ")[1]+'</surname><given-names>'+result[data]["N"].split(" ")[0]+'</given-names></name>'
    if(result[data]["AS"] != ""){
    xmldata+='<xref ref-type="aff" rid="aff1"/>'
    }
    if(result[data]["BX"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff2"/>'
        } 
    if(result[data]["DC"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff3"/>'
        } 
    if(result[data]["EH"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff4"/>'
        } 
    if(result[data]["N"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["O"] != ""){
    xmldata+='<name><surname>'+result[data]["O"].split(" ")[1]+'</surname><given-names>'+result[data]["O"].split(" ")[0]+'</given-names></name>'
    if(result[data]["AT"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["BY"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DD"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EI"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["O"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["P"] != ""){
    xmldata+='<name><surname>'+result[data]["P"].split(" ")[1]+'</surname><given-names>'+result[data]["P"].split(" ")[0]+'</given-names></name>'
    if(result[data]["AU"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["BZ"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DE"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EJ"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["P"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["Q"] != ""){
    xmldata+='<name><surname>'+result[data]["Q"].split(" ")[1]+'</surname><given-names>'+result[data]["Q"].split(" ")[0]+'</given-names></name>'
    if(result[data]["AV"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CA"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DF"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EK"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["Q"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["R"] != ""){
    xmldata+='<name><surname>'+result[data]["R"].split(" ")[1]+'</surname><given-names>'+result[data]["R"].split(" ")[0]+'</given-names></name>'
    if(result[data]["AW"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CB"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DG"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EL"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["R"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["S"] != ""){
    xmldata+='<name><surname>'+result[data]["S"].split(" ")[1]+'</surname><given-names>'+result[data]["S"].split(" ")[0]+'</given-names></name>'
    if(result[data]["AX"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CC"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DH"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EM"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["S"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["T"] != ""){
    xmldata+='<name><surname>'+result[data]["T"].split(" ")[1]+'</surname><given-names>'+result[data]["T"].split(" ")[0]+'</given-names></name>'
    if(result[data]["AY"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CD"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DI"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EN"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["T"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["U"] != ""){
    xmldata+='<name><surname>'+result[data]["U"].split(" ")[1]+'</surname><given-names>'+result[data]["U"].split(" ")[0]+'</given-names></name>'
    if(result[data]["AZ"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CE"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DJ"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EO"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["U"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["V"] != ""){
    xmldata+='<name><surname>'+result[data]["V"].split(" ")[1]+'</surname><given-names>'+result[data]["V"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BA"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CF"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DK"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EP"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["V"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["W"] != ""){
    xmldata+='<name><surname>'+result[data]["W"].split(" ")[1]+'</surname><given-names>'+result[data]["W"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BB"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CG"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DL"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EQ"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["W"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["X"] != ""){
    xmldata+='<name><surname>'+result[data]["X"].split(" ")[1]+'</surname><given-names>'+result[data]["X"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BC"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CH"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DM"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["ER"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["X"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["Y"] != ""){
    xmldata+='<name><surname>'+result[data]["Y"].split(" ")[1]+'</surname><given-names>'+result[data]["Y"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BD"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CI"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DN"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["ES"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["Y"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["Z"] != ""){
    xmldata+='<name><surname>'+result[data]["Z"].split(" ")[1]+'</surname><given-names>'+result[data]["Z"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BE"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CJ"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DO"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["ET"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["Z"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AA"] != ""){
    xmldata+='<name><surname>'+result[data]["AA"].split(" ")[1]+'</surname><given-names>'+result[data]["AA"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BF"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CK"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DP"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EU"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["AA"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AB"] != ""){
    xmldata+='<name><surname>'+result[data]["AB"].split(" ")[1]+'</surname><given-names>'+result[data]["AB"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BG"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CL"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DQ"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EV"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["AB"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AC"] != ""){
    xmldata+='<name><surname>'+result[data]["AC"].split(" ")[1]+'</surname><given-names>'+result[data]["AC"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BH"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CM"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DR"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EW"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["AC"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AD"] != ""){
    xmldata+='<name><surname>'+result[data]["AD"].split(" ")[1]+'</surname><given-names>'+result[data]["AD"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BI"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CN"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DS"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EX"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["AD"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AE"] != ""){
    xmldata+='<name><surname>'+result[data]["AE"].split(" ")[1]+'</surname><given-names>'+result[data]["AE"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BJ"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CO"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DT"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
            if(result[data]["EY"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff4"/>'
                } 
        
    if(result[data]["AE"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AF"] != ""){
    xmldata+='<name><surname>'+result[data]["AF"].split(" ")[1]+'</surname><given-names>'+result[data]["AF"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BK"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CP"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DU"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
            if(result[data]["EZ"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff4"/>'
                } 
        
    if(result[data]["AF"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AG"] != ""){
    xmldata+='<name><surname>'+result[data]["AG"].split(" ")[1]+'</surname><given-names>'+result[data]["AG"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BL"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CQ"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            }
        if(result[data]["DV"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
            if(result[data]["FA"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff4"/>'
                } 
    if(result[data]["AG"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AH"] != ""){
    xmldata+='<name><surname>'+result[data]["AH"].split(" ")[1]+'</surname><given-names>'+result[data]["AH"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BM"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CR"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            }
        if(result[data]["DW"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["FB"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["AH"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AI"] != ""){
    xmldata+='<name><surname>'+result[data]["AI"].split(" ")[1]+'</surname><given-names>'+result[data]["AI"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BN"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CS"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            }
        if(result[data]["DX"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["FC"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
    if(result[data]["AI"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AJ"] != ""){
    xmldata+='<name><surname>'+result[data]["AJ"].split(" ")[1]+'</surname><given-names>'+result[data]["AJ"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BO"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CT"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            }
        if(result[data]["DY"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["FD"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            }    
        
    if(result[data]["AJ"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AK"] != ""){
    xmldata+='<name><surname>'+result[data]["AK"].split(" ")[1]+'</surname><given-names>'+result[data]["AK"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BP"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CU"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            }
        if(result[data]["DZ"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["FE"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            }
    if(result[data]["AK"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AL"] != ""){
    xmldata+='<name><surname>'+result[data]["AL"].split(" ")[1]+'</surname><given-names>'+result[data]["AL"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BQ"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CV"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            }
        if(result[data]["EA"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["FF"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            }
    if(result[data]["AL"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AM"] != ""){
    xmldata+='<name><surname>'+result[data]["AM"].split(" ")[1]+'</surname><given-names>'+result[data]["AM"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BR"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CW"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            }
        if(result[data]["EB"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            }     
        if(result[data]["FG"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            }
    if(result[data]["AM"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AN"] != ""){
    xmldata+='<name><surname>'+result[data]["AN"].split(" ")[1]+'</surname><given-names>'+result[data]["AN"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BS"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["CX"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            }
        if(result[data]["EC"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
    if(result[data]["FH"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff4"/>'
        }
    if(result[data]["AN"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    if(result[data]["AO"] != ""){
    xmldata+='<name><surname>'+result[data]["AO"].split(" ")[1]+'</surname><given-names>'+result[data]["AO"].split(" ")[0]+'</given-names></name>'
    if(result[data]["BT"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
    if(result[data]["CY"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff2"/>'
        }
    if(result[data]["ED"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff3"/>'
        }
    if(result[data]["FI"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff4"/>'
        }
    if(result[data]["AO"] == result[data]["C"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
    }
    }
    xmldata+='</contrib>'
    if(result[data]["AE"] != ""){
        xmldata+='<aff id="aff1"><institution>'+result[data]["BV"]+'</institution>, <country>'+result[data]["DA"]+'</country></aff>'
    }
    if(result[data]["AE"] != ""){
        xmldata+='<aff id="aff1"><institution>'+result[data]["BV"]+'</institution>, <country>'+result[data]["DA"]+'</country></aff>'
    }
   
    xmldata+='</contrib-group><author-notes>'
    xmldata+='<corresp id="cor1">&#x002A;<bold>Correspondence:</bold> '+result[data]["C"]+' '+result[data]["D"]+', <email xlink:href="'+result[data]["E"]+'" xlink:type="simple">'+result[data]["E"]+'</email></corresp></author-notes>'
    xmldata+='<pub-date pub-type="ppub"><month>7</month><year>2020</year></pub-date><pub-date pub-type="epub"><day>10</day><month>07</month><year>2020</year></pub-date><volume>2</volume><issue>7A</issue><elocation-id>2</elocation-id>'
    xmldata+='<permissions><copyright-statement>&#x00A9; 2020 The Authors</copyright-statement><copyright-year>2020</copyright-year><license license-type="open-access" xlink:href="http://creativecommons.org/licenses/by/4.0/"><license-p>This is an open-access article distributed under the terms of the Creative Commons Attribution License, which permits unrestricted use, distribution, and reproduction in any medium, provided the original work is properly cited.</license-p></license></permissions>'
    xmldata+='<self-uri xlink:href="'+result[data]["B"].replace(/10.1099\//,'')+'.pdf" content-type="pdf"/>'
    xmldata+='<abstract><p>'+result[data]["G"].replace(/\n/,'</p><p>')+'</p></abstract>';
    xmldata+='<custom-meta-group><custom-meta><meta-name>OpenAccessEmbargo</meta-name><meta-value>0</meta-value></custom-meta></custom-meta-group></article-meta></front></article>';
    //xmldata = format(xmldata);// this line for giving indentation in xml file
    console.log(xmldata);
    fs.writeFile('./xml/'+result[data]["B"].replace(/10.1099\//,'')+'.xml', [xmldata], function (data, err){
        if(err) console.log(err);
        if(!err)console.log("success");
    });

 }

 console.log("Completed");


    http.createServer(function (req, res) {

    }).listen(5555);
