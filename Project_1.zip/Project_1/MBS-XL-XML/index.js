var fs = require("fs"),
    http = require('http');
    const excelToJson = require('convert-excel-to-json');
    var format = require('xml-beautifier');
const results = excelToJson({
    sourceFile: 'D:/Deepika/Projects/MBS-XL-XML/inputs/Abstract_new.xlsx'
});
var result = results["Sheet1"]
for(var data in result){
        if(data == 0){
            continue;
        }
    var xmldata = '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE article PUBLIC "-//NLM//DTD JATS (Z39.96) Journal Archiving and Interchange DTD v1.1 20151215//EN" "JATS-archivearticle1.dtd"><article xmlns:mml="http://www.w3.org/1998/Math/MathML" xmlns:xlink="http://www.w3.org/1999/xlink" article-type="meeting-report" dtd-version="1.1" xml:lang="EN"><front><journal-meta><journal-id journal-id-type="nlm-ta">Access Microbiology</journal-id><journal-id journal-id-type="hwp">acmi</journal-id><journal-id journal-id-type="publisher-id">acmi</journal-id><journal-title-group><journal-title>Access Microbiology</journal-title><abbrev-journal-title abbrev-type="pubmed">acmi</abbrev-journal-title></journal-title-group><issn pub-type="epub">2516-8290</issn><publisher><publisher-name>Microbiology Society</publisher-name></publisher></journal-meta><article-meta>'
    xmldata+='<article-id pub-id-type="publisher-id">'+result[data]["B"].replace(/10.1099\//,'')+'</article-id>'
    xmldata+='<article-id pub-id-type="doi">'+result[data]["A"]+'</article-id>'
    xmldata+='<article-categories><subj-group subj-group-type="heading"><subject>'+result[data]["I"]+'</subject></subj-group><subj-group subj-group-type="heading"><subject>'+result[data]["H"]+'</subject></subj-group></article-categories>'
    xmldata+='<title-group><article-title>'+result[data]["F"]+'</article-title><alt-title alt-title-type="recto-page-foot"><ext-link ext-link-type="uri" xlink:type="simple" xlink:href="http://jmmcr.microbiologyresearch.org">http://jmmcr.microbiologyresearch.org</ext-link></alt-title></title-group>'
    xmldata+='<contrib-group><contrib contrib-type="author">'
    xmldata+='<name><surname>'+result[data]["K"].split(" ")[1]+'</surname><given-names>'+result[data]["K"].split(" ")[0]+'</given-names></name>'
    var aff=result[data]["AP"].split(',');
    // for(var affno in aff){
    // xmldata+='<xref ref-type="aff" rid="aff'+affno+'"/>'
    
    // }
    if(result[data]["BU"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff2"/>'
        } 
    if(result[data]["CZ"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff3"/>'
        } 
    if(result[data]["EF"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff4"/>'
        } 
    if(result[data]["K"] == result[data]["D"]){
    xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
        }
    xmldata+='</contrib>'
    if(result[data]["L"]){
        xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["L"].split(" ")[1]+'</surname><given-names>'+result[data]["L"].split(" ")[0]+'</given-names></name>'
        if(result[data]["AQ"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff1"/>'
        }
        if(result[data]["BV"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff2"/>'
            } 
        if(result[data]["DA"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff3"/>'
            } 
        if(result[data]["EF"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff4"/>'
            } 
        if(result[data]["L"] == result[data]["C"]){
        xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
        }
        
    if(result[data]["M"]){
        xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["M"].split(" ")[1]+'</surname><given-names>'+result[data]["M"].split(" ")[0]+'</given-names></name>'
    if(result[data]["AR"] != ""){
    xmldata+='<xref ref-type="aff" rid="aff1"/>'
    }
    if(result[data]["BW"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff2"/>'
        } 
    if(result[data]["DB"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff3"/>'
        } 
    if(result[data]["EG"] != ""){
        xmldata+='<xref ref-type="aff" rid="aff4"/>'
        } 
        if(result[data]["M"] == result[data]["C"]){
        xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
        }
        xmldata+='</contrib>'
        }
       
        if(result[data]["N"]){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["N"].split(" ")[1]+'</surname><given-names>'+result[data]["N"].split(" ")[0]+'</given-names></name>'
            if(result[data]["AS"] != ""){
            xmldata+='<xref ref-type="aff" rid="aff1"/>'
            }
            if(result[data]["BX"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff2"/>'
                } 
            if(result[data]["DC"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff3"/>'
                } 
            if(result[data]["EH"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff4"/>'
                } 
            if(result[data]["N"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }
            if(result[data]["O"]){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["O"].split(" ")[1]+'</surname><given-names>'+result[data]["O"].split(" ")[0]+'</given-names></name>'
            if(result[data]["AT"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["BY"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DD"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["EI"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["O"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }
           

            if(result[data]["P"]){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["P"].split(" ")[1]+'</surname><given-names>'+result[data]["P"].split(" ")[0]+'</given-names></name>'
            if(result[data]["AU"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["BZ"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DE"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["EJ"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["P"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["Q"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["Q"].split(" ")[1]+'</surname><given-names>'+result[data]["Q"].split(" ")[0]+'</given-names></name>'
            if(result[data]["AV"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CA"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DF"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["EK"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["Q"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }
            

            if(result[data]["R"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["R"].split(" ")[1]+'</surname><given-names>'+result[data]["R"].split(" ")[0]+'</given-names></name>'
            if(result[data]["AW"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CB"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DG"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["EL"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["R"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }
            

            if(result[data]["S"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["S"].split(" ")[1]+'</surname><given-names>'+result[data]["S"].split(" ")[0]+'</given-names></name>'
            if(result[data]["AX"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CC"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DH"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["EM"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["S"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }
            

            if(result[data]["T"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["T"].split(" ")[1]+'</surname><given-names>'+result[data]["T"].split(" ")[0]+'</given-names></name>'
            if(result[data]["AY"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CD"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DI"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["EN"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["T"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }
            

            if(result[data]["U"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["U"].split(" ")[1]+'</surname><given-names>'+result[data]["U"].split(" ")[0]+'</given-names></name>'
            if(result[data]["AZ"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CE"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DJ"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["EO"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["U"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["V"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["V"].split(" ")[1]+'</surname><given-names>'+result[data]["V"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BA"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CF"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DK"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["EP"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["V"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["W"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["W"].split(" ")[1]+'</surname><given-names>'+result[data]["W"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BB"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CG"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DL"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["EQ"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["W"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["X"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["X"].split(" ")[1]+'</surname><given-names>'+result[data]["X"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BC"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CH"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DM"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["ER"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["X"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["Y"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["Y"].split(" ")[1]+'</surname><given-names>'+result[data]["Y"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BD"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CI"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DN"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["ES"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["Y"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["Z"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["Z"].split(" ")[1]+'</surname><given-names>'+result[data]["Z"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BE"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CJ"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DO"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["ET"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["Z"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["AA"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AA"].split(" ")[1]+'</surname><given-names>'+result[data]["AA"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BF"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CK"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DP"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["EU"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["AA"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["AB"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AB"].split(" ")[1]+'</surname><given-names>'+result[data]["AB"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BG"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CL"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DQ"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["EV"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["AB"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'

            }

            if(result[data]["AC"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AC"].split(" ")[1]+'</surname><given-names>'+result[data]["AC"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BH"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CM"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DR"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["EW"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["AC"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["AD"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AD"].split(" ")[1]+'</surname><given-names>'+result[data]["AD"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BI"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CN"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DS"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["EX"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["AD"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }


            if(result[data]["AE"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AE"].split(" ")[1]+'</surname><given-names>'+result[data]["AE"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BJ"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CO"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DT"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                    if(result[data]["EY"] != ""){
                        xmldata+='<xref ref-type="aff" rid="aff4"/>'
                        } 
                
            if(result[data]["AE"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }
            

            if(result[data]["AF"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AF"].split(" ")[1]+'</surname><given-names>'+result[data]["AF"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BK"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CP"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    } 
                if(result[data]["DU"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                    if(result[data]["EZ"] != ""){
                        xmldata+='<xref ref-type="aff" rid="aff4"/>'
                        } 
                
            if(result[data]["AF"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["AG"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AG"].split(" ")[1]+'</surname><given-names>'+result[data]["AG"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BL"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CQ"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    }
                if(result[data]["DV"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                    if(result[data]["FA"] != ""){
                        xmldata+='<xref ref-type="aff" rid="aff4"/>'
                        } 
            if(result[data]["AG"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["AH"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AH"].split(" ")[1]+'</surname><given-names>'+result[data]["AH"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BM"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CR"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    }
                if(result[data]["DW"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["FB"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["AH"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["AI"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AI"].split(" ")[1]+'</surname><given-names>'+result[data]["AI"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BN"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CS"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    }
                if(result[data]["DX"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["FC"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    } 
            if(result[data]["AI"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["AJ"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AJ"].split(" ")[1]+'</surname><given-names>'+result[data]["AJ"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BO"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CT"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    }
                if(result[data]["DY"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["FD"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    }    
                
            if(result[data]["AJ"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["AK"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AK"].split(" ")[1]+'</surname><given-names>'+result[data]["AK"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BP"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CU"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    }
                if(result[data]["DZ"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["FE"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    }
            if(result[data]["AK"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["AL"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AL"].split(" ")[1]+'</surname><given-names>'+result[data]["AL"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BQ"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CV"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    }
                if(result[data]["EA"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
                if(result[data]["FF"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    }
            if(result[data]["AL"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["AM"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AM"].split(" ")[1]+'</surname><given-names>'+result[data]["AM"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BR"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CW"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    }
                if(result[data]["EB"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    }     
                if(result[data]["FG"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff4"/>'
                    }
            if(result[data]["AM"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["AN"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AN"].split(" ")[1]+'</surname><given-names>'+result[data]["AN"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BS"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
                if(result[data]["CX"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff2"/>'
                    }
                if(result[data]["EC"] != ""){
                    xmldata+='<xref ref-type="aff" rid="aff3"/>'
                    } 
            if(result[data]["FH"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff4"/>'
                }
            if(result[data]["AN"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }

            if(result[data]["AO"] != ""){
            xmldata+='<contrib contrib-type="author"><name><surname>'+result[data]["AO"].split(" ")[1]+'</surname><given-names>'+result[data]["AO"].split(" ")[0]+'</given-names></name>'
            if(result[data]["BT"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff1"/>'
                }
            if(result[data]["CY"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff2"/>'
                }
            if(result[data]["ED"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff3"/>'
                }
            if(result[data]["FI"] != ""){
                xmldata+='<xref ref-type="aff" rid="aff4"/>'
                }
            if(result[data]["AO"] == result[data]["C"]){
            xmldata+='<xref ref-type="corresp" rid="cor1">&#x002A;</xref>'
            }
            xmldata+='</contrib>'
            }
// Affiliations
    if(result[data]["AP"]){
        xmldata+='<aff id="aff1"><institution>'+result[data]["AP"].split(", ")[0]+'</institution>, <country>'+result[data]["AP"].split(",")[1]+'</country></aff>'
    }
    if(result[data]["BU"]){
        xmldata+='<aff id="aff2"><institution>'+result[data]["BU"].split(", ")[0]+'</institution>, <country>'+result[data]["BU"].split(",")[1]+'</country></aff>'
    }
    if(result[data]["CZ"]){
        xmldata+='<aff id="aff3"><institution>'+result[data]["CZ"].split(", ")[0]+'</institution>, <country>'+result[data]["CZ"].split(",")[1]+'</country></aff>'
        } 
    if(result[data]["EF"]){
        xmldata+='<aff id="aff4"><institution>'+result[data]["EF"].split(", ")[0]+'</institution>, <country>'+result[data]["EF"].split(",")[1]+'</country></aff>'
        } 
    if(result[data]["AQ"]){
        xmldata+='<aff id="aff5"><institution>'+result[data]["AQ"].split(", ")[0]+'</institution>, <country>'+result[data]["AQ"].split(",")[1]+'</country></aff>'
        }
    if(result[data]["BV"]){
        xmldata+='<aff id="aff6"><institution>'+result[data]["BV"].split(", ")[0]+'</institution>, <country>'+result[data]["BV"].split(",")[1]+'</country></aff>'                
    } 
    if(result[data]["DA"]){
        xmldata+='<aff id="aff7"><institution>'+result[data]["DA"].split(", ")[0]+'</institution>, <country>'+result[data]["DA"].split(",")[1]+'</country></aff>'  
      } 
    if(result[data]["EF"]){
        xmldata+='<aff id="aff8"><institution>'+result[data]["EF"].split(", ")[0]+'</institution>, <country>'+result[data]["EF"].split(",")[1]+'</country></aff>'        
            } 
    if(result[data]["AR"] ){
        xmldata+='<aff id="aff9"><institution>'+result[data]["AR"].split(", ")[0]+'</institution>, <country>'+result[data]["AR"].split(",")[1]+'</country></aff>'    
                }         
    if(result[data]["BW"]){
        xmldata+='<aff id="aff10"><institution>'+result[data]["BW"].split(", ")[0]+'</institution>, <country>'+result[data]["BW"].split(",")[1]+'</country></aff>'               
     }         
    if(result[data]["DB"]){
        xmldata+='<aff id="aff11"><institution>'+result[data]["DB"].split(", ")[0]+'</institution>, <country>'+result[data]["DB"].split(",")[1]+'</country></aff>'                      
      } 
    if(result[data]["EG"]){
        xmldata+='<aff id="aff12"><institution>'+result[data]["EG"].split(", ")[0]+'</institution>, <country>'+result[data]["EG"].split(",")[1]+'</country></aff>'                       
     } 
    if(result[data]["AS"] ){
        xmldata+='<aff id="aff13"><institution>'+result[data]["AS"].split(", ")[0]+'</institution>, <country>'+result[data]["AS"].split(",")[1]+'</country></aff>'    
    }
    if(result[data]["BX"]){
        xmldata+='<aff id="aff14"><institution>'+result[data]["BX"].split(", ")[0]+'</institution>, <country>'+result[data]["BX"].split(",")[1]+'</country></aff>'        
    } 
    if(result[data]["DC"]){
        xmldata+='<aff id="aff15"><institution>'+result[data]["DC"].split(", ")[0]+'</institution>, <country>'+result[data]["DC"].split(",")[1]+'</country></aff>'        
    } 
    if(result[data]["EH"]){
        xmldata+='<aff id="aff16"><institution>'+result[data]["EH"].split(", ")[0]+'</institution>, <country>'+result[data]["EH"].split(",")[1]+'</country></aff>'       
     }     
    if(result[data]["AT"]){
        xmldata+='<aff id="aff17"><institution>'+result[data]["AT"].split(", ")[0]+'</institution>, <country>'+result[data]["AT"].split(",")[1]+'</country></aff>'      
    }
    if(result[data]["BY"]){
        xmldata+='<aff id="aff18"><institution>'+result[data]["BY"].split(", ")[0]+'</institution>, <country>'+result[data]["BY"].split(",")[1]+'</country></aff>'      
            } 
        if(result[data]["DD"]){
            xmldata+='<aff id="aff19"><institution>'+result[data]["DD"].split(", ")[0]+'</institution>, <country>'+result[data]["DD"].split(",")[1]+'</country></aff>'                 
         } 
        if(result[data]["EI"]){
            xmldata+='<aff id="aff20"><institution>'+result[data]["EI"].split(", ")[0]+'</institution>, <country>'+result[data]["EI"].split(",")[1]+'</country></aff>'                  
        } 
    if(result[data]["AU"]){
        xmldata+='<aff id="aff21"><institution>'+result[data]["AU"].split(", ")[0]+'</institution>, <country>'+result[data]["AU"].split(",")[1]+'</country></aff>'             
     }
        if(result[data]["BZ"]){
            xmldata+='<aff id="aff22"><institution>'+result[data]["BZ"].split(", ")[0]+'</institution>, <country>'+result[data]["BZ"].split(",")[1]+'</country></aff>'                  
        } 
        if(result[data]["DE"]){
            xmldata+='<aff id="aff23"><institution>'+result[data]["DE"].split(", ")[0]+'</institution>, <country>'+result[data]["DE"].split(",")[1]+'</country></aff>'                 
         } 
        if(result[data]["EJ"]){
            xmldata+='<aff id="aff24"><institution>'+result[data]["EJ"].split(", ")[0]+'</institution>, <country>'+result[data]["EJ"].split(",")[1]+'</country></aff>'                 
         } 
    if(result[data]["AV"]){
        xmldata+='<aff id="aff25"><institution>'+result[data]["AV"].split(", ")[0]+'</institution>, <country>'+result[data]["AV"].split(",")[1]+'</country></aff>'             
     }
        if(result[data]["CA"]){
            xmldata+='<aff id="aff26"><institution>'+result[data]["CA"].split(", ")[0]+'</institution>, <country>'+result[data]["CA"].split(",")[1]+'</country></aff>'                  
        } 
        if(result[data]["DF"]){
            xmldata+='<aff id="aff27"><institution>'+result[data]["DF"].split(", ")[0]+'</institution>, <country>'+result[data]["DF"].split(",")[1]+'</country></aff>'                 
         } 
        if(result[data]["EK"]){
            xmldata+='<aff id="aff28"><institution>'+result[data]["EK"].split(", ")[0]+'</institution>, <country>'+result[data]["EK"].split(",")[1]+'</country></aff>'                  
        } 
    if(result[data]["AW"]){
        xmldata+='<aff id="aff29"><institution>'+result[data]["AW"].split(", ")[0]+'</institution>, <country>'+result[data]["AW"].split(",")[1]+'</country></aff>'                  
    }
        if(result[data]["CB"]){
            xmldata+='<aff id="aff30"><institution>'+result[data]["CB"].split(", ")[0]+'</institution>, <country>'+result[data]["CB"].split(",")[1]+'</country></aff>'                  } 
    
        if(result[data]["DG"]){
            xmldata+='<aff id="aff31"><institution>'+result[data]["DG"].split(", ")[0]+'</institution>, <country>'+result[data]["DG"].split(",")[1]+'</country></aff>'                              } 
        if(result[data]["EL"]){
            xmldata+='<aff id="aff32"><institution>'+result[data]["EL"].split(", ")[0]+'</institution>, <country>'+result[data]["EL"].split(",")[1]+'</country></aff>'                              } 
    if(result[data]["AX"]){
        xmldata+='<aff id="aff33"><institution>'+result[data]["AX"].split(", ")[0]+'</institution>, <country>'+result[data]["AX"].split(",")[1]+'</country></aff>'                          }
        if(result[data]["CC"]){
            xmldata+='<aff id="aff34"><institution>'+result[data]["CC"].split(", ")[0]+'</institution>, <country>'+result[data]["CC"].split(",")[1]+'</country></aff>'                              } 
        if(result[data]["DH"]){
            xmldata+='<aff id="aff35><institution>'+result[data]["DH"].split(", ")[0]+'</institution>, <country>'+result[data]["DH"].split(",")[1]+'</country></aff>'                              } 
        if(result[data]["EM"]){
            xmldata+='<aff id="aff36"><institution>'+result[data]["EM"].split(", ")[0]+'</institution>, <country>'+result[data]["EM"].split(",")[1]+'</country></aff>'                              } 
    if(result[data]["AY"]){
        xmldata+='<aff id="aff37"><institution>'+result[data]["AY"].split(", ")[0]+'</institution>, <country>'+result[data]["AY"].split(",")[1]+'</country></aff>'                          }
        if(result[data]["CD"]){
            xmldata+='<aff id="aff38"><institution>'+result[data]["CD"].split(", ")[0]+'</institution>, <country>'+result[data]["CD"].split(",")[1]+'</country></aff>'                                      } 
        if(result[data]["DI"]){
            xmldata+='<aff id="aff39"><institution>'+result[data]["AY"].split(", ")[0]+'</institution>, <country>'+result[data]["DI"].split(",")[1]+'</country></aff>'                                      } 
        if(result[data]["EN"]){
            xmldata+='<aff id="aff40"><institution>'+result[data]["EN"].split(", ")[0]+'</institution>, <country>'+result[data]["EN"].split(",")[1]+'</country></aff>'                                      } 
    if(result[data]["AZ"]){
        xmldata+='<aff id="aff41"><institution>'+result[data]["AZ"].split(", ")[0]+'</institution>, <country>'+result[data]["AZ"].split(",")[1]+'</country></aff>'                                  }
        if(result[data]["CE"]){
            xmldata+='<aff id="aff42"><institution>'+result[data]["CE"].split(", ")[0]+'</institution>, <country>'+result[data]["CE"].split(",")[1]+'</country></aff>'                                      } 
        if(result[data]["DJ"]){
            xmldata+='<aff id="aff43"><institution>'+result[data]["DJ"].split(", ")[0]+'</institution>, <country>'+result[data]["DJ"].split(",")[1]+'</country></aff>'                                      } 
        if(result[data]["EO"]){
            xmldata+='<aff id="aff44"><institution>'+result[data]["EO"].split(", ")[0]+'</institution>, <country>'+result[data]["EO"].split(",")[1]+'</country></aff>'                                      } 
    if(result[data]["BA"]){
        xmldata+='<aff id="aff45"><institution>'+result[data]["BA"].split(", ")[0]+'</institution>, <country>'+result[data]["BA"].split(",")[1]+'</country></aff>'                                  }
        if(result[data]["CF"]){
            xmldata+='<aff id="aff46"><institution>'+result[data]["CF"].split(", ")[0]+'</institution>, <country>'+result[data]["EF"].split(",")[1]+'</country></aff>'                          
            } 
        if(result[data]["DK"]){
            xmldata+='<aff id="aff47"><institution>'+result[data]["DK"].split(", ")[0]+'</institution>, <country>'+result[data]["DK"].split(",")[1]+'</country></aff>'                                      } 
        if(result[data]["EP"]){
            xmldata+='<aff id="aff48"><institution>'+result[data]["EP"].split(", ")[0]+'</institution>, <country>'+result[data]["EP"].split(",")[1]+'</country></aff>'                                      } 
    if(result[data]["BB"]){
        xmldata+='<aff id="aff49"><institution>'+result[data]["BB"].split(", ")[0]+'</institution>, <country>'+result[data]["BB"].split(",")[1]+'</country></aff>'                                  }
        if(result[data]["CG"]){
            xmldata+='<aff id="aff50"><institution>'+result[data]["CG"].split(", ")[0]+'</institution>, <country>'+result[data]["CG"].split(",")[1]+'</country></aff>'                                      } 
        if(result[data]["DL"]){
            xmldata+='<aff id="aff51"><institution>'+result[data]["DL"].split(", ")[0]+'</institution>, <country>'+result[data]["DL"].split(",")[1]+'</country></aff>'                                      } 
        if(result[data]["EQ"]){
            xmldata+='<aff id="aff52"><institution>'+result[data]["EQ"].split(", ")[0]+'</institution>, <country>'+result[data]["EQ"].split(",")[1]+'</country></aff>'                                      } 
    if(result[data]["BC"]){
        xmldata+='<aff id="aff53"><institution>'+result[data]["BC"].split(", ")[0]+'</institution>, <country>'+result[data]["BC"].split(",")[1]+'</country></aff>'                                  }
        if(result[data]["CH"]){
            xmldata+='<aff id="aff54"><institution>'+result[data]["CH"].split(", ")[0]+'</institution>, <country>'+result[data]["CH"].split(",")[1]+'</country></aff>'                                      } 
        if(result[data]["DM"]){
            xmldata+='<aff id="aff55"><institution>'+result[data]["DM"].split(", ")[0]+'</institution>, <country>'+result[data]["DM"].split(",")[1]+'</country></aff>'                                      } 
        if(result[data]["ER"]){
            xmldata+='<aff id="aff56"><institution>'+result[data]["ER"].split(", ")[0]+'</institution>, <country>'+result[data]["ER"].split(",")[1]+'</country></aff>'                                      } 
    if(result[data]["BD"]){
        xmldata+='<aff id="aff57"><institution>'+result[data]["BD"].split(", ")[0]+'</institution>, <country>'+result[data]["BD"].split(",")[1]+'</country></aff>'                                  }
        if(result[data]["CI"]){
            xmldata+='<aff id="aff58"><institution>'+result[data]["CI"].split(", ")[0]+'</institution>, <country>'+result[data]["CI"].split(",")[1]+'</country></aff>'                                  
        } 
        if(result[data]["DN"]){
            xmldata+='<aff id="aff59"><institution>'+result[data]["DN"].split(", ")[0]+'</institution>, <country>'+result[data]["DN"].split(",")[1]+'</country></aff>'                                  
            } 
        if(result[data]["ES"]){
            xmldata+='<aff id="aff60"><institution>'+result[data]["ES"].split(", ")[0]+'</institution>, <country>'+result[data]["ES"].split(",")[1]+'</country></aff>'                                  
            } 
    if(result[data]["BE"]){
        xmldata+='<aff id="aff61"><institution>'+result[data]["BE"].split(", ")[0]+'</institution>, <country>'+result[data]["BE"].split(",")[1]+'</country></aff>'                                  
    }
        if(result[data]["CJ"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["CJ"].split(", ")[0]+'</institution>, <country>'+result[data]["CJ"].split(",")[1]+'</country></aff>'                                  
            } 
        if(result[data]["DO"]){
            xmldata+='<aff id="aff63"><institution>'+result[data]["DO"].split(", ")[0]+'</institution>, <country>'+result[data]["DO"].split(",")[1]+'</country></aff>'                                  
            } 
        if(result[data]["ET"]){
            xmldata+='<aff id="aff64"><institution>'+result[data]["ET"].split(", ")[0]+'</institution>, <country>'+result[data]["ET"].split(",")[1]+'</country></aff>'                                              } 
    if(result[data]["BF"]){
        xmldata+='<aff id="aff65"><institution>'+result[data]["BF"].split(", ")[0]+'</institution>, <country>'+result[data]["BF"].split(",")[1]+'</country></aff>'                                          }
        if(result[data]["CK"]){
            xmldata+='<aff id="aff66"><institution>'+result[data]["CK"].split(", ")[0]+'</institution>, <country>'+result[data]["CK"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["DP"]){
            xmldata+='<aff id="aff67"><institution>'+result[data]["DP"].split(", ")[0]+'</institution>, <country>'+result[data]["DP"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["EU"]){
            xmldata+='<aff id="aff68"><institution>'+result[data]["EU"].split(", ")[0]+'</institution>, <country>'+result[data]["EU"].split(",")[1]+'</country></aff>'                                              } 
    if(result[data]["BG"]){
        xmldata+='<aff id="aff69"><institution>'+result[data]["BG"].split(", ")[0]+'</institution>, <country>'+result[data]["BG"].split(",")[1]+'</country></aff>'                                          }
        if(result[data]["CL"]){
            xmldata+='<aff id="aff70"><institution>'+result[data]["CL"].split(", ")[0]+'</institution>, <country>'+result[data]["CL"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["DQ"]){
            xmldata+='<aff id="aff712"><institution>'+result[data]["DQ"].split(", ")[0]+'</institution>, <country>'+result[data]["DQ"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["EV"]){
            xmldata+='<aff id="aff72"><institution>'+result[data]["EV"].split(", ")[0]+'</institution>, <country>'+result[data]["EV"].split(",")[1]+'</country></aff>'                                              } 
     if(result[data]["BH"]){
        xmldata+='<aff id="aff73"><institution>'+result[data]["BH"].split(", ")[0]+'</institution>, <country>'+result[data]["BH"].split(",")[1]+'</country></aff>'                                          }
        if(result[data]["CM"]){
            xmldata+='<aff id="aff74"><institution>'+result[data]["CM"].split(", ")[0]+'</institution>, <country>'+result[data]["CM"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["DR"]){
            xmldata+='<aff id="aff75"><institution>'+result[data]["DR"].split(", ")[0]+'</institution>, <country>'+result[data]["DR"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["EW"]){
            xmldata+='<aff id="aff76"><institution>'+result[data]["EW"].split(", ")[0]+'</institution>, <country>'+result[data]["EW"].split(",")[1]+'</country></aff>'                                              } 
    if(result[data]["BI"]){
        xmldata+='<aff id="aff77"><institution>'+result[data]["BI"].split(", ")[0]+'</institution>, <country>'+result[data]["BI"].split(",")[1]+'</country></aff>'                                          }
        if(result[data]["CN"]){
            xmldata+='<aff id="aff78"><institution>'+result[data]["CN"].split(", ")[0]+'</institution>, <country>'+result[data]["CN"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["DS"]){
            xmldata+='<aff id="aff79"><institution>'+result[data]["DS"].split(", ")[0]+'</institution>, <country>'+result[data]["DS"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["EX"]){
            xmldata+='<aff id="aff80"><institution>'+result[data]["EX"].split(", ")[0]+'</institution>, <country>'+result[data]["EX"].split(",")[1]+'</country></aff>'                                              } 

    if(result[data]["BJ"]){
        xmldata+='<aff id="aff81"><institution>'+result[data]["BJ"].split(", ")[0]+'</institution>, <country>'+result[data]["BJ"].split(",")[1]+'</country></aff>'                                          }
        if(result[data]["CO"]){
            xmldata+='<aff id="aff82"><institution>'+result[data]["CO"].split(", ")[0]+'</institution>, <country>'+result[data]["CO"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["DT"]){
            xmldata+='<aff id="aff83"><institution>'+result[data]["DT"].split(", ")[0]+'</institution>, <country>'+result[data]["DT"].split(",")[1]+'</country></aff>'                                              } 
            if(result[data]["EY"]){
                xmldata+='<aff id="aff84"><institution>'+result[data]["EY"].split(", ")[0]+'</institution>, <country>'+result[data]["EY"].split(",")[1]+'</country></aff>'                                                  } 
        
    if(result[data]["BK"]){
        xmldata+='<aff id="aff85"><institution>'+result[data]["BK"].split(", ")[0]+'</institution>, <country>'+result[data]["BK"].split(",")[1]+'</country></aff>'                                  
        }
        if(result[data]["CP"]){
            xmldata+='<aff id="aff86"><institution>'+result[data]["CP"].split(", ")[0]+'</institution>, <country>'+result[data]["CP"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["DU"]){
            xmldata+='<aff id="aff87"><institution>'+result[data]["DU"].split(", ")[0]+'</institution>, <country>'+result[data]["DU"].split(",")[1]+'</country></aff>'                                              } 
            if(result[data]["EZ"]){
                xmldata+='<aff id="aff88"><institution>'+result[data]["EZ"].split(", ")[0]+'</institution>, <country>'+result[data]["EZ"].split(",")[1]+'</country></aff>'                                                  } 
    if(result[data]["BL"]){
        xmldata+='<aff id="aff89"><institution>'+result[data]["BL"].split(", ")[0]+'</institution>, <country>'+result[data]["BL"].split(",")[1]+'</country></aff>'                                          }
        if(result[data]["CQ"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["CQ"].split(", ")[0]+'</institution>, <country>'+result[data]["CQ"].split(",")[1]+'</country></aff>'                                              }
        if(result[data]["DV"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["DV"].split(", ")[0]+'</institution>, <country>'+result[data]["DV"].split(",")[1]+'</country></aff>'                                              } 
            if(result[data]["FA"]){
                xmldata+='<aff id="aff62"><institution>'+result[data]["FA"].split(", ")[0]+'</institution>, <country>'+result[data]["FA"].split(",")[1]+'</country></aff>'                                                  } 

    if(result[data]["BM"]){
        xmldata+='<aff id="aff62"><institution>'+result[data]["BM"].split(", ")[0]+'</institution>, <country>'+result[data]["BM"].split(",")[1]+'</country></aff>'                                          }
        if(result[data]["CR"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["CR"].split(", ")[0]+'</institution>, <country>'+result[data]["CR"].split(",")[1]+'</country></aff>'                                              }
        if(result[data]["DW"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["DW"].split(", ")[0]+'</institution>, <country>'+result[data]["DW"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["FB"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["FB"].split(", ")[0]+'</institution>, <country>'+result[data]["FB"].split(",")[1]+'</country></aff>'                                              } 
    if(result[data]["BN"]){
        xmldata+='<aff id="aff62"><institution>'+result[data]["BN"].split(", ")[0]+'</institution>, <country>'+result[data]["BN"].split(",")[1]+'</country></aff>'                                          }
        if(result[data]["CS"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["CS"].split(", ")[0]+'</institution>, <country>'+result[data]["CS"].split(",")[1]+'</country></aff>'                                              }
        if(result[data]["DX"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["DX"].split(", ")[0]+'</institution>, <country>'+result[data]["DX"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["FC"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["FC"].split(", ")[0]+'</institution>, <country>'+result[data]["FC"].split(",")[1]+'</country></aff>'                                              } 

    if(result[data]["BO"]){
        xmldata+='<aff id="aff62"><institution>'+result[data]["BO"].split(", ")[0]+'</institution>, <country>'+result[data]["BO"].split(",")[1]+'</country></aff>'                                          }
        if(result[data]["CT"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["CT"].split(", ")[0]+'</institution>, <country>'+result[data]["CT"].split(",")[1]+'</country></aff>'                                              }
        if(result[data]["DY"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["DY"].split(", ")[0]+'</institution>, <country>'+result[data]["DY"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["FD"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["FD"].split(", ")[0]+'</institution>, <country>'+result[data]["FD"].split(",")[1]+'</country></aff>'                                              }    
        
    if(result[data]["BP"]){
        xmldata+='<aff id="aff62"><institution>'+result[data]["BP"].split(", ")[0]+'</institution>, <country>'+result[data]["BP"].split(",")[1]+'</country></aff>'                                          }
        if(result[data]["CU"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["CU"].split(", ")[0]+'</institution>, <country>'+result[data]["CU"].split(",")[1]+'</country></aff>'                                              }
        if(result[data]["DZ"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["DZ"].split(", ")[0]+'</institution>, <country>'+result[data]["DZ"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["FE"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["FE"].split(", ")[0]+'</institution>, <country>'+result[data]["FE"].split(",")[1]+'</country></aff>'                                              }
    if(result[data]["BQ"]){
        xmldata+='<aff id="aff62"><institution>'+result[data]["BQ"].split(", ")[0]+'</institution>, <country>'+result[data]["BQ"].split(",")[1]+'</country></aff>'                                          }
        if(result[data]["CV"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["CV"].split(", ")[0]+'</institution>, <country>'+result[data]["CV"].split(",")[1]+'</country></aff>'                                              }
        if(result[data]["EA"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["EA"].split(", ")[0]+'</institution>, <country>'+result[data]["EA"].split(",")[1]+'</country></aff>'                                              } 
        if(result[data]["FF"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["FF"].split(", ")[0]+'</institution>, <country>'+result[data]["FF"].split(",")[1]+'</country></aff>'                                              }

    if(result[data]["BR"]){
        xmldata+='<aff id="aff62"><institution>'+result[data]["BR"].split(", ")[0]+'</institution>, <country>'+result[data]["BR"].split(",")[1]+'</country></aff>'                                          }
        if(result[data]["CW"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["CW"].split(", ")[0]+'</institution>, <country>'+result[data]["CW"].split(",")[1]+'</country></aff>'                                              }
        if(result[data]["EB"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["EB"].split(", ")[0]+'</institution>, <country>'+result[data]["EB"].split(",")[1]+'</country></aff>'                                              }     
        if(result[data]["FG"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["FG"].split(", ")[0]+'</institution>, <country>'+result[data]["FG"].split(",")[1]+'</country></aff>'                                              }
    
    if(result[data]["BS"]){
        xmldata+='<aff id="aff62"><institution>'+result[data]["BS"].split(", ")[0]+'</institution>, <country>'+result[data]["BS"].split(",")[1]+'</country></aff>'                                          }
        if(result[data]["CX"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["CX"].split(", ")[0]+'</institution>, <country>'+result[data]["CX"].split(",")[1]+'</country></aff>'                                              }
        if(result[data]["EC"]){
            xmldata+='<aff id="aff62"><institution>'+result[data]["EC"].split(", ")[0]+'</institution>, <country>'+result[data]["EC"].split(",")[1]+'</country></aff>'                                              } 
    if(result[data]["FH"]){
        xmldata+='<aff id="aff62"><institution>'+result[data]["FH"].split(", ")[0]+'</institution>, <country>'+result[data]["FH"].split(",")[1]+'</country></aff>'                                          }

    if(result[data]["BT"]){
        xmldata+='<aff id="aff62"><institution>'+result[data]["BT"].split(", ")[0]+'</institution>, <country>'+result[data]["BT"].split(",")[1]+'</country></aff>'                                          }
    if(result[data]["CY"]){
        xmldata+='<aff id="aff62"><institution>'+result[data]["CY"].split(", ")[0]+'</institution>, <country>'+result[data]["CY"].split(",")[1]+'</country></aff>'                                          }
    if(result[data]["ED"]){
        xmldata+='<aff id="aff62"><institution>'+result[data]["ED"].split(", ")[0]+'</institution>, <country>'+result[data]["ED"].split(",")[1]+'</country></aff>'                                          }
    if(result[data]["FI"]){
        xmldata+='<aff id="aff62"><institution>'+result[data]["FI"].split(", ")[0]+'</institution>, <country>'+result[data]["FI"].split(",")[1]+'</country></aff>'                                          }
                  
    xmldata+='</contrib-group><author-notes>'
    xmldata+='<corresp id="cor1">&#x002A;<bold>Correspondence:</bold>'+result[data]["D"]+', <email xlink:href="'+result[data]["C"]+'" xlink:type="simple">'+result[data]["C"]+'</email></corresp></author-notes>'
    xmldata+='<pub-date pub-type="ppub"><month>7</month><year>2020</year></pub-date><pub-date pub-type="epub"><day>10</day><month>07</month><year>2020</year></pub-date><volume>2</volume><issue>7A</issue><elocation-id>2</elocation-id>'
    xmldata+='<permissions><copyright-statement>&#x00A9; 2021 The Authors</copyright-statement><copyright-year>2021</copyright-year><license license-type="open-access" xlink:href="http://creativecommons.org/licenses/by/4.0/"><license-p>This is an open-access article distributed under the terms of the Creative Commons Attribution License.</license-p></license></permissions>'
    xmldata+='<self-uri xlink:href="'+result[data]["B"].replace(/10.1099\//,'')+'.pdf" content-type="pdf"/>'
    xmldata+='<abstract><p>'+result[data]["G"].replace(/\n/,'</p><p>')+'</p></abstract>';
    xmldata+='<custom-meta-group><custom-meta><meta-name>OpenAccessEmbargo</meta-name><meta-value>0</meta-value></custom-meta></custom-meta-group></article-meta></front></article>';
    //xmldata = format(xmldata);// this line for giving indentation in xml file
    console.log(xmldata);
    fs.writeFile('./xml/'+result[data]["B"].replace(/10.1099\//,'')+'.xml', [xmldata], function (data, err){
        if(err) console.log(err);
        if(!err)console.log("success");
    });

 }

 console.log("Completed");


    http.createServer(function (req, res) {

    }).listen(5555);
