<html lang="en">
<head>
<meta charset="utf-8">
<meta content="IE=edge" http-equiv="X-UA-Compatible">
<meta content="width=device-width, initial-scale=1" name="viewport">
<meta content="" name="description">
<meta content="" name="Exeter">
<title>Exeter Premedia Services</title>
<link rel="stylesheet" href="sb-admin/css/bootstrap.min.css">
<link rel="stylesheet" href="sb-admin/css/sb-admin.css">
<link rel="stylesheet" href="sb-admin/css/bootstrap.css">   <script src="js/jquery-1.2.6.min.js" type="text/javascript">
</script>    <script src="js/jquery.js">
</script> <script src="js/jquery.form.js">
</script>
<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 7px 16px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}
.button2 {
    background-color: white; 
    color: black; 
    border: 2px solid #008CBA;
}

.button2:hover {
    background-color: #008CBA;
    color: white;
}
</style>
</head>
<body>
<div id="wrapper">
<!-- Navigation -->
<div class="container-fluid">
<div class="col-sm-12 col-lg-12 col-xs-12 col-md-12" style="height:30px">
</div>
<div id="mainPage" class="row">
<div class="col-sm-10 col-lg-10 col-xs-10 col-md-10 col-sm-offset-1 col-lg-offset-1 col-xs-offset-1 col-md-offset-1">
<div class="panel panel-primary">
<div class="panel-heading">
<span>Get Count</span>
</div>
<div class="panel-body">
<form name="f1" action="get_count.php" id="packageform"  enctype="multipart/form-data" method="post"  class="form-horizontal">
<div class="form-group" id="articleID">
<label for="articleID" class="col-sm-2 control-label">MS number</label>
<div class="col-sm-8">
<input type="text" class="form-control" name="articleID" id="articleID">
</div>
</div>
<div class="form-group" id="client">
<label for="client" class="col-sm-2 control-label">Client</label>
<div class="col-sm-8">
<select type="text" class="form-control" name="client" id="client">
<option value="bmj" type="option">BMJ</option>
<!--<option value="elife1" type="option">eLife1</option>
<option value="elife2" type="option">eLife2</option>
<option value="mbs" type="option">Microbiology</option>
<option value="bir" type="option">BJRCR</option>	-->
</select>
</div>
</div>
<div class="form-group" id="Countfor">
<label for="Countfor" class="col-sm-2 control-label">Select attribute</label>
<div class="col-sm-8">
<select type="text" class="form-control" name="Countfor" id="Countfor">
<option value="page-count" type="option">Page Count</option>
<option value="page-count" type="option">Page Count</option>
<!-- <option value="Upload for Online First" type="option">Upload for Online First</option>
<option value="Validation check" type="option">Validation check</option> -->
</select>
</div>
</div>

<div class="form-group" id="Countfor">
<label for="Countfor" class="col-sm-2 control-label">Select value</label>
<div class="col-sm-8">
<select type="text" class="form-control" name="Countfor" id="Countfor">
<option value="true" type="option">true</option>
<option value="false" type="option">false</option>
<!-- <option value="Upload for Online First" type="option">Upload for Online First</option>
<option value="Validation check" type="option">Validation check</option> -->
</select>
</div>
</div>

<div class="form-group" align="center">
<div class="col-sm-offset-2 col-sm-8">
<button type='submit' class="button button2" value='Get count'>Get count</button>
<span id='loadingspan' style="display:none">
<img src="includes/loadingnew.gif">
</span>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>