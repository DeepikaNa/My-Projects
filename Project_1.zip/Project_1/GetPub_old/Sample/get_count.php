<html>
<head>
<style>
#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 50%;
		text-align: center;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
	text-align: center;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
	text-align: center;
}
</style>
</head>
<body>

<table id="customers" align="center">
  <tr>
    <th>DOI</th>
    <th>Page Count</th>
  </tr>
<?php
ini_set("display_errors", "0");
ini_set('max_execution_time', 600);
if (!class_exists('JSLikeHTMLElement')){
	require_once './JSLikeHTMLElement.php';
}
$selectParam = 'f_text';
$dbName = 'bmj';
$tbName = 't_articles';
 $client = $_POST['client'];
$articleIDS = $_POST['articleID'];
$Countfor = $_POST['Countfor'];
$articles = preg_split("/[\s,:]+/", $articleIDS);
foreach($articles as $article){
	$link = mysql_connect('cms31.ama.uk.com:33065', '__eps.contentq', 'Ex3t36@Pass');
	if (!$link) {
		die('Could not connect: ' . mysql_error());
	}
	$sql = 'select cmsID from `content_loading`.`__t_contentQueue` where manuscriptID = "'. $article.'"';
	$result = mysql_query ( $sql );
	$rowcount=mysql_num_rows($result);
	if (!$result) {
        echo 'Could not run query: ' . mysql_error();
        exit;
    }
	while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
        $cmsid = $row[cmsID]; 
    }
	if($rowcount > 1){
		$link1 = mysql_connect('cms30.ama.uk.com:33065', '__eps.anuraja', 'anu123');
		if (!$link1) {
			die('Could not connect: ' . mysql_error());
		}
		$sql = "select ".$selectParam." from `".$dbName."`.".$tbName." where f_children = '$cmsid'";
		$result1 = mysql_query ( $sql );
		$rowcount1 = mysql_num_rows($result1);
		if (!$result1) {
			echo 'Could not run query: ' . mysql_error();
			exit;
		}
		if($rowcount1  > 0){
			while ($row = mysql_fetch_array($result1, MYSQL_ASSOC)) {
				$file = $row[$selectParam]; 
			}
			$file = mb_convert_encoding($file, 'HTML-ENTITIES', "UTF-8");
			$dom = new DOMDocument();
			$dom->registerNodeClass('DOMElement', 'JSLikeHTMLElement');
			$dom->loadHTML($file);
			$xpath = new DOMXPath($dom);
			$workflow = $xpath->query('//workflow');
			foreach($workflow as $pagecount){
				if($pagecount->hasAttribute('page-count')){
					$pagecount = $pagecount->getAttribute('page-count');
				}else{
					$pagecount = 'N/A';
				}
			}
			echo '<tr><td>'.$article.'</td><td>'.$pagecount.'</td></tr>';
		}else{
			echo '<tr><td>'.$article.'</td><td>N/A</td></tr>';
		}
	}else{
		echo '<tr><td>'.$article.'</td><td>Not in contentQ</td></tr>';
}
	}
	
?>
</table>

</body>
</html>