<?php
//echo '<div class="content"><div></div></div>';
// we connect to example.com and port 3307
ini_set("max_execution_time", "0");
ini_set("display_errors", "0");
if (!class_exists('JSLikeHTMLElement')){
    require_once './JSLikeHTMLElement.php';
}
//$link = mysql_connect('cms32.ama.uk.com:33065', '__build.exeter', '__build.exeter@cms3__');
$link = mysql_connect('cms32.ama.uk.com:33065', '__eps.anuraja', 'anu123');
if (!$link) {
    die('Could not connect: ' . mysql_error());
}
$articleArray = "141173,180103,160803,195563,196473,189783,201043,246351,243841,223143,180403,258261,270273,272793,280293,193473,289613,229153";
$fromstg = 'Upload for Online First';
$tostg = 'Validation check';
$selectParam = 'f_text';
$dbName = 'bmj';
$tbName = 't_articles';
$date = date("Y-m-d_h:i");
$userName = 'Charles';
$articles = preg_split("/[\s,:]+/", $articleArray);
foreach ($articles as $article){
	$sql = "select ".$selectParam." from `".$dbName."`.".$tbName." where f_children = '$article'";
    $result = mysql_query ( $sql );
    if (!$result) {
        echo 'Could not run query: ' . mysql_error();
        exit;
    }
	while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
        $file = $row[$selectParam]; 
    }
	$file = mb_convert_encoding($file, 'HTML-ENTITIES', "UTF-8");
    file_put_contents($article.'.xml', $file);
	$dom = new DOMDocument();
    $dom->registerNodeClass('DOMElement', 'JSLikeHTMLElement');
    $dom->loadHTML($file);
	$xpath = new DOMXPath($dom);
	/*$abbs = $xpath->query('//front//abbrev-journal-title');
	foreach ($abbs as $abb){
		$abbText = $abb->nodeValue;
		if ($abbText != 'BMJ Sex Reprod Health'){
			$abb->nodeValue = 'BMJ Sex Reprod Health';
		}
	}
	$abbs = $xpath->query('//front//abbrev-journal-title');
	foreach ($abbs as $abb){
		$abbText = $abb->nodeValue;
		if ($abbText != 'BMJ Sex Reprod Health'){
			$abb->nodeValue = 'BMJ Sex Reprod Health';
		}
	}
	$abbs = $xpath->query('//front//journal-title');
	foreach ($abbs as $abb){
		$abbText = $abb->nodeValue;
		if ($abbText != 'BMJ Sexual & Reproductive Health'){
			$abb->nodeValue = 'BMJ Sexual & Reproductive Health';
		}
	}
	$abbs = $xpath->query('//front//publisher-name');
	foreach ($abbs as $abb){
		$abbText = $abb->nodeValue;
		if ($abbText != 'BMJ Publishing Group'){
			$abb->nodeValue = 'BMJ Publishing Group';
		}
	}
	$abbs = $xpath->query('//front//publisher-loc');
	foreach ($abbs as $abb){
		$abbText = $abb->nodeValue;
		if ($abbText != 'BMJ Publishing Group'){
			$abb->nodeValue = 'BMA House, Tavistock Square, London, WC1H 9JR';
		}
	}
	$abbs = $xpath->query('//issn');
	foreach ($abbs as $abb){
		$value = $abb->getAttribute('pub-type');
		if ($value == 'ppub'){
			$abbText = $abb->nodeValue;
			if ($abbText != 'BMJ Publishing Group'){
				$abb->nodeValue = '2515-2009';
			}
		}
		$value = $abb->getAttribute('pub-type');
		if ($value == 'epub'){
			$abbText = $abb->nodeValue;
			if ($abbText != 'BMJ Publishing Group'){
				$abb->nodeValue = '2515-1991';
			}
		}
	}
	$abbs = $xpath->query('//journal-id');
	foreach ($abbs as $abb){
		$value = $abb->getAttribute('journal-id-type');
		if ($value == 'hwp'){
			$abbText = $abb->nodeValue;
			if ($abbText != 'BMJ Publishing Group'){
				$abb->nodeValue = 'bmjsrh';
			}
		}
	}
	$journals = $xpath->query('//journal-id');
	foreach ($journals as $journal){
		$value = $journal->getAttribute('journal-id-type');
		if ($jvalue == 'publisher-id'){
			$abbText = $journal->nodeValue;
			if ($abbText != 'BMJ Publishing Group'){
				$journal->nodeValue = 'bmjsrh';
			}
		}
	}
	foreach($stages as $stage){
		if ($stage->hasAttribute('name')){
			$stgname = $stage->getAttribute('name');
			if ($stgname == 'Ready for Online'){
				$task = $stage->firstChild;
				$task->setAttribute('status', 'waiting');
				$task->setAttribute('name', 'start');
			}
			if ($stgname == 'Validation check'){
				$task = $stage->firstChild;
				$task->setAttribute('status', 'in-progress');
				$task->setAttribute('name', 'start');
			}
		}
	}*/
	//echo $dom->saveXML();
	$mains = $xpath->query('//body');
    foreach ($mains as $main) {
		$main = $main->innerHTML;
    }
    echo '<article>'.$dom->saveXML().'</article>';
	echo '<br/>';
	echo '<br/>';
	echo '<br/>';
	echo '<br/>';
	echo '<br/>';
	$var123 =  $main;
    $var123 = mb_convert_encoding($var123, 'HTML-ENTITIES', "UTF-8");
    $text123 = addslashes($var123);
	//$sql1 = "UPDATE `".$dbName."`.`".$tbName."` SET `".$selectParam."`='".$text123."' WHERE f_children='".$article."'";
    //$result1 = mysql_query ($sql1);
    if ($result1) {
    	echo    '<br/>UPDATED SUCCESS FULLY'.$result1;
    	 
    }else{
    	echo 'Could not run query: ' . mysql_error();
    	 
    }
}
?>
