<?php 
session_start();
?>
<div class="navbar navbar-inverse">
	<div class="container">
		<div class="navbar-header">
			<a href="#" class="navbar-brand" style="color:white;">Exeter Premedia
				<?php 
					//echo ' [ '.$_SESSION['userName'].' ]';
				?>
			</a>
		</div>
		<div class="navbar-collapse collapse navbar-right">
			<ul class="nav navbar-nav">
				
			</ul>
		</div>
	</div>
	<script>
		$(document).ready(function(){
			$('.nav .dropdown').hover(function(){
				$(this).addClass('open');
			},function(){
				$(this).removeClass('open');
			});
		});
	</script>
</div>