<?php
session_start();
//ini_set ('display_errors', true);

/*
 * package create class
 * 
 * */
class packageCreator{
	private $xmlFilePath = '';		## holds the path input xml
	private $xmlDom = ''; 			## holds the xml dom object
	private $xmlXpath = ''; 		## holds the xml xpath object
	private $cDom = ''; 			## holds the dom of the package xml config file
	private $cXpath = ''; 			## holds the xpath of the package xml config dom
	private $resourceFolder = ''; 	## holds the path to the resources folder
	private $packageNames = '';  	## holds the name of the packages to be created, e.g., "hws,aws"
	private $basefolder = '';       ## holds the path to the resources folder
	private $nodeName = '';         ## holds the dynamic variable name
	private $variablesHash = '';	## holds the dynamically generated variables in a hash 
	private $varFormatHash = '';	## holds the dynamically generated variable's format in a hash 
	private $contentstring  =   '';
	
	/**
	 * constructor for packageCreator class
	 * @param {$xmlFilePath} - String - file path of the xml
	 * @param {$resourceFolder} - String - folder where the resource files like figure, pdf, etc. is present
	 * @param {$packageXMLFilePath} - String - file path of the config xml
	 * @param {$packageNames} - String - comma seperated list of packages to be created
	 */
	public function __construct($xmlFilePath, $resourceFolder, $packageXMLFilePath, $packageNames){
		## load the given xml file into dom
                
                $this->contentstring    = file_get_contents($xmlFilePath);
		$xmlDom = new DOMDocument('1.0', 'utf8');
		$xmlDom->load($xmlFilePath);
		$xmlXpath = new DOMXPath($xmlDom);
		$this->xmlDom = $xmlDom;
		$this->xmlXpath = $xmlXpath;
		$this->xmlFilePath = $xmlFilePath;
		
		## load the config file into dom
		$cDom = new DOMDocument('1.0', 'utf8');
		$cDom->load($packageXMLFilePath);
		$cXpath = new DOMXPath($cDom);
		$this->cDom = $cDom;
		$this->cXpath = $cXpath;
		
		$this->packageNames = $packageNames;
		$this->resourceFolder = $resourceFolder;
		//$this->nodeName = $nodeName;
	}
	
	/**
	 * function to create the package using the package xml config file
	 * 
	 * */
	public function callPacker(){		
		$xmlDom = $this->xmlDom;
		$xmlXpath = $this->xmlXpath;
		$cDom = $this->cDom;
		$cXpath = $this->cXpath;
		$packageNames = $this->packageNames;
		$resourceFolder = $this->resourceFolder;
		
		$xmlFilePath = $this->xmlFilePath;
		//$nodeName = $this->nodeName;
		
		## create a physical folder in the name of $packageNames
		if (!file_exists($resourceFolder.'/'.$packageNames))
			mkdir($resourceFolder.'/'.$packageNames);
		chdir($resourceFolder.'/'.$packageNames);
		chmod($resourceFolder.'/'.$packageNames, 0777);
		
		$GLOBALS['basefolder'] = $resourceFolder;//$basefolder is assigned to get the files from this path
		$resourceFolder = getcwd();//points to the path of physical folder with name $packageNames
		
		$this->initializeVariable($packageNames,$cXpath,$xmlXpath);
		//supplymentry id format change
		//$this->supplymentryformat();
		
		$output_zips	=	$this->createPackage($packageNames);
                $xmlFilePath    =       $this->xmlFilePath;
		foreach($output_zips as $output_zip){
                    if(file_exists($output_zip)){
			chmod($output_zip, 0777);
                        $za = new ZipArchive(); 
			//$za->open($output_zip); 
			if ($za->open($output_zip) === TRUE) {
				$numberofinputfiles	=	array();
				for( $i = 0; $i < $za->numFiles; $i++ ){ 
				    $stat = $za->statIndex( $i ); 
				    //echo basename( $stat['name'] ).' => '.basename($xmlFilePath).'<br>';
				    if(basename( $stat['name'] ) == basename($xmlFilePath)){				    			    	
				    	//$za->deleteName($stat['name']);
				    	array_push($numberofinputfiles,$stat['name']);
				    	
				    } 
				}
			}			
			
			$za->close();
			foreach($numberofinputfiles as $numberofinputfile){
				$za = new ZipArchive(); 
				if ($za->open($output_zip) === TRUE) {
					$za->addFile($xmlFilePath,$numberofinputfile);
				}
				$za->close();
			}
                    }
			
        }
        
        return $output_zips;
	}

	/**
	 * function to define dynamic variables
	 * @param {$packageNames} - String - name of the package to be cteated
	 * @param {$cXpath} - Object - dom object of package xml
	 * @param {$xmlXpath} - Object - dom object of article xml
	 * */
	private function initializeVariable($packageNames,$cXpath,$xmlXpath){
		
		//get the childs of node variables under the specified package
		$variables = $cXpath->query('//package[@name = "'.$packageNames.'"]/variables/*');
		//$variablecollection = array();
	
		foreach($variables as $variableIndex => $variable){
			//get the value of attribute xpath from config xml
			if($variable->hasAttribute('xpath')){
				$xpathVariable = $variable->getAttribute('xpath');
				//using the $xpathVariable assign dynamic variable and its value
				//assign dynamic variable as global
				$elementNodes = $xmlXpath->query($xpathVariable);
				foreach($elementNodes as $elementNode){
					$elementNodeValue = $elementNode->nodeValue;
					/* if($variable->hasAttribute('format')){
					 $formatValue = $variable->getAttribute('format');
					$elementNodeValue = sprintf($formatValue, $elementNodeValue);
					} */
					$this->variablesHash[$variable->nodeName] = $elementNodeValue;
				}
			}
			## this is a special variable that stores the sequence of the files
			elseif ($variable->nodeName == 'seqno'){
					$this->variablesHash['startFrom'] =	'1';
					if($variable->hasAttribute('startFrom')){
						$this->variablesHash['startFrom'] = $variable->getAttribute('startFrom');
					}
					$this->variablesHash['type']   =	$variable->getAttribute('type');
					$this->variablesHash['format'] = 	$variable->getAttribute('format');
			}
		}
	}

	private function createPackage($packageNames){
		$cDom = $this->cDom;
		$cXpath = $this->cXpath;
		$xmlDom	=	$this->xmlDom;
		
		## get the child nodes of the element that has attribute name with package name as value. i.e name='hwx' and flow through it.
		$zipNodes = $cXpath->query('//package[@name = "'.$packageNames.'"]/zip');
		$length = $zipNodes->length;
		
		$zipNamearray	=	array();
		
		foreach($zipNodes as $index => $zipNode){			
			//create package using the value of dynamic variable
			if($zipNode->hasAttribute('name')){
				$zipNodeName = $zipNode->getAttribute('name');				
				$zipName = $this->resourceFolder . '/' . $packageNames . '/' . $this->resolveVariableNames($zipNodeName) . '.zip';
				$zipObject = new ZipArchive();
				//$status = $zipObject->open($zipName, ZIPARCHIVE::CREATE);
				if ($zipObject->open($zipName, ZipArchive::CREATE) === TRUE){ 
					$childNodes = $cXpath->query('./*', $zipNode);					
					foreach ($childNodes as $childNode){
						$this->copyFiles('', $childNode, $cXpath, $zipObject,false);
					}
					array_push($zipNamearray,$zipName);
				}
				$zipObject->close();
			} 
		}		
		//$xmlDom->save($this->xmlFilePath);
                file_put_contents($this->xmlFilePath, $this->contentstring);
                //file_put_contents($this->resourceFolder.'/output.html', $this->contentstring);
		return $zipNamearray;
	}
	
	private function resolveVariableNames($nameWithVariables){
		while (preg_match('/{([a-z0-9]+)}/i', $nameWithVariables, $zipNameMatches)){
			$nameWithVariables = preg_replace('/' . $zipNameMatches[0] . '/i', $this->variablesHash[$zipNameMatches[1]], $nameWithVariables);
		}
		return $nameWithVariables;
	}

	private function copyFiles($baseName, $childNode, $cXPath, $zipObject,$parentNode=false){
		
		$xmlXpath	=	$this->xmlXpath;
		## check if the nodetype is folder or file
		if (strtolower($childNode->nodeName) == 'folder'){
			## if the nodetype is folder get the folder name and add it to base path;
			$baseName = $baseName . '/' . $this->resolveVariableNames($childNode->getAttribute('name'));
			$myChildNodes = $cXPath->query('./*', $childNode);
			foreach ($myChildNodes as $myChildNode){
				$this->copyFiles($baseName, $myChildNode, $cXPath, $zipObject,false);
			}
		}
		## if the nodetype is file and the node does not have the xpath attribute
		## then the file is present inside the resource location
		else if ((strtolower($childNode->nodeName) == 'file') && (!$childNode->hasAttribute('xpath'))){
			$fileNameExt   	=	'';
			if($childNode->hasAttribute('extension'))
				$fileNameExt   	=	$childNode->getAttribute('extension');
				//echo $childNode->getAttribute('name');
			$fileNameInZip = $this->resolveVariableNames($childNode->getAttribute('name'));						
			$fileName = $this->resourceFolder . '/' . $fileNameInZip.$fileNameExt;
                        if($fileNameExt =='.xml'){
                            rename($this->xmlFilePath, $fileName);
                            $this->xmlFilePath=$fileName;
                        }
                        
			$zipObject->addFile($fileName, trim($baseName . '/' . $fileNameInZip.$fileNameExt, '/ '));
		}
		## if the nodetype is file and has xpath attribute read the xml to get the file names
		else if ((strtolower($childNode->nodeName) == 'file') && ($childNode->hasAttribute('xpath'))){
			$xpathVariable 	= $childNode->getAttribute('xpath');
			if(!$parentNode){				
				$elementNodes 	= $xmlXpath->query($xpathVariable);
			}
			else{				
				$elementNodes 	= $xmlXpath->query($xpathVariable,$parentNode);				
			}			
			
			$fileNameExt   	=	'';
			if($childNode->hasAttribute('extension'))
				$fileNameExt   	=	$childNode->getAttribute('extension');				

			if($elementNodes->length > 0){
				$seqno	=	1;
				if(isset($this->variablesHash['startFrom']))
					$seqno	=	$this->variablesHash['startFrom'];
					
				foreach($elementNodes as $elementNode){
					$this->variablesHash['seqno'] 	  =	$seqno;
					if(isset($this->variablesHash['format']) && $this->variablesHash['type']=='number'){
						$this->variablesHash['seqno'] = sprintf($this->variablesHash['format'], $seqno);
					}
					
					$fileName 	 = 	$this->resolveVariableNames($childNode->getAttribute('name'));
					$elemntfile  =  $this->resourceFolder . '/' .basename($elementNode->getAttribute($childNode->getAttribute('attrib')));
					
					
					## convert image using imagic
					if($childNode->hasAttribute('convert') && $childNode->getAttribute('convert')=='true'){
						try{
							chmod($elemntfile, 0777);							
							$im 		= new Imagick($elemntfile);	
							$elemntfile		=	$this->convertImage($im,$fileNameExt);
						}
						catch(Exception $e) {
							
						}	
					}
                                        
                                        

					if(!file_exists($elemntfile)){
						$elemntfile	=	$elemntfile.$fileNameExt;
					}
                                        
                                        $fileNameN	 =	$fileName.$fileNameExt;                    
                                        $zipObject->addFile($elemntfile, $fileNameN);
                                        
                                        //echo $childNode->getAttribute('attrib').' '.$elementNode->nodeName.' '.$fileName.'<br>';
                                        $this->contentstring    = str_replace($elementNode->getAttribute($childNode->getAttribute('attrib')),$fileName,$this->contentstring);
                                        $elementNode->setAttribute($childNode->getAttribute('attrib'),$fileName);
                    
                    /*Child node process supplymenty fig*/
					if($childNode->hasChildNodes()){
						$this->variablesHash['figseqno']	=	$this->variablesHash['seqno'];
						foreach ($childNode->childNodes as $myChildNode){
							$this->copyFiles($baseName, $myChildNode, $cXPath, $zipObject,$elementNode);
						}
					}
                    $seqno++;
				}
			}
		}
	}
	
	
	private function supplymentryformat(){
		$xmlXpath	=	$this->xmlXpath;
		
		$elementNodes 	= $xmlXpath->query("//supplementary-material");
		
		foreach($elementNodes as $elementNode){
			if($elementNode->hasAttribute('id')){
				$id	=	$elementNode->getAttribute('id');
				if ( preg_match ( '/\d+/', $id, $matches ) )
				{				
				    $newid	=	$matches[0];
				}
				
				$newid	=	'SD'.$newid.'-data';
				$elementNode->setAttribute('id',$newid);
				$xhrefNodes 	= $xmlXpath->query("//xref[@ref-type='supplementary-material'][@rid='".$id."']");
				
				foreach($xhrefNodes as $xhrefNode){
					$xhrefNode->setAttribute('rid',$newid);
				}
			}
		}
		
	}
	
	/**
	 * function to convert image
	 * @param {$img} - Object - Imagick object of input
	 * @param {$Extension} - String - Extension for output
	 * */
	private function convertImage($img,$Extension){
		
		$outputFormat 		= 	strtoupper(substr($Extension, strpos($Extension, ".") + 1));
		$ident 				= 	$img->identifyImage();
		$inputFileName		=	$ident['imageName'];
		$inputFormat		=	$ident['format'];
		$outputfilename		=	$inputFileName;
		if($inputFormat != $outputFormat){
			$img->setImageFormat($outputFormat);
			$pathinfo	=	pathinfo($inputFileName);
			$outputfilename	=	$pathinfo['dirname'].'/'.$pathinfo['filename'].$Extension;
			$img->writeImage($outputfilename);
		}
		return $outputfilename;
	}
}

//$pr = new packageCreator('/var/www/html/packaging/eLife_HWX/elife05378.xml', '/var/www/html/packaging/eLife_HWX', '/var/www/html/packaging/packageConfig.xml', 'hwx');
//$pr->callPacker();
//echo $output;
?>