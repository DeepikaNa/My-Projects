express = require('express');
app = express();
fs = require('fs');
unirest = require('unirest');

app.use(express.static('public'));
app.use('/static', express.static('public'));

app.get('/', function(req, res){
    htmlContent = fs.readFileSync('./index.html');
    res.writeHead(200, {'Content-Type': 'text/html'});    
    res.write(htmlContent);
    res.end();
})
    unirest.post('https://kriya2.kriyadocs.com/api/getdata?apiKey=cde4c89b-e452-4ba5-b493-01c691033b72&doi=DTB-2018-000060&project=dtb&customer=bmj&xpath=//workflow/stage[last()]/name/text()')
    .end(function(data){
        res.status(200).json({'status':'200', data});
    })

app.listen(3003)
console.log('Port: '+3003);