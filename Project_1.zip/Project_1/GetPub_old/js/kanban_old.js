 $(document).ready(function(){
	//load jobs into kanban
	 $.ajax({
		url: 'includes/process_ajax_call.php',
		dataType: 'json',
		type: 'post',
		async: false,
		data: {kanbanJobs: 'all'},
		success:function(response){
			var processes = {ap:'Art processing',aq:'Artwork QC',te:'Technical Editing',ce:'Copy Editing',ceqc:'Copy Editing QC',fxml:'First XML',pgn:'Pagination',prqc:'Proof QC',desp:'FP Dispatch'};
			$.each(processes, function(index, process){
				if(response[process] === undefined){
					//$('.'+ index).append('<p></p>');
					$('.'+index+'-footer').append('<br>Tot: <span class="badge bg-primary" style="background-color:rgb(53, 103, 156) !important">0</span>');
					$('.'+index+'-header').append('<br><span style="color:#69BC6B" title="Scheduled">Sch: <span class="badge bg-success" style="background-color:#69BC6B !important">0</span></span>');
					$('.'+index+'-header').append('<span style="color:#FF9900" title="Pontential Delayed"> Pd: <span class="badge bg-warning" style="background-color:#FF9900 !important">0</span></span>');
					$('.'+index+'-header').append('<span style="color:#FF0000" title="Delayed"> Dy: <span class="badge bg-danger" style="background-color:#FF0000 !important">0</span></span>');
					return;
				}
				var noOfjobs = response[process].length;
				$('.'+index+'-footer').append('<br>Tot: <span class="badge bg-primary" style="background-color:rgb(53, 103, 156) !important">'+noOfjobs + '</span>');
				var RTag = '';
				var OTag = '';
				var GTag = '';
				var redCount = 0;
				var orangeCount = 0;
				var greenCount = 0;
				for(var i=0; i < noOfjobs; i++){
					$splitData = response[process][i].split('|');
					if($splitData[3] == ''){
						$splitData[3] = 'Unassigned';
					}
					if($splitData[4] == 'I09 - Informa UK Limited'){
						$splitData[4] = 'SCAND';
					}else if($splitData[4] == 'I07 - Informa UK Limited'){
						$splitData[4] = 'ER';
					}else {
						$splitData[4] = 'EO';
					}
					if($splitData[0] == 'red'){
						RTag = RTag + '<div class="panel panel-danger" client="'+$splitData[4]+'"><div class="panel-heading">'+$splitData[1]+'</div><div class="panel-body">'+$splitData[2]+'<br>'+$splitData[3]+'</div></div>';
						redCount++;
					}else if($splitData[0] == 'orange'){
						OTag = OTag + '<div class="panel panel-warning" client="'+$splitData[4]+'"><div class="panel-heading">'+$splitData[1]+'</div><div class="panel-body">'+$splitData[2]+'<br>'+$splitData[3]+'</div></div>';
						orangeCount++;
					}else {
						GTag = GTag + '<div class="panel panel-success" client="'+$splitData[4]+'"><div class="panel-heading">'+$splitData[1]+'</div><div class="panel-body">'+$splitData[2]+'<br>'+$splitData[3]+'</div></div>';
						greenCount++;
					}
				}
				$('.'+index+'-header').append('<br><span class="'+index+'-success" style="color:#69BC6B" title="Scheduled">Sch: <span class="badge bg-success" style="background-color:#69BC6B !important">'+greenCount+'</span></span>');
				$('.'+index+'-header').append('<span class="'+index+'-warning" style="color:#FF9900" title="Pontential Delayed"> Pd: <span class="badge bg-warning" style="background-color:#FF9900 !important">'+orangeCount+'</span></span>');
				$('.'+index+'-header').append('<span class="'+index+'-danger" style="color:#FF0000" title="Delayed"> Dy: <span class="badge bg-danger" style="background-color:#FF0000 !important">'+redCount+'</span></span>');
				$('.'+ index).append(RTag);
				$('.'+ index).append(OTag);
				$('.'+ index).append(GTag);
			});
			
			
			
		},
		error: function() {
			$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data from database..!').attr('class','alert alert-danger');
		}
	});//end of ajax call
	 
	$('#displayDetail').hide();
	$('#displayjobDetail').hide();
	
	$('#dispatchDetail').click(function(){
		$('#displayjobDetail').hide();
		$('#kanbanChart').css('opacity',0.5);
		$('#displayDetail').show();
	});
	
	$('#kanbanChart .panel-kanban .panel-body .panel').click(function(){
		//clear already detail
		$('#displayjobDetail .well .panel-body').html('');
		var jobId = $(this).children('.panel-heading').text();
		$.ajax({
			url: 'includes/process_ajax_call.php',
			type: 'post',
			async: false,
			data: {kanbanJobDetail: jobId},
			success:function(response){
				$('#displayjobDetail .well .panel-body').append(response);
			}
		});
		$('#displayDetail').hide();
		$('#kanbanChart').css('opacity',0.5);
		//$('.panel-kanban')[0].scrollIntoView();
		$('#displayjobDetail').show();
	});
	
	//add css to dynamically loaded span tags
	var processes = {ap:'Art processing',aq:'Artwork QC',te:'Technical Editing',ce:'Copy Editing',ceqc:'Copy Editing QC',fxml:'First XML',pgn:'Pagination',prqc:'Proof QC',desp:'FP Dispatch'};
	$.each(processes,function(e){
		$('.'+e+'-footer').css('cursor', 'pointer');
		//display all jobs in the queue
		$('.'+e+'-footer').click(function(){
			if($(this).html() == 0){
				return false;
			}
			$('.'+e+' .panel').show();
		});
		
		$('.'+e+'-danger').css('cursor', 'pointer');
		//display only delay jobs
		$('.'+e+'-danger').click(function(){
			if($(this).html() == 0){
				return false;
			}
			$('.'+e+' .panel').show();
			$('.'+e+' > div:not(.panel-danger)').hide();
		});
		
		$('.'+e+'-success').css('cursor', 'pointer');
		//display only scheduled jobs
		$('.'+e+'-success').click(function(){
			if($(this).html() == 0){
				return false;
			}
			$('.'+e+' .panel').show();
			$('.'+e+' > div:not(.panel-success)').hide();
		});
		
		$('.'+e+'-warning').css('cursor', 'pointer');
		//display only potential delayed jobs
		$('.'+e+'-warning').click(function(){
			if($(this).html() == 0){
				return false;
			}
			$('.'+e+' .panel').show();
			$('.'+e+' > div:not(.panel-warning)').hide();
		});
	});
	
	
 });
 
function filterClient(clientName){
	if(clientName == 'ALL'){
		$('.panel-kanban .panel-body .panel').show();
		$('.panel-kanban .panel-heading span[class]').show();
		$('.clientName').html('Client');
		$('.clientStatus').html('Status');
	}else {
		$('.panel-kanban .panel-body .panel').hide();
		$('.panel-kanban .panel-body .panel[client="'+clientName+'"]').show();
		$('.panel-kanban .panel-heading span[class]').hide();
		$('.clientName').html(clientName);
	}
	
}
 
 
function filterStatus(className, status){
	$('.panel-kanban .panel-body .panel').hide();
	if($('.clientName').html() == 'Client' && className == 'All'){
		$('.panel-kanban .panel-body .panel').show();
		$('.clientStatus').html('Status');
		$('.panel-kanban .panel-heading span[class]').show(); //hide numbers
	}else if($('.clientName').html() == 'Client' && className != 'All'){
		$('.panel-kanban .panel-body .'+className).show();
		$('.clientStatus').html(status);
		$('.panel-kanban .panel-heading span[class]').hide();  //hide numbers
	}else if($('.clientName').html() != 'Client' && className == 'All'){
		$('.panel-kanban .panel-body .panel[client="'+$('.clientName').html()+'"]').show();
		$('.clientStatus').html('Status');
		$('.panel-kanban .panel-heading span[class]').hide(); //hide numbers
	}else{
		$('.panel-kanban .panel-body .'+className+'[client="'+$('.clientName').html()+'"]').show();
		$('.clientStatus').html(status);
		$('.panel-kanban .panel-heading span[class]').hide(); //hide numbers
	}
}



