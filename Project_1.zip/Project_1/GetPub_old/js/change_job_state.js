 $(document).ready(function(){
	
	$(document).ajaxStart(function() {
		$("#loading").show();
		$('body').css('opacity','0.5');
	});
	$(document).ajaxStop(function() {
		$("#loading").hide();
		$('body').css('opacity','');
	});
	
	//load job id in drop down from database
	 $.ajax({
		url: 'includes/process_ajax_call.php',
		type: 'post',
		async: false,
		data: {getJobIds: 'all'},
		success:function(response){
			if(response.match(/DATABASE ERROR/g)){
				$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data from database..!').attr('class','alert alert-danger');
			}else if(response == ''){
				$('#message').html('<b>ERROR</b><br/>Sorry, No jobs available..!').attr('class','alert alert-danger');
			}else {
				$('#jobId').append(response);
			}
		},
		error: function() {
			$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data from database..!').attr('class','alert alert-danger');
		}
	});//end of ajax call
	
	
	 $.ajax({
			url: 'includes/process_ajax_call.php',
			type: 'post',
			async: false,
			data: {getResources: 'all'},
			success:function(response){
				if(response.match(/DATABASE ERROR/g)){
					$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data from database..!').attr('class','alert alert-danger');
				}else if(response == ''){
					$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data from database..!').attr('class','alert alert-danger');
				}else {
					$('#staffName').append(response);
				}
			},
			error: function() {
				$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data from database..!').attr('class','alert alert-danger');
			}
		});//end of ajax call
	 
	 $('#jobId').change(function(){
			if($(this).val() == ''){
				window.location="change_job_state.php";
			}else {
				
				initializeFields();
				
				//ajax call on change job set job detail to fields
				$.ajax({
					url: 'includes/process_ajax_call.php',
					type: 'post',
					async: false,
					//dataType:'json',
					data: {jobId: $(this).val()},
					success:function(response){
						if(response.match(/DATABASE ERROR/g)){
							$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data for the selected job from database..!').attr('class','alert alert-danger');
						}else {
							
							var jobDetail = response.split('|');
							$('#jobName').val(jobDetail[0]);
							$('#startDate').val(jobDetail[1]);
							$('#dueDate').val(jobDetail[2]);
							
							if(jobDetail[3].match(/^ER/gi)){
								$('#journalType').val('ER');
							}else {
								$('#journalType').val('EO');
							}
							
							$('#currentTask').val(jobDetail[4]);
							
							if(jobDetail[8] == 'completed'){
								if($('#currentTask').val().match(/dispatch/gi)){
									$('#completedTask').show();
									$('#completedTask').html('Next Stage');
								}else if($('#currentTask').val().match(/Revision \d Pagination|Technical Editing/gi)){
									// Added by Lingasamy. S
									// If it is completed and Technical Editing, show filde uploadDiv
									/*if($('#currentTask').val().match(/Technical Editing/gi)){
										$('.uploadDiv').removeClass('hidden');
									}
									*/
									$('#staff').show();
									$('#completedTask').show();
									$('#staffName option[value="'+jobDetail[5]+'"]').show().prop('selected',true);
									$('#vendorBlock').show();
									$('#pageNumber').show();
								}else{
									$('#staff').show();
									$('#completedTask').show();
									if(jobDetail[4] == 'Copy Editing'){
										$('#staffName option[value="'+jobDetail[5]+'"]').show().prop('selected',true);
									}else {
										$('#staffName option[value="'+jobDetail[5]+'"]').show().prop('selected',true);
									}
								}
								
								$('#rejectTask').show();
								$('#staffName').attr('disabled','disabled');
							}
							
							if(jobDetail[8] == 'start'){
								$('.uploadDiv').addClass('hidden');
								if($('#currentTask').val() == 'Technical Editing'){
									$('#staff').show();
									$('#startTask').show();
								}else if($('#currentTask').val() == 'Copy Editing'){
									$('#staff').show();
									$('#startTask').show();
								}else if($('#currentTask').val().match(/dispatch/gi)){
									$('#startTask').html('Done');
									$('#startTask').show();
								}else if($('#currentTask').val() == 'Job Completed'){
									//job completed
								}else {
									$('#staff').show();
									$('#startTask').show();
								}
							}
							
							
							$('#otherTask').val(jobDetail[6]);
							
							if(jobDetail[9] == 'completed'){
								$('#otherStaff option[value="'+jobDetail[7]+'"]').show().prop('selected',true);
								$('#rejectOtherTask').show();
								$('#completedOtherTask').show();
								$('#otherSelectStaff').show();
								$('#otherStaff').attr('disabled','disabled');
							}else if(jobDetail[6].match(/Artwork completed|No Art/gi) && jobDetail[9] == 'start'){
								//dont show any button
							}else if(jobDetail[6].match(/Art/gi) && jobDetail[9] == 'start'){
								$('#startOtherTask').show();
								$('#otherSelectStaff').show();
								$('#notApplied').show();
							}else if(jobDetail[9] == 'start'){
								$('#startOtherTask').show();
								$('#otherSelectStaff').show();
							}
							
							$('.wholePage').show();
						}
					},
					error: function() {
						$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data for the selected job from database..!').attr('class','alert alert-danger');
						$('.wholePage').hide();
					}
			    });//end of ajax call
			}
		});
	 
	 $('#startTask').click(function(){
		 
		 if($('#currentTask').val().match(/dispatch/gi) &&  !$('#otherTask').val().match(/Artwork completed|No Art/gi)){
				$('#message').html('<b>ALERT</b><br/>Artwork not completed..!').attr('class','alert alert-danger');
				return false;
		 }
		 if($('#currentTask').val().match(/dispatch/gi)){
			 $('#checkListDiv .panel-body div').hide();
			 $('#checkListDiv').show();
			 var className = $('#currentTask').val().replace(/\s/g,'_').replace(/\d/g, '1');
			 $('#displayCheckListName').html($('#currentTask').val());
			 $('#'+className).show();
			 $('#checkListDone').hide();
			 $('#checkListStateDone').show();
			 return false;
		 }
		 
		if(!$('#currentTask').val().match(/dispatch/gi) && $('#staffName').val() == '' ){
			$('#message').html('<b>ALERT</b><br/>Please, select RESOURCE for the task..!').attr('class','alert alert-danger');
			return false;
		}
		var staff = $('#staffName').val();
		$.ajax({
			url: 'includes/process_ajax_call.php',
			type: 'post',
			data: {updateJobId: $('#jobId').val(), startTask: $('#currentTask').val(), staff: staff},
			success:function(response){
				if(response.match(/DATABASE ERROR/g)){
					$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
				}else if(response == 'done'){
					$('#startTask').hide();
					$('#message').html('<b>NOTE</b><br/>Task started successfully..!').attr('class','alert alert-success');
				}else {
					$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
				}
			},
			error: function() {
				$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
			}
		});//end of ajax call
		return false;
		
	});
	
	//click start will record the start time of job
	 $('#completedTask').click(function(event){
		 if($('#currentTask').val().match(/dispatch/gi)){
			 $('#checkListDone').click();
		 }else if($('#currentTask').val().match(/Technical Editing$/gi)){
			 if($('#noOfPage').val().match(/^$|^0$/gi)){
				 $('#message').html('<b>ALERT</b><br/>Please, Enter page count for the task..!').attr('class','alert alert-danger');
				 return false;
			 }
			 /*else if($('#file').val() == ''){
				 $('#message').html('<b>ALERT</b><br/>Please, Upload the file!').attr('class','alert alert-danger');
				 return false;
			 }*/
			 /*else if($('#staffName').val() == ''){
				 $('#message').html('<b>ALERT</b><br/>Please, select RESOURCE for the task..!').attr('class','alert alert-danger');
				 return false;
			 }*/
			 else {
			 	$('#checkListDiv .panel-body div').hide();
				$('#checkListDiv').show(); 
				var className = $('#currentTask').val().replace(/\s/g,'_').replace(/\d/g, '1');
				$('#displayCheckListName').html($('#currentTask').val());
				$('#'+className).show();
			 }
		} else {
			$('#checkListDiv .panel-body div').hide();
			$('#checkListDiv').show(); 
			var className = $('#currentTask').val().replace(/\s/g,'_').replace(/\d/g, '1');
			$('#displayCheckListName').html($('#currentTask').val());
			$('#'+className).show();
		 }
		 $('#mainPage').attr('style','opacity:0.4');
	 });
	
	
	$('#checkListDone').click(function(event){
		var className = $('#currentTask').val().replace(/\s/g,'_');
		var boolBreak = false;
		if($('#completedTask').html() != 'Next Stage'){
			$.each($('#'+className+' input'),function(checkbox){
				if(!$(this).is(':checked')){
					 alert('Please, Check all check list.');
					 boolBreak = true;
					 return false;
				}
			});
		}
		if(boolBreak){
			return false;
		}
		
		insertChecklist($('#currentTask').val(), $('#jobId').val());
		
		$('#updateJobIdHidden').val($('#jobId').val());
		$('#completeTaskHidden').val($('#currentTask').val());
		//$('#noOfPageHidden').val($('#noOfPage').val());
		//$('#staffHidden').val($('#staffName').val());
		
		$('#taskCompletionSubmit').submit();
		return false;
		/*
		var pageCount = $('#noOfPage').val();
		var staff = $('#staffName').val();
		
		$.ajax({
			url: 'includes/process_ajax_call.php',
			type: 'post',
			data: {updateJobId: $('#jobId').val(), completeTask: $('#currentTask').val(), noOfPage: pageCount, staff: staff},
			success:function(response){
				if(response.match(/DATABASE ERROR/g)){
					console.log(response);
					alert('Try after sometime');	
				}else if(response == 'done'){
					$('#checkListDiv').hide(); 
					$('#completedTask').hide();
					$('#rejectTask').hide();
					$('#message').html('<b>NOTE</b><br/>Task completed successfully..!').attr('class','alert alert-success');
					$('#mainPage').removeAttr('style');
				}else {
					console.log(response);
				}
			}
		});//end of ajax call
		*/
	});
	
	$('#startOtherTask').click(function(){
		var staff = '';
		if(!$('#otherTask').val().match(/Artwork Completed/gi) && $('#otherStaff').val() == '' ){
			$('#message').html('<b>ALERT</b><br/>Please, select RESOURCE for the task..!').attr('class','alert alert-danger');
			return false;
		}else {
			staff = $('#otherStaff').val();
		}
		$.ajax({
			url: 'includes/process_ajax_call.php',
			type: 'post',
			data: {updateJobId: $('#jobId').val(), startOtherTask: $('#otherTask').val(), staff: staff},
			success:function(response){
				if(response.match(/DATABASE ERROR/g)){
					$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
				}else if(response == 'done'){
					$('#startOtherTask').hide();
					$('#notApplied').hide();
					$('#message').html('<b>NOTE</b><br/>Task started successfully..!').attr('class','alert alert-success');
				}else {
					$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
				}
			},
			error: function() {
				$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
			}
		});//end of ajax call
		return false;
	});
	
	 $('#completedOtherTask').click(function(event){
		$('#checkListDiv #checkListDone').hide();
		$('#checkListDiv #checkListOtherDone').show();
		$('#checkListDiv .panel-body div').hide();
		$('#checkListDiv').show(); 
		var className = $('#otherTask').val().replace(/\s/g,'_').replace(/\d/g, '1');
		$('#displayCheckListName').html($('#otherTask').val());
		$('#'+className).show();
		$('#mainPage').attr('style','opacity:0.4');
	 });
	 
	 $('#checkListOtherDone').click(function(event){
		
			var className = $('#otherTask').val().replace(/\s/g,'_');
			var boolBreak = false;
			$.each($('#'+className+' input'),function(checkbox){
				if(!$(this).is(':checked')){
					alert('Please, Check all check list.');
					 boolBreak = true;
					 return false;
				}
			});
			
			if(boolBreak){
				return false;
			}
			
			insertChecklist($('#otherTask').val(), $('#jobId').val());
			
			$.ajax({
				url: 'includes/process_ajax_call.php',
				type: 'post',
				data: {updateJobId: $('#jobId').val(), completeOtherTask: $('#otherTask').val()},
				success:function(response){
					if(response.match(/DATABASE ERROR/g)){
						console.log(response);
						alert('Error');	
					}else if(response == 'done'){
						$('#checkListDiv').hide(); 
						$('#completedOtherTask').hide();
						$('#rejectOtherTask').hide();
						$('#message').html('<b>NOTE</b><br/>Task completed successfully..!').attr('class','alert alert-success');
						$('#mainPage').removeAttr('style');
						
					}else {
						console.log(response);
						alert('Error');
					}
					console.log(response);
				},
				error: function() {
					alert('JS Error');
				}
			});//end of ajax call
		});
	 
	 
	 $('#checkListStateDone').click(function(event){
		 var className = $('#currentTask').val().replace(/\s/g,'_');
			var boolBreak = false;
			$.each($('#'+className+' input'),function(checkbox){
				if(!$(this).is(':checked')){
					alert('Please, Check all check list.');
					 boolBreak = true;
					 return false;
				}
			});
			
			if(boolBreak){
				return false;
			}
		$('#checkListDiv').hide();
		insertChecklist($('#currentTask').val(), $('#jobId').val());
		
		$.ajax({
			url: 'includes/process_ajax_call.php',
			type: 'post',
			data: {updateJobId: $('#jobId').val(), startTask: $('#currentTask').val()},
			success:function(response){
				if(response.match(/DATABASE ERROR/g)){
					$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
				}else if(response == 'done'){
					$('#startTask').hide();
					$('#message').html('<b>NOTE</b><br/>Task started successfully..!').attr('class','alert alert-success');
				}else {
					$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
				}
			},
			error: function() {
				$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
			}
		});//end of ajax call
		return false;
	 });
		
	 $('#notApplied').click(function(){
		 $.ajax({
				url: 'includes/process_ajax_call.php',
				type: 'post',
				data: {updateJobId: $('#jobId').val(),ArtCorrection: $('#otherTask').val()},
				success:function(response){
					if(response.match(/DATABASE ERROR/g)){
						$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
					}else if(response == 'No Art Correction'){
						console.log(response);
						$('#otherTask').val(response);
						$('#notApplied').hide();
					}else {
						$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
					}
				},
				error: function() {
					$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
				}
			});//end of ajax call
	 });
	 
	 
	//click start will record the start time of job
	 $('#rejectTask').click(function(event){
	 	$.ajax({
	 		url: 'includes/process_ajax_call.php',
	 		type: 'post',
	 		data: {updateJobId: $('#jobId').val(), rejectTask: $('#currentTask').val()},
	 		success:function(response){
	 			if(response.match(/DATABASE ERROR/g)){
	 				$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
	 			}else if(response == 'done'){
	 				$('#rejectTask').hide();
	 				$('#completedTask').hide();
	 				$('#message').html('<b>ALERT</b><br/>Successfully, Rejected the task..!').attr('class','alert alert-success');
	 			}else if(response == 'cant reject'){
	 				alert('Sorry, You cant reject the task..!');
	 			}else {
	 				$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
	 			}
	 		},
	 		error: function() {
	 			$('#message').html('<b>ERROR</b><br/>Sorry, cannot update database..!').attr('class','alert alert-danger');
	 		}
	 	});//end of ajax call
	 	
	 });
	//validate page number count
	$("#noOfPage").keypress(function (e) {
		 //if the letter is not digit then display error and don't type anything
		 if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
		     return false;
		 }
	});
	 
	
	  (function ($) {

	      $.fn.searchit = function (options) {

	          return this.each(function () {

	              $.fn.searchit.globals = $.fn.searchit.globals || {
	                  counter: 0
	              }
	              $.fn.searchit.globals.counter++;
	              var $counter = $.fn.searchit.globals.counter;
	              var $t = $(this);
	              var opts = $.extend({}, $.fn.searchit.defaults, options);

	              // Setup default text field and class
	              if (opts.textField == null) {
	                  $t.before("<input type='textbox' id='__searchit" + $counter + "'><br>");
	                  opts.textField = $('#__searchit' + $counter);
	              }
	              if (opts.textField.length > 1) opts.textField = $(opts.textField[0]);

	              if (opts.textFieldClass) opts.textField.addClass(opts.textFieldClass);
	              //MY CODE-------------------------------------------------------------------
	              if (opts.selected) opts.textField.val($(this).find(":selected").val());
	              //MY CODE ENDS HERE -------------------------------------------------------
	              if (opts.dropDown) {
	                  $t.css("padding", "5px")
	                      .css("margin", "-5px -20px -5px -5px");

	                  $t.wrap("<div id='__searchitWrapper" + $counter + "' />");
	                  opts.wrp = $('#__searchitWrapper' + $counter);
	                  opts.wrp.css("display", "inline-block")
	                      .css("vertical-align", "top")
	                      .css("overflow", "hidden")
	                      .css("border", "solid grey 1px")
	                      .css("position", "absolute")
	                      .css("z-index", "3")
	                      .hide();
	                  if (opts.dropDownClass) opts.wrp.addClass(opts.dropDownClass);
	              }

	              opts.optionsFiltered = [];
	              opts.optionsCache = [];

	              // Save listbox current content
	              $t.find("option").each(function (index) {
	                  opts.optionsCache.push(this);
	              });

	              // Save options 
	              $t.data('opts', opts);

	              // Hook listbox click
	              $t.click(function (event) {
	                  _opts($t).textField.val($(this).find(":selected").text());
	                  _opts($t).wrp.hide();
	                  event.stopPropagation();
	              });

	              // Hook html page click to close dropdown
	              $("html").click(function () {
	                  _opts($t).wrp.hide();
	              });

	              // Hook the keyboard and we're done
	              _opts($t).textField.keyup(function (event) {
	                  if (event.keyCode == 13) {
	                      $(this).val($t.find(":selected").text());
	                      _opts($t).wrp.hide();
	                      return;
	                  }
	                  setTimeout(_findElementsInListBox($t, $(this)), 50);
	              })

	          })


	          function _findElementsInListBox(lb, txt) {

	              if (!lb.is(":visible")) {
	                  _showlb(lb);
	              }

	              _opts(lb).optionsFiltered = [];
	              var count = _opts(lb).optionsCache.length;
	              var dropDown = _opts(lb).dropDown;
	              var searchText = txt.val().toLowerCase();

	              // find match (just the old classic loop, will make the regexp later)
	              $.each(_opts(lb).optionsCache, function (index, value) {
	                  if ($(value).text().toLowerCase().indexOf(searchText) > -1) {
	                      // save matching items 
	                      _opts(lb).optionsFiltered.push(value);
	                  }

	                  // Trigger a listbox reload at the end of cycle    
	                  if (!--count) {
	                      _filterListBox(lb);
	                  }
	              });
	          }

	          function _opts(lb) {
	              return lb.data('opts');
	          }

	          function _showlb(lb) {
	              if (_opts(lb).dropDown) {
	                  var tf = _opts(lb).textField;
	                  lb.attr("size", _opts(lb).size);
	                  _opts(lb).wrp.show().offset({
	                      top: tf.offset().top + tf.outerHeight(),
	                      left: tf.offset().left
	                  });
	                  _opts(lb).wrp.css("width", tf.outerWidth() + "px");
	                  lb.css("width", (tf.outerWidth() + 25) + "px").css("min-height", "200px");
	              }
	          }

	          function _filterListBox(lb) {
	              lb.empty();
	              if (_opts(lb).optionsFiltered.length == 0) {
	                  lb.append("<option>" + _opts(lb).noElementText + "</option>");
	              } else {
	                  $.each(_opts(lb).optionsFiltered, function (index, value) {
	                      lb.append(value);
	                  });
	                  //no need to select default index
	                  //lb[0].selectedIndex = 0;
	              }
	          }
	      }

	      $.fn.searchit.defaults = {
	          textField: null,
	          textFieldClass: null,
	          dropDown: true,
	          dropDownClass: null,
	          size: 5,
	          filtered: true,
	          noElementText: "No elements found",
	          //MY CODE------------------------------------------
	          selected: false
	          //MY CODE ENDS ------------------------------------
	      }

	  }(jQuery))

	   $("#jobId").searchit({
	      textFieldClass: 'searchbox form-control',
	      selected: true
	  });
 });
	 

 
 
function initializeFields(){
	 $('#checkListDiv .panel-body div input').removeProp('checked');
	 $('#checkListDiv .panel-body div').hide();
	 $('#checkListDiv').hide();
	 $('#rejectOtherTask').hide();
	 $('#completedOtherTask').hide();
	 $('#startOtherTask').hide();
	 $('#otherStaff option:first-child').prop('selected',true);
	 $('#otherSelectStaff').hide();
	 $('#otherTask').val('');
	 $('#staffName option:first-child').prop('selected',true);
	 $('#vendorName').val('');
	 $('#noOfPage').val(0);
	 $('#rejectTask').hide();
	 $('#completedTask').hide();
	 $('#startTask').hide();
	 $('#currentTask').val('');
	 $('#dueDate').val('');
	 $('#startDate').val('');
	 $('#journalType').val('');
	 $('#jobName').val('');
	 $('#vendorNameDisplay').hide();
	 $('#staff').hide();
	 $('#pageNumber').hide();
	 $('#jobidcomment').hide();
	 $('#completedTask').html('Completed');
	 $('#startTask').html('Start');
	 $('#notApplied').hide();
	 $('#checkListOtherDone').hide();
	 $('#checkListDone').show();
	 $('#checkListStateDone').hide();
	 $('#staffName').removeAttr('disabled');
	 $('#otherStaff').removeAttr('disabled');
 }

function insertChecklist(taskName, jobId){ 
	var checked = ''; 
	className = taskName.replace(/\s/g,'_');
	className = className.replace(/\d/g,'1');
    $.each($('#'+className+' input'),function(){ 
        if($(this).is(':checked')){ 
                checked += "|check"; 
        } 
        else{ 
                checked += "|unchecked"; 
        } 
        checked = checked.replace(/^\|/g,''); 
    }); 
    taskName = taskName.replace(/\s/g,'_');
    $.ajax({ 
        url: 'includes/process_ajax_call.php', 
        type: 'post', 
        async: false, 
        data: {jobId: jobId,taskName: taskName,checked: checked}, 
        success:function(response){ 
            if(response.match(/DATABASE ERROR/g)){ 
                alert('Error');     
            }else if(response == 'done'){ 
                //do nothing just update DB 
            }else { 
                alert('Error'); 
            } 
        }, 
        error: function() { 
            alert('JS Error'); 
        } 
    }); 
    $('#checkListDiv input').removeProp('checked');
}
