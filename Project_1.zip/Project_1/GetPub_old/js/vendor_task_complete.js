 $(document).ready(function(){
	//hide checklist
	$('#checkList').hide();
	$('#POId').attr('disabled','disabled');	
	$('#uploader').hide();
	$('#poidcomment').hide();
	$('#loading').hide();
	
	$('#jobId').change(function(){
		if($(this).val() == ''){
			$('#jobidcomment').show();
			$('#POId').attr('disabled','disabled');
			//$('#poidcomment').hide();
			$('#checkList').hide();
			$('#POId option:first-child').attr("selected", "selected");
			$('#noOfPage').val('');
		}
		else {
			$('#jobidcomment').hide();
			$('#POId').removeAttr('disabled');
			//$('#poidcomment').show();
			$('#POId option').hide();
			$('#'+$(this).val()).attr("selected","selected");
			$('#checkList').show();
			
			//ajax call on change job set job detail to fields
			$.ajax({
				url: 'includes/process_ajax_call.php',
				type: 'post',
				async: false,
				//dataType:'json',
				data: {jobId: $(this).val()},
				success:function(response){
					if(response.match(/DATABASE ERROR/g)){
						$('#message').html('Sorry, cannot fetch data for the selected job from database..!').attr('class','alert alert-danger');
					}else {
						var jobDetail = response.split('|');
						$('#noOfPage').val(jobDetail[4]);
						$('#jobName').val(jobDetail[0]);
					}
				},
				error: function() {
					$('#message').html('Sorry, cannot fetch data for the selected job from database..!').attr('class','alert alert-danger');
		 			$('#noOfPage').val('Error');
				}
		    });//end of ajax call
		}
		$('#checkList .check').removeAttr('checked');
		$('#checkList textarea').val('');
		//$('#POId option:first-child').attr("selected", "selected");
	});
	
	/*$('#POId').change(function(){
		if($(this).val() == ''){
			$('#poidcomment').show();
			$('#checkList').hide();
		}else {
			$('#poidcomment').hide();
			$('#checkList').show();
		}
	});*/
	
	//validate page number count
	$("#noOfPage").keypress(function (e) {
	     //if the letter is not digit then display error and don't type anything
	     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
	        //display error message
	        $("#noOfPageComment").html('<p id="jobidcomment" class="help-block" style="color:red">Digits Only<p>').show().fadeOut("slow");
	               return false;
	    }
	});
	
	$('#fileupload').change(function(){ //validate uploaded file
		if(!$(this).val().match(/\.(zip|doc|docx|pdf|tar|tgz|7z)$/gi)){
			alert('wrong file selected..!');
			$(this).val('');
		}
	});
	
	//function to validate submit
	$('#formSubmit').click(function(event){ //if submit button is clicked then check all mandatory fields
		if($('#fileupload').val() == ''){
			alert('Please upload a file.');
			event.preventDefault();
		}else if($('#noOfPage').val() == '' || $('#noOfPage').val() == 0){
			alert('Please enter number of pages.');
			event.preventDefault();
		}else {
			$('#POId').removeAttr('disabled');
			$('#jobId').removeAttr('disabled');
			//$('#POId').attr('disabled','disabled');	
			//$('#backPage').attr('disabled','disabled');	
			//$('#formSubmit').attr('disabled','disabled');	
			//$('#cancel').attr('disabled','disabled');
			//$('#tempLoading').hide();
			$('#loading').show();
			$('.container-fluid').attr('style', 'opacity: 0.5');
		}
		
	});
});


//validate on clicking next button whether all mandatory fields are filled
function nextPage(){
	var checkBox = $('.check'); //get all checkbox
	var length = checkBox.length; // count of all checkbox 
	var minimumCheck =parseInt(length*(80/100)); // 80% of checkbox count 
	var checked = 0;
	for(var i=0;i < length;i++){
		if(checkBox[i].checked){
			checked++;	//if ticked then increment count of check
		}
	}
	if(checked < minimumCheck){ //if ticked checkbox is less than 80% then display error
		alert('Mandatory to fill check list..!');
		return;
	}
	$('#checkList').hide();	//hide first form 
	$('#uploader').show();	//display second form
	$('#POId').attr('disabled','disabled');	
	$('#jobId').attr('disabled','disabled');	
}


//function for previous button 
function prevPage(){
	$('#checkList').show();	//hide first form 
	$('#uploader').hide();	//display second form
	$('#POId').removeAttr('disabled');	
	$('#jobId').removeAttr('disabled');	
}

//$.each($('.check'),function(){$(this).attr('checked','checked')});