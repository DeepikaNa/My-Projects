<?php

/**
 * The db2XML class provide an easy way to create XML file.
 * 
 * Hey, don't worry, it's beta.
 * 
 * You can add more funcionality and redistribute
 * Feel free to do that.
 *
 * @author Marcelo Pereira <marcelopfs@yahoo.com.br>
 * @version 0.1 - Beta
 * 
 * TODO: add setSQL / Connection methods.
 */
class db2XML
{
    var $table_name;
    var $file_name;
    var $fields;
    var $xml_header;
    var $xml_body;
    var $buffer;
    var $main_tag;
   
    /**
     * Define database table name 
     *
     * @param string $name Must be the table name that will be receive data
     */
    function setTable($name)
    {
        $this->table_name = $name;
    }
    
    // define o nome do arquivo XML
    /**
     * The name of file that will be created
     *
     * @param string $file File name
     */
    function setFile($file)
    {
        $this->file_name = $file;
    }

    /**
     * db2XML class uses it to define XML Headers
     * 
     * @return $xml_header XML Header necessary to create a XML file
     */
    function setXML_Header()
    {
        $this->xml_header = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

        return $this->xml_header;
    }
    
    // array com os campos
    /**
     * It must receive an array with column names 
     *
     * @param array $fields The name of table fields
     */
    function setFields_DB($fields)
    {
        foreach($fields as $key => $value)
        {
            $this->fields .= $value . ",";
        }

        $this->fields = substr($this->fields, 0, -1);
        
        return true;
    }
    
    /**
     * Main XML tag
     * 
     * @param string $name 
     */
    function setXML_MainTag($name)
    {
        $this->main_tag = $name;
    }    

    /**
     * It's the main method of db2XML class
     *
     * It must be integrated with Database Class like PEAR::DB
     * But you can try it setting a database connection information to view how it works.
     *
     * Example:
     * 
     * $array = "" => "FOOD", 
     *              "tx_name" => "FOOD_NAME",
     *              "tx_type" => "TYPE",
     *              "tx_locale" => "LOCALE",
     *              "vl_ranking" => "RANKING"
     * 
     * This array will be create an XML file like this:
     *
     * <main_tag>
     *   <FOOD>
     *     <FOOD_NAME>Feijoada</FOOD_NAME>
     *     <TYPE>type here</TYPE>
     *     <LOCALE>Brasil</LOCALE>
     *     <RANKING>10</RANKING>
     *   </FOOD>
     * </main_tag>
     *
     *
     * @param array $xml_fields It is the array with 
     *
     */
    function setXML_Structure($xml_fields)
    {
        //$con = mysql_connect("localhost", "username", "password");
        //$db  = mysql_select_db("database_name", $con);
  
        $stmt = "SELECT " . $this->fields . " FROM " . $this->table_name;
        $stmh = mysql_query($stmt);

        $fields_db = explode(",", $this->fields);

        $y = 0;
        while (false !== ($listar = mysql_fetch_array($stmh)))
        {
            if ($xml_fields[$x] == "" || $y == 0)
                $this->xml_body .= "<" . $xml_fields[$fields_db[$x]] . ">";

            for($x=0;$x<count($fields_db);$x++)
            {
                    $this->xml_body .= "<" . $xml_fields[$fields_db[$x]] . ">";
                    $this->xml_body .= $listar[$fields_db[$x]];
                    $this->xml_body .= "</" . $xml_fields[$fields_db[$x]] . ">";
            }

            if ($xml_fields[$x] == "")
                $this->xml_body .= "</" . $xml_fields[$fields_db[$x]] . ">";

            $y++;
        }

       return true;
    }
 
    /**
     * Create XML file.
     *
     */
    function write2file()
    {
        $this->buffer .= $this->setXML_Header();
        $this->buffer .= "<" . $this->main_tag  . ">";
        $this->buffer .= $this->xml_body;
        $this->buffer .= "</" . $this->main_tag  . ">";

        $arq = fopen ($this->file_name, 'w');
        $add = fwrite($arq, $this->buffer);
       
        if (!$add)
        {
            echo "Cannot create a XML file: <b>" . $this->file_name . "</b><br />";
            echo "Verify permissions to directory: <b>" . $this->file_name . "</b><br />";
        }
        
        fclose($arq);
    }
    /**
     * return XML as string.
     *
     */
    function toString()
    {
        $this->buffer .= $this->setXML_Header();
        $this->buffer .= "<" . $this->main_tag  . ">";
        $this->buffer .= $this->xml_body;
        $this->buffer .= "</" . $this->main_tag  . ">";
        
        return $this->buffer;
    }
}
?>
