var express = require('express');
var bodyParser = require('body-parser');
var unirest = require('unirest');
var fs = require('fs');
const { resolveSrv } = require('dns');

var app = express();


// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
// parse application/json
app.use(bodyParser.json())
app.use(express.static("sb-admin"));

app.get("/", function(req, res){
    htmlContent = fs.readFileSync('./sb-admin/epubPage.html');
    res.writeHead(200, {'Content-Type': 'text/html'});    
    res.write(htmlContent);
    res.end();
});

app.post("/getPubDate", function(req, res){
    console.log(req.body.customer+" "+req.body.doi); 
    getKriya2Stage(req.body.doi)
    .then(function(stageName){
        console.log(stageName);
        isPublised();

    })
    .catch(function(err){
        console.log(err);
    })
});
function isPublised(doi){
    return new Promise(function(resolve, reject){
    var project = doi.replace(/^([a-z]+)(.+)/i, "$1", doi).toLowerCase();
    var api_url = "https://kriya2.kriyadocs.com/api/getdata?apiKey=cde4c89b-e452-4ba5-b493-01c691033b72&doi="+doi+"&project="+project+"&customer=bmj&xpath=//article";
    unirest.get(api_url)
        .end(function(response){
            if(response.error){
                resolve(""); 
            }else{
                resolve(response.body);
                var libxmljs = require('libxmljs');
                var xmlDoc = libxmljs.parseXml(result);
               var doiTag = xmlDoc.find('//nlm:article-id[@pub-id-type="doi"]');
               var epubDate = xmlDoc.find('//nlm:pub-date[@pub-type="epub"]');
               if (epubDate.length==0){
                epubDate =  xmlDoc.find('//nlm:pub-date[@pub-type="epub-original"]');
               }
               if(epubDate.length > 0 ){
                var epubMonths = xmlDoc.find('.//nlm:month', epubDate[0]);
                if(epubMonths.length>0){
                    var epubMonth = epubMonths[0].nodeValue;
                    output["month"] = epubMonth;
                }
                var epubDays = xmlDoc.find('.//nlm:day', epubDate[0]);
                if(epubDays.length>0){
                    var epubDay = epubDays[0].nodeValue;
                    output["days"] = epubDay;
                }
                var epubYears = xmlDoc.find('.//nlm:year', epubDate[0]);
                if(epubYears.length>0){
                    var epubYear = epubYears[0].nodeValue;
                    output["year"] = epubMonth;
                }
                switch (epubMonth) {
                    case "1":
                        epubMonth = 'Jan';
                        break;
                    case "2":
                        epubMonth = 'Feb';
                        break;
                    case "3":
                        epubMonth = 'Mar';
                        break;
                    case "4":
                        epubMonth = 'Apr';
                        break;
                    case "5":
                        epubMonth = 'May';
                        break;
                    case "6":
                        epubMonth = 'June';
                        break;
                    case "7":
                        epubMonth = 'July';
                        break;
                    case "8":
                        epubMonth = 'Aug';
                        break;
                    case "9":
                        epubMonth = 'Sept';
                        break;
                    case "10":
                        epubMonth = 'Oct';
                        break;
                    case "11":
                        epubMonth = 'Nov';
                        break;
                    case "12":
                        epubMonth = 'Dec';
                        break;
                }
                $result = epubDay+'-'+epubMonth+'-'+epubYear;
            
            }else{
            $result = 'False';		
            }


            }

        })
    })
}


function getKriya2Stage(doi){
    return new Promise(function(resolve, reject){
        var project = doi.replace(/^([a-z]+)(.+)/i, "$1", doi).toLowerCase();
        //var url = "https://kriya2.kriyadocs.com/api/getdata?apiKey=cde4c89b-e452-4ba5-b493-01c691033b72&doi="+doi+"&project="+project+"&customer=bmj&xpath=//workflow/stage[last()]/name/text()";
        var url = "https://kriya2.kriyadocs.com/api/getdata?apiKey=cde4c89b-e452-4ba5-b493-01c691033b72&doi="+doi+"&project="+project+"&customer=bmj&xpath=//article";
        unirest.get(url)
            .end(function(response){
                if(response.error){
                    resolve("");
                }else{
                    resolve(response.body);
                }            
            })
    })
}

app.listen(3000, function(){
    console.log("server is running on port: 3000");
})