$(document).ready(function(){
    $('.getpub').on('click', function(target){
        if(!$('input#articleID').val() || $('input#articleID').val().trim() == ""){
            alert("MS number cannot be empty!!");
            return;
        }
        var params = {
            "doi": $('input#articleID').val(),
            "customer": $('select#client option:selected').val()
        }
        $.ajax({
            type: "POST",
            url: "/getPubDate",
            data: params,
            success: function(res){
                console.log(res);
            },
            error: function(err){
                console.log(err);
            }
        });
    })
})