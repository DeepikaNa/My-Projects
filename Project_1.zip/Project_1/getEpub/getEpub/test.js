'use strict';

var fs = require("fs"),
 path = require('path'),
 libxmljs = require("read-xml");
var FILE = path.join(__dirname, 'test.xml');
 
 
// xpath queries
libxmljs.readXML(fs.readFileSync(FILE), function(err, data) {
    if (err) {
      console.error(err);
    }
    console.log('xml encoding:', data.encoding);
    console.log('Decoded xml:', data.content);
  
})