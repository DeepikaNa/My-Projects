<?php
require_once("includes/JSLikeHTMLElement.php");
ini_set('display_errors', 'off');
ini_set('max_execution_time', '-1');
require_once("includes/config.php");

// Timezone setting
date_default_timezone_set('Asia/Kolkata');

$elifeCmsID = trim($_REQUEST["elifeCmsID"]);
$pressCmsID = trim($_REQUEST["pressCmsID"]);
$pressDate = trim($_REQUEST["pressDate"]);
$confirmedStatus = trim($_REQUEST["confirmedStatus"]);
$userNamePress = trim($_REQUEST["pressUserName"]);
$pressProcessType = trim($_REQUEST["pressProcessType"]);
$noDigestCmsID = trim($_REQUEST["noDigestCmsID"]);

// Updated by Saravanan K. Date: 01-Nov-2019; Gitlab: #66-Introduce customer feedback question on sign off page
$authorRating = trim($_REQUEST["authorRating"]);
$additionalComments = trim($_REQUEST["additionalComments"]);
$articleCmsID = trim($_REQUEST["articleCmsID"]);
$authorName = trim($_REQUEST["authorName"]);


if (!empty($elifeCmsID)) {
	updateReportData($elifeCmsID);
}
elseif(!empty($pressCmsID)) {
	updatePressStatus($pressCmsID, $pressDate, $confirmedStatus, $userNamePress,$pressProcessType);
}
elseif (!empty($noDigestCmsID)) {
	updateNoDigestSetDate($noDigestCmsID);
}
elseif (!empty($articleCmsID)) {
	updateAuthorRating($articleCmsID,$authorName, $authorRating, $additionalComments);
}

// Update elife_report_data table
function updateReportData($elifeCmsID) {
	$siteAddress = "http://api.elife2.kriyadocs.com/";
	$xml = getArticleXml($elifeCmsID,'elife',$siteAddress);
	$result = insert_data($xml, $elifeCmsID);
}

function getArticleXml($cmsid,$customerName,$siteAddress) {
	$xpathXML = "<articleList><article><id>".$cmsid."</id><customer-name>". $customerName . "</customer-name><data><xpath class='articleType'><query>//article</query><returnType>html</returnType></xpath><xpath class='articleType'><query outerHTML='true'>//workflow</query><returnType>html</returnType></xpath></data></article></articleList>";
	$url = $siteAddress.'job.api/getMetaInfo?apiKey=6c8e740baa82f222c5e63b39ffac2613&accountKey=1';
	$post = stream_context_create(array(
			'http' => array(
					'method' => 'POST',
					'header' => "content: {$xpathXML}",
					"Content-Type: text/plain",
			)
	));

	$response = file_get_contents($url, false, $post);
	$response =  mb_convert_encoding($response, 'HTML-ENTITIES', "UTF-8");
	$response = str_replace('&#65279;',"",$response);
	$response = str_replace('&',"&#38;",$response);
	//file_put_contents($siteurl."bucket/eLife2_{$bucketID}/{$msid}.xml",$response);
	return $response;

}


function insert_data($xmlFile, $elifeCmsID) {
	include('includes/config.php');
	//libxml_use_internal_errors(true);
	$articleDom = new DOMDocument;
	$noDigestCount = 0;
	$uploadCount = 0;
	$reUploadCount = 0;

	$articleDetails = array();
	$articleDom->loadXML($xmlFile);
	$articleXpath = new DOMXPath($articleDom);
	$digestStatus = checkDigest($articleDom, $articleXpath);
	$currentStage = getCurrentStage($articleDom, $articleXpath);
	$articleDetails['currentStage'] =  $currentStage;
	$title = $articleXpath->query("//article-meta/title-group/article-title");
	$articleDetails['articleTitle'] =  $title->item(0)->nodeValue;
	$articleType = $articleXpath->query("//subj-group[@subj-group-type='display-channel']");
	$articleDetails['articleType'] =  $articleType->item(0)->nodeValue;
	$articleDoi = $articleXpath->query("//article-meta/article-id[@pub-id-type='publisher-id']");
	$relatedArticle = $articleXpath->query("//related-article[not(contains(@deleted, 'true'))]");

	$relatedArticleLength = $relatedArticle->length;
	if($relatedArticleLength > 0) {
		$articleDetails['relatedArticles'] = '';
		for($r=0; $r<$relatedArticleLength; $r++) {
			if(strlen(trim($relatedArticle->item($r)->nodeValue))>0) {
				$related = explode("-",$relatedArticle->item($r)->nodeValue);
				$articleDetails['relatedArticles'] .=  trim($related[count($related)-1]) . "|";
			}
			else {
				$checking = $relatedArticle->item($r)->hasAttribute('xlink:href');
				if($checking==1){
					$relatedInput = $relatedArticle->item($r)->getAttribute('xlink:href');
					preg_match("/(\d)*+$/", $relatedInput, $relatedOutput);
					if(count($relatedOutput) > 0){
						$articleDetails['relatedArticles'] .= $relatedOutput[0] . "|";
					}
				}
			}
		}
		$articleDetails['relatedArticles'] = rtrim($articleDetails['relatedArticles'], "|");
		$articleDetails['relatedArticles'] = preg_replace("/10\.7554\/eLife\./", '', $articleDetails['relatedArticles']);
	}
	// Press Date
	$pressDate = $articleXpath->query("//workflow[@pressdate]/@pressdate");
	$articleDetails['pressDate'] = $pressDate->item(0)->nodeValue;
	$homePage = $articleXpath->query("//workflow[@homepage]/@homepage");
	$articleDetails['homePage'] = $homePage->item(0)->nodeValue;
	$articleDetails['doi'] =  $articleDoi->item(0)->nodeValue;
	$bucket = getBucketName($elifeCmsID);
	$articleDetails['bucket'] = $bucket;
	$articleID = $articleXpath->query("//article/id");
	$articleDetails['cmsid'] =  $articleID->item(0)->nodeValue;
	//Date Accepted - History - Day,Month,Year
	$dayAccept = $articleXpath->query("//history/date[@date-type='accepted']/day");
	$monthAccept = $articleXpath->query("//history/date[@date-type='accepted']/month");
	$yearAccept = $articleXpath->query("//history/date[@date-type='accepted']/year");
	$articleDetails['dateAccepted'] = $yearAccept->item(0)->nodeValue . "-" . $monthAccept->item(0)->nodeValue . "-" . $dayAccept->item(0)->nodeValue;

	// word count, exclude ref
	$wordCount = $articleXpath->query("//workflow[@word-count]/@word-count");
	$articleDetails['wordCount'] = "Not found";
	if($wordCount->length > 0) {
		$articleDetails['wordCount'] = $wordCount->item(0)->nodeValue;
	}
	$wordCountExcludeRef = $articleXpath->query("//workflow[@word-count-without-ref]/@word-count-without-ref");
	$articleDetails['excludeRef'] = "Not found";
	if($wordCountExcludeRef->length > 0) {
		$articleDetails['excludeRef'] = $wordCountExcludeRef->item(0)->nodeValue;
	}

	// collect workflow information
	$workflowDetails = $articleXpath->query("//workflow/stage");
	$workflowData = "";
	if($workflowDetails->length > 0) {
		foreach ($workflowDetails as $workflow) {
			$workflowData .= 'Name:' . $workflow->getAttribute('name');
			$taskDatas = $articleXpath->query('.//task', $workflow);
			if($taskDatas->length > 0) {
				foreach ($taskDatas as $taskData) {
					$taskStart = $taskData->getAttribute('start_date');
					$taskDue = $taskData->getAttribute('end_date');
					$taskEnd = $taskData->getAttribute('end_time');
					$taskAssignedTo = $taskData->getAttribute('assigned_to');
					$taskAssignedBy = $taskData->getAttribute('assigned_by');
					$taskStatus = $taskData->getAttribute('status');
					$workflowData .= '|Start:'.$taskStart.'|Due:'.$taskDue.'|End:'.$taskEnd.'|AssignedTo:'.$taskAssignedTo.'|AssignedBy:'. $taskAssignedBy.'|taskStatus:'.$taskStatus.'#';
				}
			}
		}
	}
	$articleDetails['workflow'] = $workflowData;
	if(strlen(trim($articleDetails['pubDate']))<10) {
		$articleDetails['pubDate'] = '';
	}
	//Date Entered into Kriya - Stage - Preediting - Start date
	$dateEntered = $articleXpath->query("//stage[@name='Pre-editing']/@start_date");
	$articleDetails['dateEntered'] = $dateEntered->item(0)->nodeValue;

	//Post Author Validation
	$postAuthorCount = $articleXpath->query("//stage[@name='Post Author Validation']");
	$articleDetails['postAuthorCount'] = $postAuthorCount->length;

	//Silent Correction
	$silentCount = $articleXpath->query("//stage[@name='Silent correction']");
	$articleDetails['silentCorrection'] = $silentCount->length;

	//Resupply Online
	$reSupplyCount = $articleXpath->query("//stage[@name='Resupply Online']");
	$articleDetails['reSupplyCount'] = $reSupplyCount->length;

	//New version
	$newVersionCount = $articleXpath->query("//stage[@name='New version']");
	$articleDetails['newVersionCount'] = $newVersionCount->length;

	//Vor pub Date
	$sql = "SELECT pub_date, poa_date from e_relatedarticles where article_id='" . $articleDetails['doi']. "'";
	if($result = mysql_query($sql, $link)) {
		while($row=mysql_fetch_assoc($result)) {
			$articleDetails['vorPubDate'] = $row['pub_date'];
			$articleDetails['pubDate'] = $row['poa_date'];

		}
		mysql_free_result($result);
	}
	else {
		$articleDetails['vorPubDate'] = "";
	}
	if ($digestStatus == '0'){
		$articleDetails['digestStatus'] = 'No';
		//echo $file . ' - No Digest </br>';
		$noDigestCount++;
	}
	else {
		$articleDetails['digestStatus'] = 'Yes';
		$uploadCount++;
		//Digest Date
		$checkFirstDigest = "Select MIN(updatedOn) from `__t_contentQueue` where fileName LIKE '%digest_%' and cmsID = " . $articleDetails['cmsid'];
		if($result2 = mysql_query($checkFirstDigest,$link2)) {
			while($row2=mysql_fetch_row($result2)) {
				$articleDetails['dateDigestLoad'] = $row2[0];
			}
			mysql_free_result($result2);
		}
		else {
			$articleDetails['dateDigestLoad'] = "";
		}
	}
	
	// Check whether sub-article exists
	$subArticleInfo =  $articleXpath->query("//sub-article[@article-type='article-commentary']/div/boxed-text");
	$subArticleStatus = 'No';
	if($subArticleInfo->length > 0)
	{
		$subArticleStatus = 'Yes';
		//Digest Date
		$checkFirstDecision = "Select MIN(updatedOn) from `__t_contentQueue` where fileName LIKE '%decision_%' and cmsID = " . $articleDetails['cmsid'];
		if($result2 = mysql_query($checkFirstDecision,$link2)) {
			while($row2=mysql_fetch_row($result2)) {
				$articleDetails['dateSubArticleLoad'] = $row2[0];
			}
			mysql_free_result($result2);
		}
		else {
			$articleDetails['dateSubArticleLoad'] = "";
		}
	}
	
	// Copyediting Level
	$ceReqs = $articleXpath->query('//custom-meta');
	$ceLevel = 1;
	foreach ($ceReqs as $ceReq){
		if (preg_match('/copy[\s\-]+editing/i', $ceReq->nodeValue)){
			$meta = $articleXpath->query('.//meta-value', $ceReq);
			if ($meta->length > 0){
				if(preg_match('/^(2|3)$/', $meta->item(0)->nodeValue)){
					$ceLevel = $meta->item(0)->nodeValue;
				}
			}
		}
	}
	
	$dbArticleID = $articleDetails['doi'];
	$dbArticleType = $articleDetails['articleType'];
	$dbWordCount = $articleDetails['wordCount'];
	$dbExcludeRef = $articleDetails['excludeRef'];
	$dbDateAccepted = $articleDetails['dateAccepted'];
	$dbDateEntered = $articleDetails['dateEntered'];
	$dbDigest = $articleDetails['digestStatus'];
	$dbPubDate = $articleDetails['pubDate'];
	$dbVorPubDate = $articleDetails['vorPubDate'];
	$dbBucket = $articleDetails['bucket'];
	$dbCurrentStage = $articleDetails['currentStage'];
	$dbRelatedArticles = $articleDetails['relatedArticles'];
	$dbPressDate = $articleDetails['pressDate'];
	$dbHomePage = $articleDetails['homePage'];
	$dbPostAuthor = $articleDetails['postAuthorCount'];
	$dbSilentCorrection = $articleDetails['silentCorrection'];
	$dbResupplyOnline = $articleDetails['reSupplyCount'];
	$dbNewVersion = $articleDetails['newVersionCount'];
	$dbWorkflow = $articleDetails['workflow'];
	$dbdateDigestLoad = $articleDetails['dateDigestLoad'];
	$dbdateDecisionLoad = $articleDetails['dateSubArticleLoad'];
	
	if($dbCurrentStage=='Content-loading') {
		continue;
	}
	// Updated by Saravanan K. Date: 01-Nov-2019; Gitlab: #335-Reporting: No digest set date missing
$query = "SELECT dateNoDigestSet,dateOfComment,authorName,additionalComments,ratingValue from elife_report_data where articleID='" . $dbArticleID ."'";
$dbDateNoDigestSet = "";
$dbDateOfComment = "";
$dbAuthorName = "";
$dbAdditionalComments = "";
$dbRatingValue = "";

if($result2 = mysql_query($query,$conn)) {
	while($row2=mysql_fetch_assoc($result2)) {
		if(!empty($row2['dateNoDigestSet'])) {
			$dbDateNoDigestSet = $row2['dateNoDigestSet'];
			$dbDigest = 'No';
		}
		if(!empty($row2['dateOfComment'])) {
			$dbDateOfComment = $row2['dateOfComment'];
		}
		if(!empty($row2['authorName'])) {
			$dbAuthorName = $row2['authorName'];
		}
		if(!empty($row2['additionalComments'])) {
			$dbAdditionalComments = $row2['additionalComments'];
		}
		if(!empty($row2['ratingValue'])) {
			$dbRatingValue = $row2['ratingValue'];
		}
		
		
	}
	mysql_free_result($result2);
}


	$query = "DELETE from elife_report_data where articleID='" . $dbArticleID."'";
	$retval = mysql_query($query,$conn);
	if (empty($dbDateOfComment)) {
		$dbDateOfComment='null';
		// echo $dbDateOfComment;
		// echo "dataofcomment";
		$query = "INSERT INTO elife_report_data  (articleID, articleType, wordCount, excludeRef, dateAccepted, dateEntered, digestStatus, pubDate, vorPubDate, bucket, currentStage, relatedArticles, pressDate, homePage, postAuthorCount, silentCorrection, resupplyOnline, newVersion, workflow, dateNoDigestSet, subArticleStatus, dateDigestLoad, dateSubArticleLoad, ceLevel, dateOfComment, authorName, additionalComments, ratingValue)".
			"VALUES ('$dbArticleID','$dbArticleType','$dbWordCount','$dbExcludeRef','$dbDateAccepted','$dbDateEntered','$dbDigest', '$dbPubDate', '$dbVorPubDate','$dbBucket', '$dbCurrentStage', '$dbRelatedArticles', '$dbPressDate', '$dbHomePage', '$dbPostAuthor', '$dbSilentCorrection', '$dbResupplyOnline', '$dbNewVersion','$dbWorkflow','$dbDateNoDigestSet','$subArticleStatus','$dbdateDigestLoad','$dbdateDecisionLoad','$ceLevel',null,'$dbAuthorName','$dbAdditionalComments','$dbRatingValue')";
	
	}
	else{
	
	$query = "INSERT INTO elife_report_data  (articleID, articleType, wordCount, excludeRef, dateAccepted, dateEntered, digestStatus, pubDate, vorPubDate, bucket, currentStage, relatedArticles, pressDate, homePage, postAuthorCount, silentCorrection, resupplyOnline, newVersion, workflow, dateNoDigestSet, subArticleStatus, dateDigestLoad, dateSubArticleLoad, ceLevel, dateOfComment, authorName, additionalComments, ratingValue)".
			"VALUES ('$dbArticleID','$dbArticleType','$dbWordCount','$dbExcludeRef','$dbDateAccepted','$dbDateEntered','$dbDigest', '$dbPubDate', '$dbVorPubDate','$dbBucket', '$dbCurrentStage', '$dbRelatedArticles', '$dbPressDate', '$dbHomePage', '$dbPostAuthor', '$dbSilentCorrection', '$dbResupplyOnline', '$dbNewVersion','$dbWorkflow','$dbDateNoDigestSet','$subArticleStatus','$dbdateDigestLoad','$dbdateDecisionLoad','$ceLevel','$dbDateOfComment','$dbAuthorName','$dbAdditionalComments','$dbRatingValue')";
	}			
		$retval = mysql_query($query, $conn);
	file_put_contents('C:/wamp64/www/elife-report-system/eLifeReports/report17.txt',$query);
	return;
}


function checkDigest($articleDom, $articleXpath){
	//global $articleDom, $articleXpath;
	#get status of digest
	$digestStatus = '0';
	$artTypeNode = '';
	$artType = $articleXpath->query("//subj-group[@subj-group-type='display-channel']/subject");
	if ($artType->length > 0){
		$artTypeNode = $artType->item(0)->nodeValue;
	}
	$digest = $articleXpath->query("//abstract[@abstract-type='executive-summary']");
	## Bug Id - 1392 - Dhatshayani . D September 02, 2016 - added "Registered Report" in regex to check digest for this type of article too.
	// Updated by Saravanan K. Date: 19-Oct-2019; Gitlab: #327 - Reporting bug: Load to Kriya date being used for digest load date
	if (preg_match('/Research article|Short report|Tools and resource|Registered Report|Research Communication|Review Article/i', $artTypeNode)){
		if ($digest->length > 0){
			$digestStatus = '1';
			if (strlen($digest->item(0)->nodeValue) > 50){
				$digestStatus = '2';
			}else if (preg_match('/No Digest/', $digest->item(0)->nodeValue)){
				$digestStatus = '0';
			}
		}
	}
	return $digestStatus;
}


//Get current stage
function getCurrentStage($articleDom, $articleXpath){
	$stageName = '-';
	$stage = $articleXpath->query("//stage/task[@status='in-progress']/../@name");
	if ($stage->length > 0){
		$stageName = $stage->item(0)->nodeValue;
	}

	return $stageName;
}

// update press date
function updatePressStatus($pressCmsID, $pressDate, $confirmedStatus, $userNamePress, $pressProcessType) {
	include "includes/config.php";
	$articleQuery = "SELECT f_doi from t_articles where f_children='" . $pressCmsID ."'";
	if($result = mysql_query($articleQuery, $link)) {
		while($row=mysql_fetch_assoc($result)) {
			$articleID = $row['f_doi'];
		}
		mysql_free_result($result);
	}
	else {
		$articleID = "Not found";
	}
	$articleID = str_ireplace('elife', '', $articleID);
	if($articleID!="Not found" && $pressProcessType=="Add") {
		$query = "INSERT INTO pressdate_info (articleID, confirmedStatus, dateGiven, dateApplied, userName) VALUES ('" . $articleID . "', '" . $confirmedStatus . "', '" . $pressDate . "', '". date("d/m/Y") . "', '" . $userNamePress . "')";
		$result = mysql_query($query, $conn); 
	}
	elseif ($articleID!="Not found" && $pressProcessType=="Delete") {
		$rowID = '';
		$query = "SELECT max(id) as rowid from pressdate_info where articleID='" . $articleID . "'";
		if($result = mysql_query($query, $conn)) {
			while($row=mysql_fetch_assoc($result)) {
				$rowID = $row['rowid'];
			}
			//mysqli_free_result($result);
			if(!empty($rowID)) {
				$query = "UPDATE pressdate_info set pressStatusRemoved ='" . date('d/m/Y') . "' where id=" . $rowID;
				$result = mysql_query($query, $conn); 
			}
		}
	}
	return;
}

// update no digest date set 
function updateNoDigestSetDate($digestCmsID) {
	include "includes/config.php";
	$articleQuery = "SELECT f_doi from t_articles where f_children='" . $digestCmsID ."'";
	if($result = mysql_query($articleQuery, $link)) {
		while($row=mysql_fetch_assoc($result)) {
			$articleID = $row['f_doi'];
		}
		mysql_free_result($result);
	}
	else {
		$articleID = "Not found";
	}
	$articleID = str_ireplace('elife', '', $articleID);
	if($articleID!="Not found") {
		$currentDate = date('d/m/Y');
		$query = "UPDATE elife_report_data set dateNoDigestSet = '". $currentDate . "' where articleID ='".$articleID."'";
		$result = mysql_query($query, $conn);
	}
	return;
}
// Updated by Saravanan K. Date: 20-May-2019; To get the bucket name of given cms id
function getBucketName($elifeCmsID) {
	include_once('JSLikeHTMLElement.php');
	$url = "http://api.elife2.kriyadocs.com/job.api/getPublicationGroupDetails?publicationGroupIds=33679&apiKey=6c8e740baa82f222c5e63b39ffac2613&accountKey=1";
	$siteAddress = "http://api.elife2.kriyadocs.com/";
	$xpathXML = "";
	$post = stream_context_create(array(
			'http' => array(
					'method' => 'POST',
					'header' => "content: {$xpathXML}",
					"Content-Type: text/plain",
			)
	));

	$response = file_get_contents($url, false, $post);

	$response =  mb_convert_encoding($response, 'HTML-ENTITIES', "UTF-8");
	$cmsDom = new DOMDocument('1.0', 'UTF-8');
	$cmsDom->registerNodeClass('DOMElement', 'JSLikeHTMLElement');
	$cmsDom->loadHTML($response);
	$cmsXpath = new DOMXPath($cmsDom);

	$status = $cmsXpath->query('//status')->item(0);
	if($status->nodeValue == 'Ok'){
		$publicationIds = $cmsXpath->query("//publication");
		foreach($publicationIds as $publicationId) {
			if($publicationId->getAttribute('id')=='33679' or $publicationId->getAttribute('id')=='72172'  or $publicationId->getAttribute('id')=='75402'   or $publicationId->getAttribute('id')=='83342'   or $publicationId->getAttribute('id')=='80922'   or $publicationId->getAttribute('id')=='76872'   or $publicationId->getAttribute('id')=='74832'   or $publicationId->getAttribute('id')=='73482'   or $publicationId->getAttribute('id')=='70222'   or $publicationId->getAttribute('id')=='98812'   or $publicationId->getAttribute('id')=='98822' or $publicationId->getAttribute('id')=='89771') {
				continue;
			}
			$bucketID = $publicationId->getAttribute('id');
			$bucketName = $publicationId->getAttribute('name');
			$url = "http://api.elife2.kriyadocs.com/job.api/getPublicationGroupDetails?publicationGroupIds=".$bucketID."&apiKey=6c8e740baa82f222c5e63b39ffac2613&accountKey=1";
			$siteAddress = "http://api.elife2.kriyadocs.com/";

			$xpathXML = "";
			$post = stream_context_create(array(
					'http' => array(
							'method' => 'POST',
							'header' => "content: {$xpathXML}",
							"Content-Type: text/plain",
					)
			));

			$response = file_get_contents($url, false, $post);
			$response =  mb_convert_encoding($response, 'HTML-ENTITIES', "UTF-8");
			$cmsDom = new DOMDocument('1.0', 'UTF-8');
			$cmsDom->registerNodeClass('DOMElement', 'JSLikeHTMLElement');
			$cmsDom->loadHTML($response);
			$cmsXpath = new DOMXPath($cmsDom);

			$status = $cmsXpath->query('//status')->item(0);
			if($status->nodeValue == 'Ok'){
				$cmsids = $cmsXpath->query("//article");
				foreach($cmsids as $cmsid) {
					if($elifeCmsID == $cmsid->getAttribute('cmsid')) {
						return $bucketName;
					}
				}
			}
		}
	}

}

function updateAuthorRating($articleCmsID, $authorName, $authorRating, $additionalComments) {
	include "includes/config.php";
	$articleQuery = "SELECT f_doi from t_articles where f_children='" . $articleCmsID ."'";
	if($result = mysql_query($articleQuery, $link)) {
		while($row=mysql_fetch_assoc($result)) {
			$articleID = $row['f_doi'];
		}
		mysql_free_result($result);
	}
	else {
		$articleID = "Not found";
	}
	$articleID = str_ireplace('elife', '', $articleID);
	if($articleID!="Not found") {
		$currentDate = date('Y-m-d');
		
		$query = "UPDATE elife_report_data set dateOfComment = '". $currentDate . "', authorName = '" . $authorName . "', ratingValue= '". $authorRating ."', additionalComments = '". $additionalComments . "' where articleID ='".$articleID."'";
		$result = mysql_query($query, $conn);
	}
	return;
}

// Close database connection
mysqli_close($connection1);
mysqli_close($connection2);

?>
