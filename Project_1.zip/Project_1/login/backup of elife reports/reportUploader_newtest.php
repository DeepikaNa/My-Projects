<?php
/*
 * #Gitlab ID: #311 - Delivering output of reports to eLife AWS
 * Developed by - Saravanan K. Date: 25-Sep-2019
 *
 */
ini_set('max_execution_time', 0);
error_reporting(E_ERROR | E_PARSE);
date_default_timezone_set('Asia/Kolkata');
if(PHP_OS != "WINNT"){
	//require_once("/var/www/html/_default/cms/cms-{$_SESSION['CMS_VERSION']}/ecs_includes/packageCreator/vendor/autoload.php");
	require_once("/var/www/html/_default/cms/cms-0.9.40-alpha-eLife2/ecs_includes/packageCreator/vendor/autoload.php");
}else{										
	include_once (__DIR__.'/vendor/autoload.php');
}
// S3 Initialization
use Aws\S3\S3Client;
use Melihucar\FtpClient\FtpClient;

$s3 = S3Client::factory(array(
		'credentials' => array(
				'key'    => 'AKIAXOXT77XQPYBXCS5H',
				'secret' => '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',
				'region'=>'us-east-1',
		)
));

// Database connectivity
$dbhost = 'localhost:3306';
//$dbuser = '__reports';
$dbuser = 'root';
// $dbpass = '__reports@CMS33';
$dbpass = 'Exeter@123';

$db3 = 'eLife_reports';

if (!$conn = mysql_connect($dbhost, $dbuser, $dbpass)) {
	echo 'Could not connect to mysql';
	exit;
}

if (!mysql_select_db($db3, $conn)) {
	echo 'Could not select database';
	exit;
}


file_put_contents('C:/wamp64/www/elife-report-system/log/reports1.txt', "process started");
$tatArray = array('Pre-editing'=>1, 'Publisher Check'=>2,'Typesetter QA'=>1,'Deliver digest'=>2,'Author Review'=>3,'Post Author Validation'=>1,'Publisher Review'=>2,'Final Deliverables'=>1,'Resupply Online'=>1,'New Version'=>1,'Validation Check'=>1,'Official correction'=>1,'Copyediting'=>1,'Typesetter Review'=>1,'Silent Resupply'=>1,'Ready for Publication'=>1,'Silent correction'=>1,'Feature Review'=>3);
// Report 1: WIP_Stage_Summary
	$query = "SELECT * FROM elife_report_data where bucket='Articles in progress'";
	$result = mysql_query($query,$conn);
	$i=1;
	$csv_row = '';
	$csv_header = "Article, Word count, Exclude Reference, Days in production, Current stage, Article type, Assignee, Accepted Date, Exported Date, Pre-editing, Copyediting, Publisher Check, Deliver digest, Typesetter QA, Author Review, Post Author Validation, Publisher Review, Author, Rating, Additional Comments\n";
	while ($row = mysql_fetch_assoc($result)) {

		if(trim($row['dateEntered']!='')) {
			$currentTime = strtotime(date('Y-m-d'));
			$secondsInProduction = $currentTime - strtotime($row['dateEntered']);
			$totalDaysInProduction = $secondsInProduction / 86400;
		}
		$relatedArticles = str_replace("|", ",", $row['relatedArticles']);
		$workflowDetails = explode('#',$row['workflow']);
		if(count($workflowDetails)>0) {
			$preEditCount = 0;
			$copyeditingCount = 0;
			$publisherCheckCount =0;
			$typesetterQaCount =0;
			$authorReviewCount= 0;
			$pavCount = 0;
			$currentAssignee = '';
			$preEditStart = '';
			$pavStart = '';
			$copyEditStart = '';
			$pubCheckStart = '';
			$tqaStart = '';
			$arStart = '';
			$prStart = '';
			$ddStart = '';

			foreach($workflowDetails as $workflowDetail) {
				// Pre-edit
				if(strpos($workflowDetail, 'Pre-editing')!== false) {
					$individualStageDetails = explode('|', $workflowDetail);
					foreach($individualStageDetails as $individualStageDetail) {
						$preEditCount++;
						$preEditName= 'Pre-editing';
						if(strpos($individualStageDetail, 'Start:')!== false) {
							$preEditStart = str_replace('Start:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'Due:')!== false) {
							$preEditDue = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'End:')!== false) {
							$preEditEnd = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
							$preEditAssignee = str_replace('AssignedTo:','',$individualStageDetail);
						}
						//taskStatus:in-progress
						if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
							$currentAssignee = $preEditAssignee;
						}
					}
				}
				// Copyedit
				if(strpos($workflowDetail, 'Copyediting')!== false) {
					$individualStageDetails = explode('|', $workflowDetail);
					foreach($individualStageDetails as $individualStageDetail) {
						$copyEditCount++;
						$copyEditName= 'Copyediting';
						if(strpos($individualStageDetail, 'Start:')!== false) {
							$copyEditStart = str_replace('Start:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'Due:')!== false) {
							$copyEditDue = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'End:')!== false) {
							$copyEditEnd = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
							$copyEditAssignee = str_replace('AssignedTo:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
							$currentAssignee = $copyEditAssignee;
						}
					}
				}

				// Publisher Check
				if(strpos($workflowDetail, 'Publisher Check')!== false) {
					$individualStageDetails = explode('|', $workflowDetail);
					foreach($individualStageDetails as $individualStageDetail) {
						$pubCheckEditCount++;
						$pubCheckName= 'Publisher Check';
						if(strpos($individualStageDetail, 'Start:')!== false) {
							$pubCheckStart = str_replace('Start:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'Due:')!== false) {
							$pubCheckDue = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'End:')!== false) {
							$pubCheckEnd = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
							$pubCheckAssignee = str_replace('AssignedTo:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
							$currentAssignee = $pubCheckAssignee;
						}
					}
				}

				// Typesetter QA
				if(strpos($workflowDetail, 'Typesetter QA')!== false) {
					$individualStageDetails = explode('|', $workflowDetail);
					foreach($individualStageDetails as $individualStageDetail) {
						$tqaCount++;
						$tqaName= 'Typesetter QA';
						if(strpos($individualStageDetail, 'Start:')!== false) {
							$tqaStart = str_replace('Start:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'Due:')!== false) {
							$tqaDue = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'End:')!== false) {
							$tqaEnd = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
							$tqaAssignee = str_replace('AssignedTo:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
							$currentAssignee = $tqaAssignee;
						}
					}
				}

				// Post Author Validation
				if(strpos($workflowDetail, 'Post Author Validation')!== false) {
					$individualStageDetails = explode('|', $workflowDetail);
					foreach($individualStageDetails as $individualStageDetail) {
						$pavCount++;
						$pavName= 'Post Author Validation';
						if(strpos($individualStageDetail, 'Start:')!== false) {
							$pavStart = str_replace('Start:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'Due:')!== false) {
							$pavDue = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'End:')!== false) {
							$pavEnd = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
							$pavAssignee = str_replace('AssignedTo:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
							$currentAssignee = $pavAssignee;
						}
					}
				}

				// Author Review
				if(strpos($workflowDetail, 'Author Review')!== false) {
					$individualStageDetails = explode('|', $workflowDetail);
					foreach($individualStageDetails as $individualStageDetail) {
						$arCount++;
						$arName= 'Author Review';
						if(strpos($individualStageDetail, 'Start:')!== false) {
							$arStart = str_replace('Start:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'Due:')!== false) {
							$arDue = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'End:')!== false) {
							$arEnd = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
							$arAssignee = str_replace('AssignedTo:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
							$currentAssignee = $arAssignee;
						}
					}
				}

				// Publisher Review
				if(strpos($workflowDetail, 'Publisher Review')!== false) {
					$individualStageDetails = explode('|', $workflowDetail);
					foreach($individualStageDetails as $individualStageDetail) {
						$prCount++;
						$prName= 'Publisher Review';
						if(strpos($individualStageDetail, 'Start:')!== false) {
							$prStart = str_replace('Start:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'Due:')!== false) {
							$prDue = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'End:')!== false) {
							$prEnd = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
							$prAssignee = str_replace('AssignedTo:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
							$currentAssignee = $prAssignee;
						}
					}
				}

				// Deliver digest
				// Updated by Saravanan K. Date: 21-Oct-2019; Gitlab: #327 - Reporting bug: Load to Kriya date being used for digest load date
				if(strpos($workflowDetail, 'Deliver digest')!== false && ($row['digestStatus']=='Yes' || $row['subArticleStatus']=='Yes')) {
					$individualStageDetails = explode('|', $workflowDetail);
					foreach($individualStageDetails as $individualStageDetail) {
						$ddCount++;
						$ddName= 'Deliver digest';
						if(strpos($individualStageDetail, 'Start:')!== false) {
							$ddStart = str_replace('Start:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'Due:')!== false) {
							$ddDue = str_replace('Due:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'End:')!== false) {
							$ddEnd = $individualStageDetail;
						}
						if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
							$ddAssignee = str_replace('AssignedTo:','',$individualStageDetail);
						}
						if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
							$currentAssignee = $ddAssignee;
						}
					}
				}
			}
		}
		$csv_row .= "{$row['articleID']}, {$row['wordCount']}, {$row['excludeRef']}, {$totalDaysInProduction}, {$row['currentStage']}, {$row['articleType']}, {$currentAssignee}, {$row['dateAccepted']}, {$row['dateEntered']}, {$preEditStart}, {$copyEditStart}, {$pubCheckStart}, {$ddStart}, {$tqaStart}, {$arStart}, {$pavStart}, {$prStart},{$row['authorName']},{$row['ratingValue']},\"{$row['additionalComments']}\"\n";
	}
	$fileName = 'WIP_Stage_Summary_'. date("Y-m-d") . '.csv';
	$content = $csv_header . $csv_row;
	$fd = fopen($fileName, "w");
	fputs($fd, $content);
	fclose($fd);
	file_put_contents('C:/wamp64/www/elife-report-system/log/WIP_Stage_Summary.csv', $content);
	if(file_exists($fileName)) {

		$result = $s3->putObject([
				'Bucket' => 'prod-elife-kriya',
				'Key'    => $fileName,
				'SourceFile' => $fileName
				]);
		
	}
	unlink($fileName);
	file_put_contents('C:/wamp64/www/elife-report-system/log/reports2.txt', "vip stage history");

	// Report 2: WIP_Stage_History
	$query = "SELECT * FROM elife_report_data where bucket='Articles in progress'";
	$result = mysql_query($query,$conn);
	// Updated by Saravanan K. Date: 16-Oct-2019; Gitlab: #323 - Adding count of how many times an article has been in a stage to reports
	$csv_header = "Article, Article Type, Stage Name, Times at Stage, Stage Owner, Start Date, Due Date, Completed Date, Task Status, Delay\n";
	$csv_row = '';
	$i=1;
	while ($row = mysql_fetch_assoc($result)) {

		if(trim($row['dateEntered']!='')) {
			$currentTime = strtotime(date('Y-m-d'));
			$secondsInProduction = $currentTime - strtotime($row['dateEntered']);
			$totalDaysInProduction = $secondsInProduction / 86400;
		}
		$relatedArticles = str_replace("|", ",", $row['relatedArticles']);

		$workflowDetails = explode('#',$row['workflow']);
		if(count($workflowDetails)>0) {
			$preEditCount = 0;
			$copyeditingCount = 0;
			$publisherCheckCount =0;
			$typesetterQaCount =0;
			$authorReviewCount= 0;
			$pavCount = 0;
			$currentAssignee = '';
			$preEditStart = '';
			$pavStart = '';
			$pavEnd = '';
			$copyEditStart = '';
			$pubCheckStart = '';
			$tqaStart = '';
			$arStart = '';
			$prStart = '';
			$ddStart = '';
			$stageNameArray = array();
			foreach($workflowDetails as $workflowDetail) {

				$stageInfo = explode('|',$workflowDetail);
				if(empty($stageInfo[0])) {continue;}
				// Updated by Saravanan K. Date: 21-Oct-2019; Gitlab: #327 - Reporting bug: Load to Kriya date being used for digest load date
				if ($stageInfo[0]=='Name:Deliver digest' && $row['digestStatus']=='No' && $row['subArticleStatus']=='No' && $row['subArticleStatus']=='No') {continue;}
				$stageName = str_replace('Name:','',$stageInfo[0]);
				// Updated by Saravanan K. Date: 16-Oct-2019; Gitlab: #323 - Adding count of how many times an article has been in a stage to reports
				array_push($stageNameArray, $stageName);
				$tmp = array_count_values($stageNameArray);
				$cnt = $tmp[$stageName];
				$stageOwner = str_replace('AssignedTo:','',$stageInfo[4]);

				$startDate = str_replace('Start:','',$stageInfo[1]);
				if($startDate!='') {
					$startDate = date('Y-m-d',strtotime($startDate));
					//$dueDate = date('Y-m-d', strtotime($startDate.' +' . $tatArray[$stageName] .' day'));
				}
				$dueDate = str_replace('Due:','',$stageInfo[2]);
				if($dueDate!='') {
					$dueDate = date('Y-m-d',strtotime($dueDate));
				}

				$endDate = trim(str_replace('End:','',$stageInfo[3]));
				if(empty($endDate) && !empty($dueDate)) {$endDate = $dueDate;}
				if(empty($startDate) && !empty($dueDate)) {$startDate = $dueDate;}
				if(empty($endDate) && !empty($startDate)) {$endDate = $startDate;}

				if(empty($startDate)) {continue;}
				if($pavEnd && date('Y-m-d',strtotime($pavEnd)) > date('Y-m-d',strtotime($startDate)))continue;
				$pavEnd = $endDate;
				$makedDueDate = date('Y-m-d', strtotime($startDate.' +' . $tatArray[$stageName] .' day'));
				if(date('D', strtotime($startDate)) == "Fri"){
					$makedDueDate = date('Y-m-d', strtotime($makedDueDate.' +2 day'));
				}
				$tt=date("D",strtotime($makedDueDate));
				if($tt=='Sun') {
					$makedDueDate = date('Y-m-d', strtotime($makedDueDate.' +1 day'));
				}
				if($tt=='Sat') {
					$makedDueDate = date('Y-m-d', strtotime($makedDueDate.' +2 day'));
				}
				$taskStatus = str_replace('taskStatus:','',$stageInfo[6]);
				$delay = '-';
				if($taskStatus == "waiting")continue;
				if($taskStatus == "in-progress"){
					$endDate = date('Y-m-d');
				}


				if($endDate!='') {
					$endDate = date('Y-m-d',strtotime($endDate));
					$datediff = strtotime($endDate) - strtotime($makedDueDate);
					if(strtotime($makedDueDate) < strtotime($endDate))
					{
						$delay =  round($datediff / (60 * 60 * 24));
					}
				}
				if($taskStatus == "in-progress")$endDate = "-";
				if(!$stageOwner)continue;
				//Should not come Author Review stage for correction articles- kirankumar
				if($row['articleType'] == "Correction" && $stageName == "Author Review") {continue;}
				$csv_row .= "eLife{$row['articleID']}, {$row['articleType']}, {$stageName}, {$cnt},  {$stageOwner}, {$startDate}, {$makedDueDate}, {$endDate}, {$taskStatus}, {$delay}\n";

			}
			}


	}
	$fileName = 'WIP_Stage_History_'. date("Y-m-d") . '.csv';
	$content = $csv_header . $csv_row;
	$fd = fopen($fileName, "w");
	fputs($fd, $content);
	fclose($fd);
	file_put_contents('C:/wamp64/www/elife-report-system/log/WIP_Stage_History.csv', $content);


	if(file_exists($fileName)) {

		$result = $s3->putObject([
				'Bucket' => 'prod-elife-kriya',
				'Key'    => $fileName,
				'SourceFile' => $fileName
				]);
	}
	unlink($fileName);
	file_put_contents('C:/wamp64/www/elife-report-system/log/reports3.txt', "published stage summary");

	// Report 3: Published_Stage_Summary
	$query = "SELECT * FROM elife_report_data where bucket!='Articles in progress'";
	$result = mysql_query($query, $conn);
	$csv_header = "Article, Word count, Exclude Reference, Days in production, Article type, Accepted Date, Exported Date, Pre-editing, Copyediting, Publisher Check, Deliver digest, Typesetter QA, Author Review, Post Author Validation, Publisher Review, Author, Rating, Additional Comments\n";
	$i=1;
	$csv_row = '';
	while ($row = mysql_fetch_assoc($result)) {
		$daysInEJP = 0;
		$daysInKriya = 0;
		if(trim($row['dateEntered']!='')) {
			$currentTime = strtotime(date('Y-m-d'));
			$secondsInProduction = $currentTime - strtotime($row['dateEntered']);
			$totalDaysInProduction = $secondsInProduction / 86400;
		}
		$relatedArticles = str_replace("|", ",", $row['relatedArticles']);

	$workflowDetails = explode('#',$row['workflow']);
	if(count($workflowDetails)>0) {
		$preEditCount = 0;
		$copyeditingCount = 0;
		$publisherCheckCount =0;
		$typesetterQaCount =0;
		$authorReviewCount= 0;
		$pavCount = 0;
		$currentAssignee = '';
		$preEditStart = '';
		$pavStart = '';
		$copyEditStart = '';
		$pubCheckStart = '';
		$tqaStart = '';
		$arStart = '';
		$prStart = '';
		$ddStart = '';

		foreach($workflowDetails as $workflowDetail) {
			// Pre-edit
			if(strpos($workflowDetail, 'Pre-editing')!== false) {
				$individualStageDetails = explode('|', $workflowDetail);
				foreach($individualStageDetails as $individualStageDetail) {
					$preEditCount++;
					$preEditName= 'Pre-editing';
					if(strpos($individualStageDetail, 'Start:')!== false) {
						$preEditStart = str_replace('Start:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'Due:')!== false) {
						$preEditDue = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'End:')!== false) {
						$preEditEnd = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
						$preEditAssignee = str_replace('AssignedTo:','',$individualStageDetail);
					}
					//taskStatus:in-progress
					if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
						$currentAssignee = $preEditAssignee;
					}
				}
			}
			// Copyedit
			if(strpos($workflowDetail, 'Copyediting')!== false) {
				$individualStageDetails = explode('|', $workflowDetail);
				foreach($individualStageDetails as $individualStageDetail) {
					$copyEditCount++;
					$copyEditName= 'Copyediting';
					if(strpos($individualStageDetail, 'Start:')!== false) {
						$copyEditStart = str_replace('Start:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'Due:')!== false) {
						$copyEditDue = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'End:')!== false) {
						$copyEditEnd = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
						$copyEditAssignee = str_replace('AssignedTo:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
						$currentAssignee = $copyEditAssignee;
					}
				}
			}

			// Publisher Check
			if(strpos($workflowDetail, 'Publisher Check')!== false) {
				$individualStageDetails = explode('|', $workflowDetail);
				foreach($individualStageDetails as $individualStageDetail) {
					$pubCheckEditCount++;
					$pubCheckName= 'Publisher Check';
					if(strpos($individualStageDetail, 'Start:')!== false) {
						$pubCheckStart = str_replace('Start:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'Due:')!== false) {
						$pubCheckDue = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'End:')!== false) {
						$pubCheckEnd = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
						$pubCheckAssignee = str_replace('AssignedTo:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
						$currentAssignee = $pubCheckAssignee;
					}
				}
			}

			// Typesetter QA
			if(strpos($workflowDetail, 'Typesetter QA')!== false) {
				$individualStageDetails = explode('|', $workflowDetail);
				foreach($individualStageDetails as $individualStageDetail) {
					$tqaCount++;
					$tqaName= 'Typesetter QA';
					if(strpos($individualStageDetail, 'Start:')!== false) {
						$tqaStart = str_replace('Start:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'Due:')!== false) {
						$tqaDue = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'End:')!== false) {
						$tqaEnd = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
						$tqaAssignee = str_replace('AssignedTo:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
						$currentAssignee = $tqaAssignee;
					}
				}
			}

			// Post Author Validation
			if(strpos($workflowDetail, 'Post Author Validation')!== false) {
				$individualStageDetails = explode('|', $workflowDetail);
				foreach($individualStageDetails as $individualStageDetail) {
					$pavCount++;
					$pavName= 'Post Author Validation';
					if(strpos($individualStageDetail, 'Start:')!== false) {
						$pavStart = str_replace('Start:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'Due:')!== false) {
						$pavDue = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'End:')!== false) {
						$pavEnd = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
						$pavAssignee = str_replace('AssignedTo:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
						$currentAssignee = $pavAssignee;
					}
				}
			}

			// Author Review
			if(strpos($workflowDetail, 'Author Review')!== false) {
				$individualStageDetails = explode('|', $workflowDetail);
				foreach($individualStageDetails as $individualStageDetail) {
					$arCount++;
					$arName= 'Author Review';
					if(strpos($individualStageDetail, 'Start:')!== false) {
						$arStart = str_replace('Start:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'Due:')!== false) {
						$arDue = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'End:')!== false) {
						$arEnd = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
						$arAssignee = str_replace('AssignedTo:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
						$currentAssignee = $arAssignee;
					}
				}
			}

			// Publisher Review
			if(strpos($workflowDetail, 'Publisher Review')!== false) {
				$individualStageDetails = explode('|', $workflowDetail);
				foreach($individualStageDetails as $individualStageDetail) {
					$prCount++;
					$prName= 'Publisher Review';
					if(strpos($individualStageDetail, 'Start:')!== false) {
						$prStart = str_replace('Start:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'Due:')!== false) {
						$prDue = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'End:')!== false) {
						$prEnd = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
						$prAssignee = str_replace('AssignedTo:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
						$currentAssignee = $prAssignee;
					}
				}
			}

			// Deliver digest
			// Updated by Saravanan K. Date: 21-Oct-2019; Gitlab: #327 - Reporting bug: Load to Kriya date being used for digest load date
			if(strpos($workflowDetail, 'Deliver digest')!== false && ($row['digestStatus']=='Yes' || $row['subArticleStatus']=='Yes')) {
				$individualStageDetails = explode('|', $workflowDetail);
				foreach($individualStageDetails as $individualStageDetail) {
					$ddCount++;
					$ddName= 'Deliver digest';
					if(strpos($individualStageDetail, 'Start:')!== false) {
						$ddStart = str_replace('Start:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'Due:')!== false) {
						$ddDue = str_replace('Due:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'End:')!== false) {
						$ddEnd = $individualStageDetail;
					}
					if(strpos($individualStageDetail, 'AssignedTo:')!== false) {
						$ddAssignee = str_replace('AssignedTo:','',$individualStageDetail);
					}
					if(strpos($individualStageDetail, 'taskStatus:in-progress')!== false) {
						$currentAssignee = $ddAssignee;
					}
				}
			}


		}
	}

	$csv_row .= "{$row['articleID']}, {$row['wordCount']}, {$row['excludeRef']}, {$totalDaysInProduction}, {$row['articleType']}, {$row['dateAccepted']}, {$row['dateEntered']}, {$preEditStart}, {$copyEditStart}, {$pubCheckStart}, {$ddStart}, {$tqaStart}, {$arStart}, {$pavStart}, {$prStart},{$row['authorName']},{$row['ratingValue']},\"{$row['additionalComments']}\"\n";
}

	$fileName = 'Published_Stage_Summary_'. date("Y-m-d") . '.csv';
	$content = $csv_header . $csv_row;
	$fd = fopen($fileName, "w");
	fputs($fd, $content);
	fclose($fd);
	file_put_contents('C:/wamp64/www/elife-report-system/log/Published_Stage_Summary.csv', $content);

	if(file_exists($fileName)) {

		$result = $s3->putObject([
				'Bucket' => 'prod-elife-kriya',
				'Key'    => $fileName,
				'SourceFile' => $fileName
				]);
	}
	unlink($fileName);
	file_put_contents('C:/wamp64/www/elife-report-system/log/reports4.txt', "published stage history");

	// Report 4: Published_Stage_History
	$query = "SELECT * FROM elife_report_data where bucket!='Articles in progress'";
	$result = mysql_query($query, $conn);
	$csv_header =  "Article, Article Type, Stage Name, Times at Stage, Stage Owner, Start Date, Due Date, Completed Date, Task Status, Delay\n";
	$i=1;
	$csv_row = '';
	while ($row = mysql_fetch_assoc($result)) {
		$daysInEJP = 0;
		$daysInKriya = 0;
		if(trim($row['dateEntered']!='')) {
			$currentTime = strtotime(date('Y-m-d'));
			$secondsInProduction = $currentTime - strtotime($row['dateEntered']);
			$totalDaysInProduction = $secondsInProduction / 86400;
		}
	$relatedArticles = str_replace("|", ",", $row['relatedArticles']);

	$workflowDetails = explode('#',$row['workflow']);
	if(count($workflowDetails)>0) {
		$preEditCount = 0;
		$copyeditingCount = 0;
		$publisherCheckCount =0;
		$typesetterQaCount =0;
		$authorReviewCount= 0;
		$pavCount = 0;
		$currentAssignee = '';
		$preEditStart = '';
		$pavStart = '';
		$pavEnd = '';
		$copyEditStart = '';
		$pubCheckStart = '';
		$tqaStart = '';
		$arStart = '';
		$prStart = '';
		$ddStart = '';
		$stageNameArray = array();
		foreach($workflowDetails as $workflowDetail) {
			$stageInfo = explode('|',$workflowDetail);
			if(empty($stageInfo[0])) {continue;}
			// Deliver digest
			// Updated by Saravanan K. Date: 21-Oct-2019; Gitlab: #327 - Reporting bug: Load to Kriya date being used for digest load date
			if ($stageInfo[0]=='Name:Deliver digest' && $row['digestStatus']=='No' && $row['subArticleStatus']=='No') {continue;}
			$stageName = str_replace('Name:','',$stageInfo[0]);
			// Updated by Saravanan K. Date: 16-Oct-2019; Gitlab: #323 - Adding count of how many times an article has been in a stage to reports
			array_push($stageNameArray, $stageName);
			$tmp = array_count_values($stageNameArray);
			$cnt = $tmp[$stageName];
			$stageOwner = str_replace('AssignedTo:','',$stageInfo[4]);

			$startDate = str_replace('Start:','',$stageInfo[1]);
			if($startDate!='') {
				$startDate = date('Y-m-d',strtotime($startDate));
				//$dueDate = date('Y-m-d', strtotime($startDate.' +' . $tatArray[$stageName] .' day'));
			}
			$dueDate = str_replace('Due:','',$stageInfo[2]);
			if($dueDate!='') {
				$dueDate = date('Y-m-d',strtotime($dueDate));
			}

			$endDate = trim(str_replace('End:','',$stageInfo[3]));
			if(empty($endDate) && !empty($dueDate)) {$endDate = $dueDate;}
			if(empty($startDate) && !empty($dueDate)) {$startDate = $dueDate;}
			if(empty($endDate) && !empty($startDate)) {$endDate = $startDate;}

			if(empty($startDate)) {continue;}
			if($pavEnd && date('Y-m-d',strtotime($pavEnd)) > date('Y-m-d',strtotime($startDate)))
			continue;
			$pavEnd = $endDate;
			$makedDueDate = date('Y-m-d', strtotime($startDate.' +' . $tatArray[$stageName] .' day'));
			$tt=date("D",strtotime($makedDueDate));
			if($tt=='Sun') {
				$makedDueDate = date('Y-m-d', strtotime($makedDueDate.' +1 day'));
			}
			if($tt=='Sat') {
				$makedDueDate = date('Y-m-d', strtotime($makedDueDate.' +2 day'));
			}
			$taskStatus = str_replace('taskStatus:','',$stageInfo[6]);
			$delay = '-';
			if($taskStatus == "waiting")continue;
			if($taskStatus == "in-progress" && $stageName == "Final Deliverables" && "2019" > date('Y',strtotime($endDate))){
				$taskStatus =  "completed";
			}else if($taskStatus == "in-progress"){
				$endDate = date('Y-m-d');
			}

			if($endDate!='') {
				$endDate = date('Y-m-d',strtotime($endDate));
				$datediff = strtotime($endDate) - strtotime($makedDueDate);
				if(strtotime($makedDueDate) < strtotime($endDate))
				{
					$delay =  round($datediff / (60 * 60 * 24));
				}
			}
			if($taskStatus == "in-progress")$endDate = "-";
			if(!$stageOwner)continue;
			//Should not come Author Review stage for correction articles- kirankumar
			if($row['articleType'] == "Correction" && $stageName == "Author Review") {continue;}
			$csv_row .= "eLife{$row['articleID']}, {$row['articleType']}, {$stageName}, {$cnt}, {$stageOwner}, {$startDate}, {$makedDueDate}, {$endDate}, {$taskStatus}, {$delay}\n";
		}
	}
}
	$fileName = 'Published_Stage_History_'. date("Y-m-d") . '.csv';
	$content = $csv_header . $csv_row;
	$fd = fopen($fileName, "w");
	fputs($fd, $content);
	fclose($fd);
	file_put_contents('C:/wamp64/www/elife-report-system/log/Published_Stage_History.csv', $content);
	if(file_exists($fileName)) {
		$result = $s3->putObject([
				'Bucket' => 'prod-elife-kriya',
				'Key'    => $fileName,
				'SourceFile' => $fileName
				]);
	}
	unlink($fileName);
	file_put_contents('C:/wamp64/www/elife-report-system/log/reports5.txt', "press info");

	// Report 5: Press_Info
	$query = "SELECT * FROM pressdate_info";
	$result = mysql_query($query, $conn);

	$csv_header = "Article, Press status applied, Date given, Confirmed, Press status removed\n";
	$i=1;
	$csv_row = '';
	while ($row = mysql_fetch_assoc($result)) {
		$dateGiven = strtotime($row['dateGiven']);
		$givenDate = date('d/m/Y',$dateGiven);
			$csv_row .= "{$row['articleID']}, {$row['dateApplied']}, {$givenDate}, {$row['confirmedStatus']}, {$row['pressStatusRemoved']}\n";
		}
	$fileName = 'Press_Info_'. date("Y-m-d") . '.csv';
	$content = $csv_header . $csv_row;
	$fd = fopen($fileName, "w");
	fputs($fd, $content);
	fclose($fd);
	file_put_contents('C:/wamp64/www/elife-report-system/log/Press_Info.csv', $content);

	if(file_exists($fileName)) {
		$result = $s3->putObject([
				'Bucket' => 'prod-elife-kriya',
				'Key'    => $fileName,
				'SourceFile' => $fileName
				]);
	}
	unlink($fileName);
	file_put_contents('C:/wamp64/www/elife-report-system/log/reports6.txt', "digest");

	// Report 6: Digest_Sub-article_Info
	$query = "SELECT * FROM `elife_report_data`";
	$result = mysql_query($query, $conn);
	$csv_row ='';
	$csv_header = "Article, Digest Status, Digest Load Date, No Digest Set Date, Sub-Article Status, Sub-Article Load Date, Bucket, CE Level, Word count, Exclude Reference\n";
	$i=1;
	while ($row = mysql_fetch_assoc($result)) {
		$articleBucket = str_ireplace('Articles published in','',$row['bucket']);
		// Updated by Saravanan K. Date: 19-Oct-2019; Gitlab: #327 - Reporting bug: Load to Kriya date being used for digest load date
	$ddEnd = '';
	if(strpos($row['workflow'], 'Deliver digest')!== false && $row['digestStatus']=='Yes')  {
		$workflowDetails = explode('#',$row['workflow']);
		foreach($workflowDetails as $workflowDetail) {
			if(strpos($workflowDetail, 'Deliver digest')!== false)  {
				$individualStageDetails = explode('|', $workflowDetail);
				foreach($individualStageDetails as $individualStageDetail) {
					if(strpos($individualStageDetail, 'End:')!== false && strpos($workflowDetail, 'taskStatus:completed')!== false) {
						$ddEnd = str_replace('End:','',$individualStageDetail);
						break 2;
					}
				}
			}
		}
	}
		$csv_row .= "{$row['articleID']}, {$row['digestStatus']}, {$ddEnd}, {$row['dateNoDigestSet']}, {$row['subArticleStatus']}, {$row['dateSubArticleLoad']}, {$articleBucket}, {$row['ceLevel']}, {$row['wordCount']}, {$row['excludeRef']}\n";
	}
	$fileName = 'Digest_Sub-article_Info_'. date("Y-m-d") . '.csv';
	$content = $csv_header . $csv_row;
	$fd = fopen($fileName, "w");
	fputs($fd, $content);
	fclose($fd);
	file_put_contents('C:/wamp64/www/elife-report-system/log/Digest_Sub-article_Info.csv', $content);

	if(file_exists($fileName)) {
		$result = $s3->putObject([
				'Bucket' => 'prod-elife-kriya',
				'Key'    => $fileName,
				'SourceFile' => $fileName
				]);
	}
	unlink($fileName);

	echo "Success";
?>
