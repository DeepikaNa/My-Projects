<?php
echo(phpinfo ( ));
?>