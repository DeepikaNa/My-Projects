var express = require('express');
var fs = require('fs');
var app = express();


app.use(express.json());

app.get("/", function(req, res){
    htmlContent = fs.readFileSync('./index.html');
    res.writeHead(200, {'Content-Type': 'text/html'});    
    res.write(htmlContent);
    res.end();
});


app.listen(3000, function(){
    console.log("server is running on port: 3000");
})