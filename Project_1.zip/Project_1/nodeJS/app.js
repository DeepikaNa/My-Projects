express = require('express');
app = express();
fs = require('fs');
unirest = require('unirest');

app.use(express.static('public'));
app.use('/static', express.static('public'));

app.get('/', function(req, res){
    htmlContent = fs.readFileSync('./index.html');
    res.writeHead(200, {'Content-Type': 'text/html'});    
    res.write(htmlContent);
    res.end();
})


app.get('/api', function(req, res){
    start = new Date();
    unirest.post('http://localhost/nodeJS/timeout.php')
    .end(function(data){
        res.status(200).json({'status':'200', 'data':((new Date() - start)/1000)}).end();
    })
})

app.listen(3003)
console.log('Port: '+3003);