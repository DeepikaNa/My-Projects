
$('#button').on('click', function(){
    alert('sfd')
})