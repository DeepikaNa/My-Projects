<?php
    sleep(300);
    echo '';
    return;
?>