const libxml = require("libxmljs");
const fs = require("fs");
var dirFields = fs.readdirSync("./input");
if(dirFields.length){
    for(var j=0;j<dirFields.length;j++){
        writeFile(dirFields[j]);
    }
}


function writeFile(dirFile){
    if(dirFile.match(".xml")){
        fs.readFile("./input/"+dirFile,"utf-8",function(err,inputdata){
            try{
                var Rdata = replaceSymbols(inputdata);
                var data = Rdata.xmlData;
                let dom = libxml.parseXmlString(data);
                let fnNodes = dom.find("//fn");
                fnNodes.forEach(fnNode => {
                    let fnPNodes =  fnNode.find("p");
                    for(var i=0;i<fnPNodes.length;i++){
                        if(fnNode.attr("id")){
                            let id = fnNode.attr("id").value()+"-p"+(i+1);
                            fnPNodes[i].attr("id",id);
                        }
                    }
                });

                var secPNodes =  dom.find("//sec//p");
                for(var i=0;i < secPNodes.length;i++){
                        console.log(i)
                    taggingSce(secPNodes[i]);
                }

                var secPNodes =  dom.find("//sec//array");
                for(var i=0;i<secPNodes.length;i++){
                        console.log(i)
                    taggingSce(secPNodes[i]);
                }

                var secPNodes =  dom.find("//sec//list[not(contains(@list-content, 'example'))]");
                for(var i=0;i<secPNodes.length;i++){
                        console.log(i)
                    taggingSce(secPNodes[i]);
                }

                var secPNodes =  dom.find("//sec//disp-quote");
                for(var i=0;i<secPNodes.length;i++){
                        console.log(i)
                    taggingSce(secPNodes[i]);
                }

                var secNodes = dom.find("//sec/sec");
                secNodes.forEach(secNode => {
                    let secID = secNode.attr("id").value();
                    let sec = libxml.parseXmlString(secNode.toString());
                    let secPNodes =  sec.find("//p");
                    for(var i=0;i<secPNodes.length;i++){
                        let id = secPNodes[i].attr("id").value()+"-p"+(i+1);
                        secPNodes[i].attr("id",id);
                    }
                    let secArrayNodes =  sec.find("//array");
                    for(var i=0;i<secArrayNodes.length;i++){
                        let id = secArrayNodes[i].attr("id").value()+"-array"+(i+1);
                        secArrayNodes[i].attr("id",id);
                    }
                    let secListNodes =  sec.find("//list[not(contains(@list-content, 'example'))]");
                    for(var i=0;i<secListNodes.length;i++){
                        let id = secListNodes[i].attr("id").value()+"-list"+(i+1);
                        secListNodes[i].attr("id",id);
                    }
                    let secBlockNodes =  sec.find("//disp-quote");
                    for(var i=0;i<secBlockNodes.length;i++){
                        let id = secBlockNodes[i].attr("id").value()+"-disp-quote"+(i+1);
                        secBlockNodes[i].attr("id",id);
                    }
                    secNode.replace(libxml.parseXmlString(sec.toString()).root());
                });

                var secNodes = dom.find("//sec[not(ancestor::sec)]");
                secNodes.forEach(secNode => {
                    let secID = secNode.attr("id").value();
                    let sec = libxml.parseXmlString(secNode.toString());
                    let secPNodes =  sec.find("//p[not(contains(@id,'p'))]");
                    for(var i=0;i<secPNodes.length;i++){
                        let id = secPNodes[i].attr("id").value()+"-p"+(i+1);
                        secPNodes[i].attr("id",id);
                    }
                    let secArrayNodes =  sec.find("//array[not(contains(@id,'array'))]");
                    for(var i=0;i<secArrayNodes.length;i++){
                        let id = secArrayNodes[i].attr("id").value()+"-array"+(i+1);
                        secArrayNodes[i].attr("id",id);
                    }
                    let secListNodes =  sec.find("//list[not(contains(@list-content, 'example'))][not(contains(@id,'list'))]");
                    for(var i=0;i<secListNodes.length;i++){
                        let id = secListNodes[i].attr("id").value()+"-list"+(i+1);
                        secListNodes[i].attr("id",id);
                    }
                    let secBlockNodes =  sec.find("//disp-quote[not(contains(@id,'disp-quote'))]");
                    for(var i=0;i<secBlockNodes.length;i++){
                        let id = secBlockNodes[i].attr("id").value()+"-disp-quote"+(i+1);
                        secBlockNodes[i].attr("id",id);
                    }
                    secNode.replace(libxml.parseXmlString(sec.toString()).root());
                });
                
                let output = replaceEntity(dom.toString(),Rdata.matchs);
                fs.writeFile("./output/"+dirFile,output,function(err){
                    if(err) throw err;
                });
            }catch(e){
                console.log(dirFile);
            }
        });
    }
}


function taggingSce(tag,parentTag){
    if(parentTag && parentTag.name()=="sec"){
        let secid = parentTag.attr("id").value();
        if(tag.attr("id") && tag.attr("id").value())
        tag.attr("id",secid+"-"+tag.attr("id").value())
        else
        tag.attr("id",secid);
        console.log(tag.attr("id").value());
        //taggingSce(tag,parentTag.parent());
    }else if(parentTag && parentTag.name()=="body"){
        console.log("");
    }else if(!parentTag){
        tag.attr("id","");
        taggingSce(tag,tag.parent());
    }else{
        taggingSce(tag,parentTag.parent());
    }
    return tag;
}



/**
 * this function will replace all entitys
 */
function replaceEntity(xmlData,matchs){
    //return new Promise(resolve => {
        if(matchs && matchs.length >0){
            for(var i = 0; i < matchs.length; i++){
                var regx = new RegExp("#@"+i+"@#","g")
                xmlData = xmlData.replace(regx,matchs[i])
            }
        }
        return xmlData;
        //resolve(xmlData);
    //})
}

/**
 * this function will replace all entitys to numbers
 */
function replaceSymbols(xmlData){
    //return new Promise(resolve => {
        var entityData = {};
        var matchs = [...new Set(xmlData.match(/&#x[a-zA-Z0-9]*;/g))]
        if(matchs && matchs.length >0){
            for(var i = 0; i < matchs.length; i++){
                var regx = new RegExp(matchs[i],"g")
                xmlData = xmlData.replace(regx,"#@"+i+"@#")
            }
            //console.log(matchs)
        }
        return {xmlData,matchs};
        //resolve({xmlData,matchs});
    //})
}

