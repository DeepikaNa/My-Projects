const libxml = require("libxmljs");
const fs = require("fs");
var express = require("express");
var app = express();
var bodyParser = require('body-parser');
var multer = require('multer');
var http = require('http').Server(app);
var io = require('socket.io')(http);
var socket ={};
users = [];
io.on('connection', function(socket1) {
    socket = socket1;
    socket.on('msg', function(data) {
      //Send message to everyone
      io.sockets.emit('newmsg', data);
   })
});
var server = http.listen(8000, function() {
    const host = server.address().address;
    const port = server.address().port;
    console.log("App listening at http://", host, port);
  });
  app.use(bodyParser.json());
var Storage = multer.diskStorage({
  destination: function(req, file, callback) {
     callback(null, "./Inputs");
  },
  filename: function(req, file, callback) {
      callback(null, file.originalname);
  }
});
var upload = multer({
  storage: Storage
}).array("fileUploader", 3); //Fie

app.get("/", function(req, res) {
    res.sendFile(__dirname + "/public/index.html");
});
app.post("", function(req, res) {
  upload(req, res, function(err) {
      if (err) {
          console.log(err)
          return res.end("Something went wrong!");
      }
      //var path = 'D:/Deepika/MBS_pro_DP/MBS_pro/process/Map_supp';
      var path = './Inputs';
      var dir = fs.readdirSync(path);
      for (var i = 0; i < dir.length; i++) {
        var toPath = path;
        if (!fs.existsSync(toPath)) fs.mkdirSync(toPath);
        if (dir[i].match(/(\.xml)$/)) {
            return res.end("File uploaded sucessfully!!!");
            }
          else{
              return res.end("File uploaded Failed!!!");
            }
        }
        res.redirect('/');
    });
  })
