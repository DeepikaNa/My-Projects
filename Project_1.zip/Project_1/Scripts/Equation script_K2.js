convertEq(0);

function convertEq(index){
	console.log(index);

	  var eqNode = $(kriya.config.containerElm).find('.kriyaFormula:eq(' + index + ')');	
			 var configJson  = JSON.stringify(updateObj);
	  var mathType = 'inline';
	  if($(eqNode).closest('.jrnlEqnPara').length > 0){
		  mathType = 'display';
	  }
	  var texCode = $(eqNode).attr('data-tex');
	  if(!texCode){
	  	return false;
	  }
  
	  var parameter = {
					  'tex'      : texCode,
					  'customer' : kriya.config.content.customer,
					  'project'  : kriya.config.content.project,
					  'doi'      : kriya.config.content.doi,
					  'config'   : configJson,
					  'mathmode' : mathType
					};
	  kriya.general.sendAPIRequest('texconversion', parameter, function(data){
		console.log(data);
		var pngFile = (data.online)?data.online.png:'';
		data = data.print;
		var eqDepth = (data.eq_sizes.Depth)?Math.floor(parseFloat(data.eq_sizes.Depth) * 10)/10:'';
		var eqWidth  =  data.eq_sizes.Width;
		var eqHeight =  data.eq_sizes.TotalHeight;
		$(eqNode).removeAttr('data-eq-eps');
		$(eqNode).attr('src', pngFile).attr('data-tex', texCode).attr('data-eq-depth', eqDepth).attr('data-eq-height', data.eq_sizes.Height).attr('data-eq-totalheight', data.eq_sizes.TotalHeight).attr('data-eq-width', data.eq_sizes.Width).attr('data-primary-extension', 'pdf');
		kriyaEditor.htmlContent = kriyaEditor.settings.contentNode.innerHTML;
		kriyaEditor.settings.undoStack.push(eqNode);
		kriyaEditor.init.addUndoLevel('equation');
		convertEq(index+1);
	  });
}