convertEq(0);
function convertEq(index){
    console.log(index);
    var eqNode = $('#content').find('.kriyaFormula:eq(' + index + ')');
    var mathType = 'inline';
      if($(eqNode).closest('.jrnlEqnPara').length > 0){
          mathType = 'display';
      }
        var imageTex = $(eqNode).attr('data-tex');
        imageTex = imageTex.replace(/[\t\r\n]+/g, ' ');
        imageTex = imageTex.replace(/\s+/g, ' ');
        imageTex = imageTex.replace(/&/g, '|AMP|');
        imageTex = imageTex.replace(/\+/g, '|PLUS|');
        imageTex = imageTex.replace(/#/g, '|HASH|');
    
        var cmsID = document.getElementById('content').getAttribute('rowid');
        $.ajax({
            url: "/_exeter/phplatex/getImage.php?latex=" + imageTex + "&cmsID=" + cmsID,
            type:'POST',
            error: function (request, error) {
                console.log(error);
            },
            success: function(data){
                if(data.match(/^ERROR:/i)){
                    console.log(data);
                }else{
                    data = data.split('|');
                    $(eqNode).removeAttr('data-eqn-src').attr('src', data[0]).attr('width', data[1]);
                    if($('#content').find('.kriyaFormula').length != index+1){
                        convertEq(index+1);
                    }
                }
            }
        });
}
