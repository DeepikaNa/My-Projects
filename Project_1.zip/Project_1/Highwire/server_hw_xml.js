var express = require('express');
var bodyParser = require('body-parser');
var unirest = require('unirest');
var fs = require('fs');
var formidable = require('formidable');
var Q = require('q');
var moment = require('moment');

var app = express();

// parse application/json
app.use(bodyParser.json())

var resObj = {};

app.post("/getPubDate", function (req, res) {
    try{
        var form = new formidable({multiples: true});
        form.parse(req, function(err, field, files){
            if (err) {
                res.status(500).send("Unable to parse form data");
                return;
            }  
            for(var key in files){
                if(files[key].name == 'doi.txt'){
                    var fileConent = fs.readFileSync(files[key].path, "UTF-8");
                    if(fileConent && fileConent.split('\n').length > 0){
                        var dois = fileConent.split('\n');
                        getPubDate(req, res, dois, 0);
                    }else{
                        res.status(500).send("File content is empty");
                        return; 
                    }
                    break;
                }
            }
        });
    }catch(err){
        res.status(500).json(err);
        return;
    }
});

function getPubDate(req, res, dois, index){
    try{
        if(index < dois.length+5){
            var promiseArr = [];    
            for(var i=index;(i<(index+5) && i<dois.length);i++){
                promiseArr.push(getKriya2XML(dois[i]));
            }
            Q.allSettled(promiseArr).then(function(results){
                for(var i=0;(i<5 && (i+index)<dois.length);i++){
                    if (results && results[i] && results[i].state === "fulfilled" && results[i].value) {
                        var xml = results[i].value;
                        resObj[dois[i+index]] = {};
                        resObj[dois[i+index]]["xml"] = results[i].value;                        
                    } else {
                        resObj[dois[i+index]] = "Unable to get Highwire XML";
                    }
                }
                getPubDate(req, res, dois, index+5);
            })
        }else{
            fs.writeFileSync("./output.json", JSON.stringify(resObj));
                        res.status(200).json(resObj);
                        return;
        }
    }catch(err){
        res.status(500).send("Failed to get Kriya2 XML data");
        return;
    }
}

function getKriya2XML(doi) {
    return new Promise(function (resolve, reject) {        
        var project = doi.replace(/^([a-z]+)(.+)/i, "$1", doi).toLowerCase();
        //var url = "https://kriya2.kriyadocs.com/api/getdata?apiKey=cde4c89b-e452-4ba5-b493-01c691033b72&doi="+doi+"&project="+project+"&customer=bmj&xpath=//front";
        var url = "http://api.highwire.org/content?key=C02333C5-913A-46C4-A871-2A832D5EC514&doi=10.1136/"+doi+"";
        unirest.get(url)
            .end(function (response) {
                if (response.error) {
                    reject(response.error);
                } else {
                    resolve(response.body);
                }
            })
    })
}

app.listen(3000, function () {
    console.log("server is running on port: 3000");
})