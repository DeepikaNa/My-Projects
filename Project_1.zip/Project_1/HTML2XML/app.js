var xsltproc = require('xsltproc')
var format = require('xml-beautifier');
fs = require("fs")
http = require('http');

xsltproc.transform('front.xsl', 'testwe.html', {
  "profile": true,
  "output": "testie.xml",
  "stringparam": [
    {
      "key": 'title',
      "val": 'This is a single parameter passed as subtitle----anvidsahviulasdhvklasdbcuw'
    },
    {
      "key": 'anotherTitle',
      "val": 'This is a another single parameter passed'
    }
  ],
});
console.log("Completed Successfully!!");
http.createServer(function (req, res) {

}).listen(5555);
 
// var xslt = xsltproc.transform('front.xsl', 'testwe.html');
 
// xslt.stdout.on('data', function (data) {
//   console.log('xsltproc stdout: ' + data);
// });
 
// xslt.stderr.on('data', function (data) {
//   console.log('xsltproc stderr: ' + data);
// });
 
// xslt.on('exit', function (code) {
//   console.log('xsltproc process exited with code ' + code);
// });
// console.log("Completed Successfully!!");