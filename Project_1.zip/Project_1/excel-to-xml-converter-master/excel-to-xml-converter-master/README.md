# excel-to-xml-converter

#Step to run :

* Download this project.
* Navigate to the directory
* Run command "npm install"
* Run command "npm start"
* Open browser after build completed.
* type http://localhost:4200/
* Upload the given testExcel.xlsx file to view XML.
* After uploading your testExcel.xlsx file you can see the XML which is converted by excel file.
* Congratulatations.. Your app is working.. Now you can add more.
