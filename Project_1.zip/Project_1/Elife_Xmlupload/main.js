$(document).ready(function () {


var Loader = document.getElementById('preloader'); //Here you can change the VAR .
window.addEventListener('load', function(){
  $(Loader).css({'display': 'none'}) // If you change the VAR on the top then you need to change here too .
})


var trigger = $('.hamburger'),
  overlay = $('.overlay'),
 isClosed = false;
$('#process').on("click",function(){
  $('#bodyContent').html("");
  $('.loaderBox').show();
  jQuery.ajax({
    type: "GET",
    url:"process?path="+$("#example-search-input").val(),
    success: function (data) {
      if(data == "not found"){
        $('.loaderBox').hide();
      }else{
        $('.loaderBox').hide();
      }
    },
    error:function(err){
      $('.loaderBox').hide();
    }
  })
})
$('#UpdateXML').on("click",function(){
  $('.loaderBox').show();
  jQuery.ajax({
    type: "POST",
    data:{data:$('#bodyContent').text().replace(">\r\n<", "><"),path:$('#bodyContent').attr("pathtofile")},
    url:"updateXml",
    success: function (data) {
      if(data == "not found"){
        $('.loaderBox').hide();
      }else{
        $('.loaderBox').hide();
      }
    },
    error:function(err){
      $('.loaderBox').hide();
    }
  })
})
$('#FileDTDval').on("click",function(){
  $('.loaderBox').show();
  jQuery.ajax({
    type: "POST",
    data:{data:$('#bodyContent').text(),path:$('#bodyContent').attr("pathtofile")},
    url:"FileDTDval",
    success: function (data) {
      if(data == ""){
        $('.loaderBox').hide();
        var newWindow = window.open();
                newWindow.document.write('<html><head><head><body><pre>No DTD errors found.</pre></body></html>');
        $('.loaderBox').hide();
      }else{
        var newWindow = window.open();
                newWindow.document.write('<html><head><head><body><pre>'+data+'</pre></body></html>');
        $('.loaderBox').hide();
      }
    },
    error:function(err){
      $('.loaderBox').hide();
    }
  })
})
$('#validatePKG').on("click",function(){
  $('.loaderBox').show();
    jQuery.ajax({
      type: "GET",
      url:"validatePKG",
      success: function (data) {
        if(data == "not found"){
          $('.loaderBox').hide();
        }else{
                  $('#bodyContent').html(data);
          $('.loaderBox').hide();
        }
      },
      error:function(err){
        $('.loaderBox').hide();
      }
  })
})
$('#mapSupp').on("click",function(){
  $('.loaderBox').show();
    jQuery.ajax({
      type: "GET",
      url:"mapSupp",
      success: function (data) {
        if(data == "not found"){
          $('.loaderBox').hide();
        }else{
                  $('#bodyContent').append(data);
          $('.loaderBox').hide();
        }
      },
      error:function(err){
        $('.loaderBox').hide();
      }
  })
})

$('#checkSupp').on("click",function(){
  $('.loaderBox').show();
    jQuery.ajax({
      type: "GET",
      url:"checkSupp",
      success: function (data) {
        if(data == "not found"){
          $('.loaderBox').hide();
        }else{
                  $('#bodyContent').append(data);
          $('.loaderBox').hide();
        }
      },
      error:function(err){
        $('.loaderBox').hide();
      }
  })
})
$('#FilePMCval').on("click",function(){
  $('.loaderBox').show();
  jQuery.ajax({
    type: "POST",
    data:{data:$('#bodyContent').text(),path:$('#bodyContent').attr("pathtofile")},
    url:"FilePMCval",
    success: function (data) {
      if(data == ""){
        $('.loaderBox').hide();
        var newWindow = window.open();
                newWindow.document.write('<html><head><head><body><pre>No PMC errors found</pre></body></html>');
      }else{
        var newWindow = window.open();
                newWindow.document.write('<html><head><head><body><pre>'+data+'</pre></body></html>');
        $('.loaderBox').hide();
      }
    },
    error:function(err){
      $('.loaderBox').hide();
    }
  })
})
$('#copyZip').on("click",function(){
  jQuery.ajax({
    type: "POST",
    data:{path:$("#example-search-input").val(),matchCase:$("#matchCase").val()},
    url:"copyZipFiles",
    success: function (data) {
      $('.loaderBox').hide();
    },
    error:function(err){
      $('.loaderBox').hide();
    }
  })
})
$('#creatPKG').on("click",function(){
  $('.loaderBox').show();
  jQuery.ajax({
    type: "GET",
    url:"createPKG",
    success: function (data) {
      if(data == "Done"){
        $('.loaderBox').hide();
      }else{
        $('.loaderBox').hide();
      }
    },
    error:function(err){
      $('.loaderBox').hide();
    }
  })
})

$('#DTDval').on("click",function(){
  $('.loaderBox').show();
  jQuery.ajax({
    type: "GET",
    url:"DTDval",
    success: function (data) {
      if(data == "Done"){
        $('.loaderBox').hide();
      }else{
        $('.loaderBox').hide();
      }
    },
    error:function(err){
      $('.loaderBox').hide();
    }
  })
})

$('#PMCval').on("click",function(){
  $('.loaderBox').show();
  jQuery.ajax({
    type: "GET",
    url:"PMCval",
    success: function (data) {
      if(data == "Done"){
        $('.loaderBox').hide();
      }else{
        $('.loaderBox').hide();
      }
    },
    error:function(err){
      $('.loaderBox').hide();
    }
  })
})

$('#downloadLogData').on("click",function(){
  jQuery.ajax({
    type: "GET",
    url:"downloadLogData",
    success: function (response) {
      if(response && response.body && response.body){
          var zip = new JSZip();
          for(var fileData of response.body){
              zip.file(fileData.fileName, fileData.data.data);
          }
          zip.generateAsync({
              type: "base64"
          }).then(function(content) {
              var link = document.createElement('a');
              link.href = "data:application/zip;base64," + content;
              link.download = "download.zip";
              if(response.zipName){
                  link.download = response.zipName+".zip";
              }
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              
              $('pre#bodyContent').text($('pre#bodyContent').text()+"\nDownload completed!")

          })
          .catch(function(){
              alert("File download failed!")
          })
      }
    },
    error:function(err){
      alert("File download failed!")
    }
  })
});

trigger.click(function () {
  hamburger_cross();
});
$("body").on({click:function () {
  if($(this).find('.fa-folder').length > 0){
    $(this).find('.fa-folder').addClass('fa-folder-open').removeClass("fa-folder");

  }else if($(this).find('.fa-folder-open').length > 0){
    $(this).find('.fa-folder-open').addClass('fa-folder').removeClass("fa-folder-open");
  }
}},"a")
$("body").on({click:function () {
  var target = $(this);
  var path = $(target).attr('path')
  $('#bodyContent').removeAttr('contenteditable')
  if($(target).attr('path').match(".pdf")){
    $('.btn-group button').attr('disabled','true')
    $('#bodyContent').html('<embed type="application/pdf" src="'+$(target).attr('path').replace('/process','')+'" width="100%" height="87%" alt="pdf" pluginspage="http://www.adobe.com/products/acrobat/readstep2.html" background-color="0xFF525659" top-toolbar-height="56" full-frame="" internalinstanceid="40" title="CHROME">');
    return;
  }else if(path && !(path.match(".txt") || path.match(".html") || path.match(".xml")) && path.match(/\..{3}$/)){
    $('.btn-group button').attr('disabled','true')
    $('#bodyContent').html('<img class="img-responsive" src="'+$(target).attr('path').replace('/process','')+'" width="100%" height="100%">');
    return;
  }
  if($(target).find('.fa-folder').length > 0){
    $(this).closest('li').find('ul').remove();
  }else{
    jQuery.ajax({
      type: "GET",
      url:"getFiles?path="+$(target).attr('path'),
      success: function (data) {
      $(target).closest('li').find('ul').remove();
      if(data.list && data.list.length > 0){
        var list = '<ul class="dropdown-menu" role="menu" style="padding-left: 10px">'
        for(var i = 0; i < data.list.length; i++){
          if(data.list[i].match(/\.[a-zA-Z]{3}/)){
              list += '<li><a href="#" path="'+$(target).attr('path')+"/"+data.list[i]+'"><i class="fa fa-file" aria-hidden="true"></i> '+data.list[i]+'</a></li>'
            }else if(!data.list[i].match("public")){
              list += '<li><a href="#" path="'+$(target).attr('path')+"/"+data.list[i]+'"><i class="fa fa-folder" aria-hidden="true"></i> '+data.list[i]+'</a></li>'
            }
        }
        list += '</ul>'
      }else if(data.data){
        if(data.ext == "xml"){
          $('.btn-group button').removeAttr('disabled')
          $('#bodyContent').text(data.data.replace(/></g,'>\r\n<'))
          $('#bodyContent').attr('pathToFile',$(target).attr('path'))
        }else{
          $('.btn-group button').attr('disabled','true')
          $('#bodyContent').html(formatXml(data.data))
          $('#bodyContent').attr('pathToFile',$(target).attr('path'))
        }

      }
      $(target).closest('li').append(list);
      $(target).closest('li').attr('class','dropdown open');
      console.log(data)
          },
          error: function (err) {
      console.log(err)
          }
    });
  }
}},"[path]")

function hamburger_cross() {

  if (isClosed == true) {
    overlay.hide();
    trigger.removeClass('is-open');
    trigger.addClass('is-closed');
    $('#bodyContent').closest("div").attr("class","col-lg-11 col-lg-offset-1")
    $('#searchContainer').attr("class","col-md-11")
    isClosed = false;
  } else {
    overlay.show();
    trigger.removeClass('is-closed');
    trigger.addClass('is-open');
    $('#bodyContent').closest("div").attr("class","col-lg-10")
    $('#searchContainer').attr("class","col-md-9")
    isClosed = true;
  }
}

$('[data-toggle="offcanvas"]').click(function () {
    $('#wrapper').toggleClass('toggled');
});
});
function formatXml(xml) {
var formatted = '';
var reg = /(>)(<)(\/*)/g;
xml = xml.replace(reg, '$1\r\n$2$3');
var pad = 0;
jQuery.each(xml.split('\r\n'), function(index, node) {
  var indent = 0;
  if (node.match( /.+<\/\w[^>]*>$/ )) {
      indent = 0;
  } else if (node.match( /^<\/\w/ )) {
      if (pad != 0) {
          pad -= 1;
      }
  } else if (node.match( /^<\w[^>]*[^\/]>.*$/ )) {
      indent = 1;
  } else {
      indent = 0;
  }

  var padding = '';
  for (var i = 0; i < pad; i++) {
      padding += '  ';
  }

  formatted += padding + node + '\r\n';
  pad += indent;
});

return formatted;
}
