<?php 
ini_set('memory_limit', '-1');									//extend memory limit
ini_set('max_execution_time', 0);								//extend execution time
date_default_timezone_set("Asia/Kolkata");
?>

<html>
<head>
<meta charset="utf-8">
<meta content="IE=edge" http-equiv="X-UA-Compatible">
<meta content="width=device-width, initial-scale=1" name="viewport">
<meta content="" name="description">
<meta content="" name="Exeter">
<title>Exeter Premedia Services</title>
<link rel="stylesheet" href="sb-admin/css/bootstrap.min.css">
<link rel="stylesheet" href="sb-admin/css/sb-admin.css">
<script src="js/jquery-1.2.6.min.js" type="text/javascript"></script>
<style>
body {
background: white;
}
</style>
</head>
<body>
<div id="page-wrapper">
<div class="container-fluid">
<div class="row">
<div class="col-sm-6 col-lg-6 col-xs-6 col-md-6 col-sm-offset-3 col-lg-offset-3 col-xs-offset-3 col-md-offset-3">
<div class="panel panel-primary">
<div class="panel-heading">
<span>eLife Latex Cleanup Process</span>
</div>
<div class="panel-body">
<form action="LatexCleanup.php" method="post" accept-charset="utf-8" enctype="multipart/form-data">
<section id="uploader">
<div class="col-sm-6 col-lg-6 col-xs-6 col-md-6 col-sm-offset-3 col-lg-offset-3 col-xs-offset-3 col-md-offset-3" >
<div class="row">
<div class="form-group input-group">
<input id="fileupload" name="fileName" type="file" accept=".html" required/>
<p class="help-block" style="color:#F0AD4E">Upload input XML file here.</p>
</div>
</div>
<div class="col-sm-6 col-lg-6 col-xs-6 col-md-6 col-sm-offset-3 col-lg-offset-3 col-xs-offset-3 col-md-offset-3">
<button class="btn btn-success" type="submit" id="formSubmit">GET HTML FILE</button>
</div>
</div>
</section>
</form>
</div>
</div>
</div>
<div class="col-sm-1 col-lg-1 col-xs-1 col-md-1"></div>
</div>
<div id="loading" class="col-sm-offset-5 col-lg-offset-5 col-xs-offset-5 col-md-offset-5 hidden"><img src="includes/loading.gif" style="height:65px"/></div>
</div>
</div>
</body>
</html>
