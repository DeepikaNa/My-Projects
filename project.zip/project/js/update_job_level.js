 $(document).ready(function(){
	 
	 
	//load job id in drop down from database
	 $.ajax({
		url: 'includes/process_ajax_call.php',
		type: 'post',
		//async: false,
		data: {getJobIds: 'updateAssign'},
		success:function(response){
			if(response.match(/DATABASE ERROR/g)){
				$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data from database..!').attr('class','alert alert-danger');
			}else if(response == ''){
				$('#jobId option:first-child').attr("selected", "selected");
				$('#jobId').attr('disabled','disabled');
				$('#message').html('<b>ALERT</b><br/>Sorry, no job..!').attr('class','alert alert-danger');
				$('#jobidcomment').hide();
			}else {
				$('#jobId').append(response);
			}
		},
		error: function() {
			$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data from database..!').attr('class','alert alert-danger');
		}
	});//end of ajax call
	 			
	//restrict user to assign job till job not selected
	$('#level').attr('disabled','disabled');
	$('#noOfPage').attr('disabled','disabled');
	//$('#noOfWord').attr('disabled','disabled');
	$('#assignButton').attr('disabled','disabled');
	$('#rejectButton').attr('disabled','disabled');
	$('#jobId').change(function(){
		if($(this).val() == ''){
			window.location="update_job_level.php";
		}else {
			$('#jobidcomment').hide();
			$('#level').removeAttr('disabled');
			$('#noOfPage').removeAttr('disabled').val('');
			//$('#noOfWord').removeAttr('disabled').val('');
			$('#assignButton').removeAttr('disabled');
			$('#rejectButton').removeAttr('disabled');
			$('#level option:first-child').attr("selected", "selected");
			
			//ajax call on change job set job detail to fields
			$.ajax({
				url: 'includes/process_ajax_call.php',
				type: 'post',
				async: false,
				//dataType:'json',
				data: {jobId: $(this).val()},
				success:function(response){
					if(response.match(/DATABASE ERROR/g)){
						$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data for the selected job from database..!').attr('class','alert alert-danger');
					}else {
						var jobDetail = response.split('|');
						$('#jobName').val(jobDetail[0]);
						$('#startDate').val(jobDetail[1]);
						$('#dueDate').val(jobDetail[2]);
						$('#level option[value="Simple"]').attr('selected','selected');
						$('#noOfPage').val(parseInt(jobDetail[4]));
					}
				},
				error: function() {
					$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data for the selected job from database..!').attr('class','alert alert-danger');
					$('#jobName').val('Error');
					$('#startDate').val('Error');
					$('#dueDate').val('Error');
					$('#level').attr('disabled','disabled');
		 			$('#noOfPage').attr('disabled','disabled').val('');
		 			//$('#noOfWord').attr('disabled','disabled').val('');
		 			$('#assignButton').attr('disabled','disabled');
		 			$('#rejectButton').attr('disabled','disabled');
		 			$('#level option:first-child').attr("selected", "selected");
				}
		    });//end of ajax call
		}
	});
	
	//validate page number count
	$("#noOfPage").keypress(function (e) {
		 //if the letter is not digit then display error and don't type anything
		 if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
		     return false;
		 }
	});
	/*$("#noOfWord").keypress(function (e) {
		 //if the letter is not digit then display error and don't type anything
		 if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
		     return false;
		 }
	});*/
	
	//validation on assign button 
	$('#assignButton').click(function(event){
		if($('#level').val() == ''){
			$('#message').html('<b>ALERT</b><br/>Please select LEVEL of job.').attr('class','alert alert-danger');
			event.preventDefault();
		}else if($('#noOfPage').val() == ''){
			$('#message').html('<b>ALERT</b><br/>Please enter No. OF PAGES.').attr('class','alert alert-danger');
			event.preventDefault();
		}
		/*
		else if($('#noOfWord').val() == ''){
			$('#message').html('<b>ALERT</b><br/>Please enter No. OF WORDS.').attr('class','alert alert-danger');
			event.preventDefault();
		}
		*/
	});
	
	//reject a job
	$('#rejectButton').click(function(event){
		//load job id in drop down from database
		 $.ajax({
			url: 'includes/process_ajax_call.php',
			type: 'post',
			//async: false,
			data: {jobReject: $('#jobId').val()},
			success:function(response){
				if(response == 'done'){
					window.location="update_job_level.php?rejectSuccess=''";
				}else {
					$('#message').html('<b>ERROR</b><br/>Sorry, cannot reject the selected job..!').attr('class','alert alert-danger');
				}
			},
			error: function() {
				$('#message').html('<b>ERROR</b><br/>Sorry, cannot reject the selected job..!').attr('class','alert alert-danger');
			}
		});//end of ajax call
	});
	
	//onclick nav-bar tracking
	$('#tracking').click(function(){
		$('#tracking').addClass('open');
	});
	
});