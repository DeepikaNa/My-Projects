$(document).ready(function() {
	$('#selectVendor').hide();
	$('#buttons').hide();
	//onclick nav-bar tracking
	$('#tracking').click(function(){
		$('#tracking').addClass('open');
	});
	
	//load job id in drop down from database
	 $.ajax({
		url: 'includes/process_ajax_call.php',
		type: 'post',
		//async: false,
		data: {getJobIds: 'assigned'},
		success:function(response){
			if(response.match(/DATABASE ERROR/g)){
				$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data from database..!').attr('class','alert alert-danger');
			}else if(response == ''){
				$('#jobId option:first-child').attr("selected", "selected");
				$('#jobId').attr('disabled','disabled');
				$('#message').html('<b>ALERT</b><br/>Sorry, no job..!').attr('class','alert alert-danger');
				$('#jobidcomment').hide();
			}else {
				$('#jobId').append(response);
			}
		},
		error: function() {
			$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data from database..!').attr('class','alert alert-danger');
		}
	});//end of ajax call
	 
	//load vendors in drop down from database
	 $.ajax({
		url: 'includes/process_ajax_call.php',
		type: 'post',
		//async: false,
		data: {getVendors: ''},
		success:function(response){
			if(response.match(/DATABASE ERROR/g)){
				$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data from database..!').attr('class','alert alert-danger');
			}else if(response == ''){
				$('#vendorName option:first-child').attr("selected", "selected");
				$('#vendorName').attr('disabled','disabled');
				$('#message').html('<b>ALERT</b><br/>Sorry, no job..!').attr('class','alert alert-danger');
				$('#vendorComment').hide();
			}else {
				$('#vendorName').append(response);
			}
		},
		error: function() {
			$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data from database..!').attr('class','alert alert-danger');
		}
	});//end of ajax call
	 
	 $('#jobId').change(function(){
			if($(this).val() == ''){
				window.location="manual_assign_job.php";
			}else {
				$('#jobidcomment').hide();
				$('#selectVendor').show();
				
				//ajax call on change job set job detail to fields
				$.ajax({
					url: 'includes/process_ajax_call.php',
					type: 'post',
					async: false,
					//dataType:'json',
					data: {jobId: $(this).val()},
					success:function(response){
						if(response.match(/DATABASE ERROR/g)){
							$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data for the selected job from database..!').attr('class','alert alert-danger');
						}else {
							var jobDetail = response.split('|');
							$('#jobName').val(jobDetail[0]);
							$('#startDate').val(jobDetail[1]);
							$('#dueDate').val(jobDetail[2]);
							$('#level').val(jobDetail[3]);
							$('#noOfPage').val(jobDetail[4]);
							//$('#noOfWord').val(jobDetail[5]);
						}
					},
					error: function() {
						$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data for the selected job from database..!').attr('class','alert alert-danger');
						$('#jobName').val('Error');
						$('#startDate').val('Error');
						$('#dueDate').val('Error');
						$('#level').attr('disabled','disabled');
			 			$('#noOfPage').attr('disabled','disabled').val('');
			 			//$('#noOfWord').attr('disabled','disabled').val('');
					}
			    });//end of ajax call
			}
			$('#selectVendor option:first-child').attr('selected', 'selected');
			$('#currentPage').val('');
			$('#buttons').hide();
		});
	 
	 $('#vendorName').change(function(){
			if($(this).val() == ''){
				$('#buttons').hide();
				$('#vendorComment').show();
				$('#currentPage').val('');
			}else {
				//ajax call on change job set job detail to fields
				$.ajax({
					url: 'includes/process_ajax_call.php',
					type: 'post',
					async: false,
					//dataType:'json',
					data: {getVendor: $(this).val()},
					success:function(response){
						if(response.match(/DATABASE ERROR/g)){
							$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data for the selected job from database..!').attr('class','alert alert-danger');
						}else {
							var vendorDetail = response.split('|');
							$('#currentPage').val(vendorDetail[0]);
							$('#vendorInternalID').val(vendorDetail[3]);
							$('#vendorMail').val(vendorDetail[4]);
							$('#buttons').show();
							$('#vendorComment').hide();
						}
					},
					error: function() {
						$('#message').html('<b>ERROR</b><br/>Sorry, cannot fetch data for the selected job from database..!').attr('class','alert alert-danger');
			 			$('#noOfPage').val('Error');
			 		//	$('#noOfWord').val('Error');
					}
			    });//end of ajax call
			}
		});
	 
	 	//reset the fields
		$('#resetButton').click(function(event){
			window.location="manual_assign_job.php";
		});
});
		