<?php
ini_set('max_execution_time', -1);
ini_set('memory_limit', '-1');
ini_set ('display_errors', 0);
error_reporting(E_ALL & ~E_NOTICE);
date_default_timezone_set('Asia/Kolkata');
require_once 'JSLikeHTMLElement.php';

$message           =''; 
$errormessage	=	'';
$noofchapter	=	'';
$noerror        =   false;
$latexHtml = $_FILES['fileName']['tmp_name'];

function outputPostProcess($latexHtml){	
	
	$processHTML    =   file_get_contents($latexHtml);
	$processHTML    =   preg_replace('/<head[^>]*>([\s\S]*?)<\/head>/','',$processHTML);
	$processHTML    =   preg_replace('/<img[^>]*>/','',$processHTML);
	$processHTML    =   preg_replace('/<br[^>]*>/','',$processHTML);
	$processHTML    =   preg_replace('/<hr[^>]*>/','',$processHTML);
	$processHTML    =   preg_replace('/<span>/','',$processHTML);
	$processHTML    =   preg_replace('/<span class="ltx_tag ltx_role_autoref ltx_tag_section">([^>]*)<\/span>/','',$processHTML);
	$processHTML    =   preg_replace('/<span class="ltx_tag ltx_role_refnum ltx_tag_section">([^>]*)<\/span>/','',$processHTML);
	$processHTML    =   preg_replace('/<span class="ltx_tag ltx_role_typerefnum ltx_tag_section">([^>]*)<\/span>/','',$processHTML);
	$processHTML    =   preg_replace('/<span class="ltx_tag ltx_tag_section">([^>]*)<\/span>/','',$processHTML);
	$processHTML    =   preg_replace('/<span class="ltx_tag ltx_tag_subsection">([^>]*)<\/span>/','',$processHTML);
	$processHTML    =   preg_replace('/<span class="ltx_tag ltx_role_autoref ltx_tag_subsection">([^>]*)<\/span>/','',$processHTML);
	$processHTML    =   preg_replace('/<span class="ltx_tag ltx_role_refnum ltx_tag_subsection">([^>]*)<\/span>/','',$processHTML);
	$processHTML    =   preg_replace('/<span class="ltx_tag ltx_role_typerefnum ltx_tag_subsection">([^>]*)<\/span>/','',$processHTML);
	$latexLog ="----------------------------\n";
	#$latexLog .= "Running this script to change Math lowercase greek character to plain text\n";
	$table = '<table><thead><th style="border-style: ridge;">Time</th><th style="border-style: ridge;">Description</th><th style="border-style: ridge;">Count</th></thead></tbody>';
	#Running this script to change Math lowercase greek character to plain text
	$reg1 = false;
	$reg1Count = preg_match_all('/<math([^>]*)><mi>\&(gamma|mu|delta|alpha|beta|nu|omega|phi|pi|epsilon|eta|iota|kappa|lambda|psi|rho|sigma|tau|theta|upsilon|xi|zeta|digamma|varepsilon|varkappa|varphi|varpi|varrho|varsigma|vartheta|Dela|Gamma|Lambda|Pi|Psi|Sigma|Theta|Upsilon|Xi|aleph|beth|daleth|gimel)\;<\/mi><\/math>/',$processHTML);
	if($reg1Count > 0){
		$reg1 = true;
		$latexLog .=date(DATE_RFC822)." lowercase greek single character in to text (".$reg1Count.")\n"; # Log created with date and timestamp along with replacement occurence.
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">lowercase greek single character in to text</td><td style="border-style: ridge;">'.$reg1Count.'</td></tr>';

	}else{
		$latexLog .=date(DATE_RFC822)." lowercase greek single character not found (".$reg1Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">lowercase greek single character not found</td><td style="border-style: ridge;">'.$reg1Count.'</td></tr>';
	}
	
	$processHTML    =   preg_replace('/<math([^>]*)><mi>\&(gamma|mu|delta|alpha|beta|nu|omega|phi|pi|epsilon|eta|iota|kappa|lambda|psi|rho|sigma|tau|theta|upsilon|xi|zeta|digamma|varepsilon|varkappa|varphi|varpi|varrho|varsigma|vartheta|Dela|Gamma|Lambda|Pi|Psi|Sigma|Theta|Upsilon|Xi|aleph|beth|daleth|gimel)\;<\/mi><\/math>/','&$2;',$processHTML);
	
	if($reg1 && !preg_match('/<math([^>]*)><mi>\&(gamma|mu|delta|alpha|beta|nu|omega|phi|pi|epsilon|eta|iota|kappa|lambda|psi|rho|sigma|tau|theta|upsilon|xi|zeta|digamma|varepsilon|varkappa|varphi|varpi|varrho|varsigma|vartheta|Dela|Gamma|Lambda|Pi|Psi|Sigma|Theta|Upsilon|Xi|aleph|beth|daleth|gimel)\;<\/mi><\/math>/',$processHTML)){
		$latexLog .=date(DATE_RFC822)." lowercase greek single character run successfully\n";
	}
	#Running this script to change all math signle characters to change plain text
	#$latexLog .= "Running this script to change all math signle characters to change plain text\n";
	$reg2 = false;
	$reg2Count = preg_match_all('/<math([^>]*)><mi>([a-z,A-Z]+)<\/mi><\/math>/',$processHTML);
	if($reg2Count > 0){
		$reg2 = true;
		$latexLog .=date(DATE_RFC822)." All character in to text are found (".$reg2Count.")\n"; # Log created with time and datestamp along with replacement occurence.
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All character in to text</td><td style="border-style: ridge;">'.$reg2Count.'</td></tr>';
	}else{
		$latexLog .=date(DATE_RFC822)." All character in to text not found (".$reg2Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All character in to text not found</td><td style="border-style: ridge;">'.$reg2Count.'</td></tr>';
	}
	$processHTML    =   preg_replace('/<math([^>]*)><mi>([a-z,A-Z]+)<\/mi><\/math>/','<i>$2</i>',$processHTML);
	
	if($reg2 && !preg_match('/<math([^>]*)><mi>([a-z,A-Z]+)<\/mi><\/math>/',$processHTML)){
		$latexLog .=date(DATE_RFC822)."All character in to text run successfully\n";
	}
	#Running this script to change all math numbers to change plain text
	#$latexLog .= "Running this script to change all math numbers to change plain text\n";
	$reg3 = false;
	$reg3Count = preg_match_all('/<math([^>]*)><mo>([0-9]+)<\/mo><\/math>/',$processHTML);
		if($reg3Count > 0){
		$reg3 = true;
		$latexLog .=date(DATE_RFC822)." All number in to text are found (".$reg3Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All number in to text</td><td style="border-style: ridge;">'.$reg3Count.'</td></tr>';
     }else{
		$latexLog .=date(DATE_RFC822)." All number in to text not found (".$reg3Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All number in to text not found</td><td style="border-style: ridge;">'.$reg3Count.'</td></tr>';
	 }
	$processHTML    =   preg_replace('/<math([^>]*)><mo>([0-9]+)<\/mo><\/math>/','<i>$2</i>',$processHTML);
	if($reg3 && !preg_match('/<math([^>]*)><mo>([0-9]+)<\/mo><\/math>/',$processHTML)){
		$latexLog .=date(DATE_RFC822)." All number in to text run successfully\n";
	}
	#Running this script to change all math subscript characters to plain subscript text
	#$latexLog .= "Running this script to change all math subscript characters to plain subscript text\n";
	$reg4 = false;
	$reg4Count = preg_match_all('/<math([^>]*)><msub><mi>([a-z,A-Z]+)<\/mi><mn>([0-9]+)<\/mn><\/msub><\/math>/',$processHTML);
	if($reg4Count > 0){
		$reg4 = true;
		$latexLog .=date(DATE_RFC822). " All Subscript character number changed  (".$reg4Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All Subscript character number changed </td><td style="border-style: ridge;">'.$reg4Count.'</td></tr>';
     }else{
		$latexLog .=date(DATE_RFC822). " All Subscript character number not found (".$reg4Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All Subscript character number not found</td><td style="border-style: ridge;">'.$reg4Count.'</td></tr>';
	 }
	$processHTML    =   preg_replace('/<math([^>]*)><msub><mi>([a-z,A-Z]+)<\/mi><mn>([0-9]+)<\/mn><\/msub><\/math>/','<i>$2</i><sub>$3</sub>',$processHTML);
     if($reg4 && !preg_match('/<math([^>]*)><msub><mi>([a-z,A-Z]+)<\/mi><mn>([0-9]+)<\/mn><\/msub><\/math>/',$processHTML)){
		$latexLog .=date(DATE_RFC822)." All Subscript character run successfully\n";
	  }
	#Running this script to change all number into text
	$reg5 = false;
	$reg5Count    =   preg_match_all('/<math([^>]*)><mo>\&([a-z,A-Z]+);<\/mo><\/math>/',$processHTML);
	if($reg5Count > 0){
		$reg5 = true;
		$latexLog .=date(DATE_RFC822)." All number into text run successfully (".$reg5Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All number into text run successfully</td><td style="border-style: ridge;">'.$reg5Count.'</td></tr>';
	}else{
		$latexLog .=date(DATE_RFC822). " All number into text not found (".$reg5Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All number into text not found</td><td style="border-style: ridge;">'.$reg5Count.'</td></tr>';
	}
		
	$processHTML    =   preg_replace('/<math([^>]*)><mo>\&([a-z]+);<\/mo><\/math>/','&$2;',$processHTML);
     if($reg5 && !preg_match('/<math([^>]*)><mo>\&([a-z]+);<\/mo><\/math>/',$processHTML)){
		$latexLog .=date(DATE_RFC822)." All number into text run successfully\n";
	 }
	 
	#Running this script to change all Math Lowergreek number in to Normal text 
	$reg6 = false;
	$reg6Count    =   preg_match_all('/<math([^>]*)><mrow><mi><\/mi><mo>\&([a-z]+);<\/mo><mn>([0-9,\.]+)<\/mn><\/mrow><\/math>/',$processHTML);
	if($reg6Count > 0){
		$reg6 = true;
		$latexLog .=date(DATE_RFC822)." All any Entity Followed by number in to Normal text are found(".$reg6Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All any Entity Followed by number in to Normal text run successfully</td><td style="border-style: ridge;">'.$reg5Count.'</td></tr>';
	}else{
		$latexLog .=date(DATE_RFC822). " All any Entity Followed by number in to Normal text  not found (".$reg6Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All any Entity Followed by number in to Normal text  not found</td><td style="border-style: ridge;">'.$reg6Count.'</td></tr>';
	}
	$processHTML    =  preg_replace('/<math([^>]*)><mrow><mi><\/mi><mo>\&([a-z]+);<\/mo><mn>([0-9,\.]+)<\/mn><\/mrow><\/math>/','<i>$2</i><sub>$3</sub>',$processHTML);
     if($reg6 && !preg_match('/<math([^>]*)><mrow><mi><\/mi><mo>\&([a-z]+);<\/mo><mn>([0-9,\.]+)<\/mn><\/mrow><\/math>/',$processHTML)){
		$latexLog .=date(DATE_RFC822)." All Math Lowergreek number in to Normal text run successfully\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All Math Lowergreek number in to Normal text run successfully</td><td style="border-style: ridge;">'.$reg6Count.'</td></tr>';
	 }
			
	#Running this script to change all Math subscript text  in to subscript normal text
	$reg7 = false;
	$reg7Count    =   preg_match_all('/<math([^>]*)><msub><mi>([a-z]+)<\/mi><mi>([a-z]+)<\/mi><\/msub><\/math>/',$processHTML);
	if($reg7Count > 0){
		$reg7 = true;
		$latexLog .=date(DATE_RFC822)." All Single variable with subscript changed  in to text format are found(".$reg7Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All Single variable with subscript changed  in to text format are found</td><td style="border-style: ridge;">'.$reg7Count.'</td></tr>';
	}else{
		$latexLog .=date(DATE_RFC822). " All Single variable with subscript changed  in to text format  not found (".$reg7Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All Single variable with subscript changed  in to text format  not found</td><td style="border-style: ridge;">'.$reg7Count.'</td></tr>';
	}
	$processHTML    =  preg_replace('/<math([^>]*)><msub><mi>([a-z]+)<\/mi><mi>([a-z]+)<\/mi><\/msub><\/math>/','<i>$2</i><sub><i>$3</i></sub>',$processHTML);
     if($reg7 && !preg_match('/<math([^>]*)><msub><mi>([a-z]+)<\/mi><mi>([a-z]+)<\/mi><\/msub><\/math>/',$processHTML)){
		$latexLog .=date(DATE_RFC822)." All Single variable with subscript changed in to text format run successfully\n";
	 }
	
	#Running this script to change all Math Lowergreek text in to normal text 
	$reg8 = false;
	$reg8Count    =   preg_match_all('/<math([^>]*)><mrow><mi>\&([a-z]+);<\/mi><mo>&#8290;<\/mo><mi>([a-z]+)<\/mi><\/mrow><\/math>/',$processHTML);
	if($reg8Count > 0){
		$reg8 = true;
		$latexLog .=date(DATE_RFC822)." All Math Lowergreek text in to normal text are found(".$reg8Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All Math Lowergreek text in to normal text run successfully</td><td style="border-style: ridge;">'.$reg8Count.'</td></tr>';
	}else{
		$latexLog .=date(DATE_RFC822). " All Math Lowergreek text in to normal text  not found (".$reg8Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">All Math Lowergreek text in to normal text  not found</td><td style="border-style: ridge;">'.$reg8Count.'</td></tr>';
	}
	$processHTML    =  preg_replace('/<math([^>]*)><mrow><mi>\&([a-z]+);<\/mi><mo>&#8290;<\/mo><mi>([a-z]+)<\/mi><\/mrow><\/math>/','&$2;<i>$3</i>',$processHTML);
     if($reg8 && !preg_match('/<math([^>]*)><mrow><mi>\&([a-z]+);<\/mi><mo>&#8290;<\/mo><mi>([a-z]+)<\/mi><\/mrow><\/math>/',$processHTML)){
		$latexLog .=date(DATE_RFC822)." All Math Lowergreek number in to Normal text run successfully\n";
	 }
	 
	#Running this script to change digits into subscript
	$reg11 = false;
	$reg11Count    =   preg_match_all('/<math([^>]*)><msub><mi><\/mi><mn>([0-9]+)<\/mn><\/msub><\/math>/',$processHTML);
	if($reg11Count > 0){
		$reg11 = true;
		$latexLog .=date(DATE_RFC822)."  Change subscript Number in to text format are found(".$reg11Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">Change subscript Number in to text format run successfully</td><td style="border-style: ridge;">'.$reg11Count.'</td></tr>';
	}else{
		$latexLog .=date(DATE_RFC822). " Change subscript Number in to text format not found (".$reg11Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">Change subscript Number in to text format not found</td><td style="border-style: ridge;">'.$reg11Count.'</td></tr>';
	}
	$processHTML    =  preg_replace('/<math([^>]*)><msub><mi><\/mi><mn>([0-9]+)<\/mn><\/msub><\/math>/','<sub>$2</sub>',$processHTML);
     if($reg11 && !preg_match('/<math([^>]*)><msub><mi><\/mi><mn>([0-9]+)<\/mn><\/msub><\/math>',$processHTML)){
		$latexLog .=date(DATE_RFC822)." Change subscript Number in to text format run successfully\n";
	 }
	
	#Running this script to change digits into superscript
	$reg12 = false;
	$reg12Count    =   preg_match_all('/<math([^>]*)><msup><mi><\/mi><mn>([0-9]+)<\/mn><\/msup><\/math>/',$processHTML);
	if($reg12Count > 0){
		$reg12 = true;
		$latexLog .=date(DATE_RFC822)."  Change superscript Number in to text format are found(".$reg12Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">Change superscript Number in to text format run successfully</td><td style="border-style: ridge;">'.$reg12Count.'</td></tr>';
	}else{
		$latexLog .=date(DATE_RFC822). " Change superscript Number in to text format not found (".$reg12Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">Change superscript Number in to text format not found</td><td style="border-style: ridge;">'.$reg12Count.'</td></tr>';
	}
	$processHTML    =  preg_replace('/<math([^>]*)><msup><mi><\/mi><mn>([0-9]+)<\/mn><\/msup><\/math>/','<sup>$2</sup>',$processHTML);
     if($reg12 && !preg_match('/<math([^>]*)><msup><mi><\/mi><mn>([0-9]+)<\/mn><\/msup><\/math>',$processHTML)){
		$latexLog .=date(DATE_RFC822)." Change superscript Number in to text format run successfully\n";
	 }
	 
	 #Running this script to change theta's  into subscript tag
	$reg13 = false;
	$reg13Count    =   preg_match_all('/<math([^>]*)><msub><mtext>([a-z,A-Z]+)<\/mtext><mi>(max|min|log|cos|tan)<\/mi><\/msub><\/math>/',$processHTML);
	if($reg13Count > 0){
		$reg13 = true;
		$latexLog .=date(DATE_RFC822)."  Change the single math functions in to text format are found(".$reg13Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">Change the single math functions in to text format run successfully</td><td style="border-style: ridge;">'.$reg13Count.'</td></tr>';
	}else{
		$latexLog .=date(DATE_RFC822). " Change the single math functions in to text format not found (".$reg13Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">Change the single math functions in to text format not found</td><td style="border-style: ridge;">'.$reg13Count.'</td></tr>';
	}
	$processHTML    =  preg_replace('/<math([^>]*)><msub><mtext>([a-z,A-Z]+)<\/mtext><mi>(max|min|log|cos|tan)<\/mi><\/msub><\/math>/','$2<sub>$3</sub>',$processHTML);
     if($reg13 && !preg_match('/<math([^>]*)><msub><mtext>([a-z,A-Z]+)<\/mtext><mi>(max|min|log|cos|tan)<\/mi><\/msub><\/math>',$processHTML)){
		$latexLog .=date(DATE_RFC822)." Change the single math functions in to text format run successfully\n";
	 }
	 
	 #Running this script to change text into subscript tag
	$reg14 = false;
	$reg14Count    =   preg_match_all('/<math([^>]*)><msub><mtext>([a-z,A-Z]+)<\/mtext><mn>([0-9]+)<\/mn><\/msub><\/math>/',$processHTML);
	if($reg14Count > 0){
		$reg14 = true;
		$latexLog .=date(DATE_RFC822)."  Simple text with subscript changed in to text format are found(".$reg14Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">Simple text with subscript changed in to text format are found</td><td style="border-style: ridge;">'.$reg14Count.'</td></tr>';
	}else{
		$latexLog .=date(DATE_RFC822). " Simple text with subscript changed in to text format not found (".$reg14Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">Simple text with subscript changed in to text format not found</td><td style="border-style: ridge;">'.$reg14Count.'</td></tr>';
	}
	$processHTML    =  preg_replace('/<math([^>]*)><msub><mtext>([a-z,A-Z]+)<\/mtext><mn>([0-9]+)<\/mn><\/msub><\/math>/','$2<sub>$3</sub>',$processHTML);
     if($reg14 && !preg_match('/<math([^>]*)><msub><mtext>([a-z,A-Z]+)<\/mtext><mn>([0-9]+)<\/mn><\/msub><\/math>/',$processHTML)){
		$latexLog .=date(DATE_RFC822)." Simple text with subscript changed in to text format run successfully\n";
	 }
	 #Running this script to change text into superscript tag
	$reg15 = false;
	$reg15Count    =   preg_match_all('/<math([^>]*)><msup><mtext>([a-z,A-Z]+)<\/mtext><mn>([0-9]+)<\/mn><\/msup><\/math>/',$processHTML);
	if($reg15Count > 0){
		$reg15 = true;
		$latexLog .=date(DATE_RFC822)."  To change text into superscript tag are found(".$reg15Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">To change text into superscript tag run successfully</td><td style="border-style: ridge;">'.$reg15Count.'</td></tr>';
	}else{
		$latexLog .=date(DATE_RFC822). " To change text into superscript tag not found (".$reg15Count.")\n";
		$table.= '<tr><td style="border-style: ridge;">'.date(DATE_RFC822).'</td><td style="border-style: ridge;">To change text into superscript tag not found</td><td style="border-style: ridge;">'.$reg15Count.'</td></tr>';
	}
	$processHTML    =  preg_replace('/<math([^>]*)><msup><mtext>([a-z,A-Z]+)<\/mtext><mn>([0-9]+)<\/mn><\/msup><\/math>/','$2<sup>$3</sup>',$processHTML);
     if($reg15 && !preg_match('/<math([^>]*)><msup><mtext>([a-z,A-Z]+)<\/mtext><mn>([0-9]+)<\/mn><\/msup><\/math>/',$processHTML)){
		$latexLog .=date(DATE_RFC822)." To change text into subscript tag run successfully\n";
	}
	# Created the log for Non- ASCII Characters in a file
	$asciiCharacters = "";
	if(preg_match_all('/[^[:ascii:]]+/', $processHTML, $matches)){
		$filtered_array = array_filter($matches);
		foreach($filtered_array[0] as $match){
			$asciiCharacters .=date(DATE_RFC822)."  acsii char: ".$match."\n"; # Log created
		}
	}
	$table .= '</tbody></table>';
	echo $table;

	//Remove the tex error tag
	$processHTML    = preg_replace('/<span[^>]*class=\"ltx_ERROR([\s\S]*?)">([\s\S]*?)<\/span>/','',$processHTML);
		
	$processHTML  = mb_convert_encoding($processHTML, 'HTML-ENTITIES', 'UTF-8');
	
	//file_put_contents($htmlFile,$processHTML);
	
	$doc = new DOMDocument('1.0', 'utf-8');
	$doc->registerNodeClass('DOMElement', 'JSLikeHTMLElement');
	$doc->loadHTML($processHTML);
	$xpath = new DOMXPath($doc);
	$xpath->registerNamespace('php', 'http://php.net/xpath');
	$xpath->registerPhpFunctions(array('preg_match', 'preg_split', 'preg_replace', 'sizeof', 'str_word_count'));	
	$mathNodes = $xpath->query('//math');
	$miNodes = $xpath->query('//mi');
	$EqTableNodes = $xpath->query('//table[@class="ltx_equationgroup ltx_eqn_eqnarray"]|//table[@class="ltx_equationgroup ltx_eqn_align"]|//table[@class="ltx_equation"]|//table[@class="ltx_equationgroup"]');
	
	$mathColorNodes  = $xpath->query('//*[@mathcolor]');
	$logString = '';
	
	# Changing the attribute for the table based on classname
	$absTitles = $xpath->query('//*[@class="ltx_equationgroup ltx_eqn_eqnarray ltx_eqn_table"]//*[@display="inline"]');
    foreach ($absTitles as $absTitle){
    	$absTitle->setAttribute('display','block');
    }
	# removing table tag based on classname, tagged as normal p 
	$tables = $xpath->query('//table[@class="ltx_equation ltx_eqn_table" or @class="ltx_equationgroup ltx_eqn_eqnarray ltx_eqn_table"]');
    foreach ($tables as $table){
		$childNodes = $xpath->query('//tr|//th|//td', $table);
		foreach($childNodes as $childNode){
			DOMRemove($childNode);
		}
		$tableId = $table->getAttribute('id');
		$newNode = renameNode($table, 'p', null, true);
		$newNode->setAttribute('class','ltx_p');
		if($tableId){
			$newNode->setAttribute('id',preg_replace("/^(\w+\d+\.)(\w+\d+)$/", "$2", $tableId)); # id updated based on dot operator
		}
    }
	
	if($mathColorNodes->length > 0){
		$logString .= 'Cleaning up the math color.......... ';
		foreach($mathColorNodes as $mathColor){
			$mathColor->removeAttribute('mathcolor');
		}	
	}else{
		$logString .= 'math color node not found.......... ';
	}
	
	
	/*$logString .= 'Cleanup reference number in reference........ ';
	foreach($refRoleNum as $refNum){
		$refNum->parentNode->removeChild($refNum);
	}*/
	$logString .= 'Cleanup the comment in the alttext attribute........ ';
	//remove the % symbol in the alttext attribute and add the begin align in front of the split
	foreach($mathNodes as $math){
		$texEq = $math->getAttribute('alttext');
		if(preg_match('/((?!\\\\).)\%/',$texEq)){
			$texEq = preg_replace('/((?!\\\\).)\%/','$1 ',$texEq);
			$math->setAttribute('alttext',$texEq);
		}
		if(preg_match('/\\\begin\{split\}/',$texEq)){
			$texEq = '\begin{align}'.$texEq.'\notag\end{align}';
			$math->setAttribute('alttext',$texEq);
		}
	}
	$logString .= 'Styling the mathvariant to the mi node.......... \n';
	//add mathvariant attribute to mi tag
	foreach($miNodes as $mi){
		$nodeText = $mi->nodeValue;
		if(preg_match('/[\x{1D400}-\x{1D433} \x{1D6A8}-\x{1D6E1} \x{1D7CA}-\x{1D7D7}]+/u',$nodeText)){
			$mi->setAttribute('mathvariant','bold');
		}elseif(preg_match('/[\x{1D468}-\x{1D49B} \x{1D71C}-\x{1D755}]+/u',$nodeText)){
			$mi->setAttribute('mathvariant','bold-italic');
		}elseif(preg_match('/[\x{1D4D0}-\x{1D503}]+/u',$nodeText)){
			$mi->setAttribute('mathvariant','bold-script');
		}elseif(preg_match('/[\x{1D56C}-\x{1D59F}]+/u',$nodeText)){
			$mi->setAttribute('mathvariant','bold-fraktur');
		}
		//remove strechy attribute in mi
		if($mi->hasAttribute ('stretchy')){
			$mi->removeAttribute('stretchy');
		}
	}
	
    $logString .= 'Joining the mathml & tex and Removing the table which contain only the equation...... \n';
	//combine the equation which comes in table
	
	foreach ($EqTableNodes as $table){
		$trNode = $xpath->query('.//tr',$table);
		$tableMathNode =$xpath->query('.//math',$table);
		if(preg_match('/<math[^>]*>([\s\S]*?)<\/math>/', $trNode->item(0)->innerHTML) && $tableMathNode ->length > 1){
			$firstRowCol = $xpath->query('.//td',$trNode->item(0));
			$texAlign = '';
			$mathAlign = '';
			$tex = '';
			$trMathml = '';
			$rootTableNode = '';
			foreach($trNode as $trKey=>$tr){
				$labelString = '';
				$tdNode = $xpath->query('.//th|.//td',$tr); 
				foreach($tdNode as $tdKey=>$td){
					$tdHTML = $td->innerHTML;
					$tdHTML = preg_replace('/([\n|\r|\t])/','',$tdHTML);
					if(!preg_match('/^((\s+)?[\(\)a-zA-Z0-9]+)/',$tdHTML)){
						$tdMath = $xpath->query('.//math',$td);
						//join the tex
						foreach($tdMath as $math){
							$tex .= $math->getAttribute('alttext');
						}
						if(preg_match('/<math[^>]*>/',$tdHTML)){
							$tdHTML = preg_replace('/<math[^>]*>/', '', $tdHTML);
							$tdHTML = preg_replace('/<\/math[^>]*>/', '', $tdHTML);
							$tex .= '&';
						}
						$td->innerHTML = $tdHTML;
						$eqNum =  $xpath->query('.//span',$td)->item(0);
						//replace the equation number table to parent of math
						if(preg_match('/^\((\w+)\)/',$eqNum->innerHTML,$mathches)){
							$tex  = rtrim($tex,' & ');
							$tex .= ' \tag{'.$mathches[1].'} \\\\ ';
							$labelString = '<mtd>
							<mtext>('.$mathches[1].')</mtext>
							</mtd>';
							$td->innerHTML = '';
						}
						$tdClass =  $td->getAttribute('class');
						if(preg_match('/left/', $tdClass)){
							$texAlign .= 'l';
							$mathAlign .= ' left';
						}elseif (preg_match('/right/', $tdClass)){
							$texAlign .= 'r';
							$mathAlign .= ' right';
						}else {
							$texAlign .= 'l';
							$mathAlign .= 'left';
						}
						renameNode($td, 'mtd', null, true);
					}elseif(preg_match('/^((\s+)?[\(\)a-zA-Z0-9]+)/',$tdHTML)){
						$rootTableNode .= '<math alttext="\begin{align}'.rtrim($tex,' \\ ').'\end{align}">
						<mtable columnalign="'.$mathAlign.'">'.$trMathml.'</mtable>
						</math>';
						$trMathml  = '';
						$mathAlign = '';
						$texAlign  = '';
						$tex       = '';
						$rootTableNode .= '<p>'.$td->innerHTML.'</p>';
						$td->parentNode->removeChild($td);
						$mathNode = true;
					}if($trKey == ($trNode->length)-1 && $tdKey == ($tdNode->length)-1){
					    if($labelString != ''){
							$trMathml .= '<mlabeledtr>
							<mtd>
							<mtext>'.$labelString.'</mtext>
							</mtd>'.$tr->innerHTML.'</mlabeledtr>';
						}else{
							$tex .= '\notag';
							$trMathml .= '<mtr>'.$tr->innerHTML.'</mtr>';
						}
						$rootTableNode .= '<math alttext="\begin{align}'.rtrim($tex,' \\ ').'\end{align}">
						<mtable columnalign="'.$mathAlign.'">'.$trMathml.'</mtable>
						</math>';
						$trMathml  = '';
						$mathAlign = '';
						$texAlign  = '';
						$tex       = '';
						$mathNode = true;
					}
				}
				
				if($labelString != ''){
					$trMathml .= '<mlabeledtr>
					<mtd>
					<mtext>'.$labelString.'</mtext>
					</mtd>'.$tr->innerHTML.'</mlabeledtr>';
				}else{
					$tex       .= '\notag \\\\';
					$trMathml .= '<mtr>'.$tr->innerHTML.'</mtr>';
				}
			}
			if($mathNode){
				$tablePara = $doc->createElement('p');
				$tablePara->innerHTML = $rootTableNode;
				$table->parentNode->insertBefore($tablePara, $table);
			    $table->parentNode->removeChild($table);
			}
		}elseif ($tableMathNode->length == 1){
			$tableHTML = $table->innerHTML;
			$tableHTML = preg_replace('/<(\/)?(tr|td|th|tbody|thead)[^>]*>/','',$tableHTML); //Remove the table chid tags
			$table->innerHTML = $tableHTML;
			renameNode($table, 'p', null, true);
		}
	}
	// echo $doc->saveHTML();

	//save uploaded file
	$uploadedFileName = $_FILES["fileName"]["name"]; //given file name

	$pathinfo = pathinfo($uploadedFileName);

	//echo __DIR__.'/Logs/'.$pathinfo["filename"].'_cleanUp.html';

	$doc->saveHTMLFile(__DIR__.'/Logs/'.$pathinfo["filename"].'_cleanUp.html');
	file_put_contents(__DIR__.'/Logs/'.$pathinfo["filename"].'_cleanUp.log',$logString);
	file_put_contents(__DIR__.'/Logs/'.$pathinfo["filename"].'_LatexcleanUp.log',$latexLog, FILE_APPEND | LOCK_EX);
	file_put_contents(__DIR__.'/Logs/'.$pathinfo["filename"].'_asciiChars.log',$asciiCharacters);
	return  __DIR__.'/Logs/'.$pathinfo["filename"].'_cleanUp.html';
	
}
function renameNode(DOMNode $oldNode, $newName, $wrapInName = null, $stripAttr = null, $newNS = null){
	if (isset($newNS)) {
		$newNode = $oldNode->ownerDocument->createElementNS($newNS, $newName);
	}else {
		$newNode = $oldNode->ownerDocument->createElement($newName);
	}
	if (! isset($stripAttr)) {
		foreach ($oldNode->attributes as $attr) {
			$newNode->appendChild($attr->cloneNode());
		}
	}
	foreach ($oldNode->childNodes as $child) {
		$newNode->appendChild($child->cloneNode(true));
	}
	$oldNode->parentNode->replaceChild($newNode, $oldNode);
	if (isset($wrapInName)){
		$wrapNode = $newNode->ownerDocument->createElement($wrapInName);
		$newNode->parentNode->insertBefore($wrapNode, $newNode);
		$wrapNode->appendChild($newNode);
	}
	return $newNode;
}

function DOMRemove(DOMNode $from) {
	$sibling = $from->firstChild;
	if ($sibling){
		do {
			$next = $sibling->nextSibling;
			$from->parentNode->insertBefore($sibling, $from);
		} while ($sibling = $next);
	}
	$from->parentNode->removeChild($from);
}

function getPreLoadPackages($texString,$misingPackageList){
	$returnString = '';
	preg_match('/\\\usepackage(\[.*?\])?\{(.*?)\}/', $texString,$matchedPackage);
	foreach($matchedPackage as $packageList){
		$packageArray = $packageList[2].split(',');
		foreach($packageArray as $packageName){
			if(!in_array($packageName,$misingPackageList)){
				$returnString .= '--preload = tex_package/'.$packageName.'.sty';
			}
		}
	}
	return $returnString;
}
outputPostProcess($latexHtml);
?>