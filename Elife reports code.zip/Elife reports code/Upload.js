const fs = require('fs');
const AWS = require('aws-sdk');
var moment = require('moment');

const s3 = new AWS.S3({
    accessKeyId: process.env.AWS_ACCESS_KEY || "AKIAXOXT77XQPYBXCS5H",
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "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"
});
var date = moment().format("YYYY-MM-DD")
// Report 1
const fileName = 'DigestSub-article info.csv';
//var date = moment().format("YYYY-MM-DD")
const uploadFileDigest = () => {
  fs.readFile(fileName,'utf-8', (err, data) => {
     if (err) throw err;
     const params = {
         Bucket: 'prod-elife-kriya', 
         Key: 'Digest_Sub-article_Info_'+date+'.csv', 
        //  Body: JSON.stringify(data, null, 2)
         Body: data
     };
     s3.upload(params, function(s3Err, data) {
         if (s3Err) throw s3Err
         console.log(data);
         console.log(`File uploaded successfully at ${data.Location}`)
     });
  });
};
uploadFileDigest();

// Report 2
const fileName2 = 'Press Info.csv';
const uploadFilePress = () => {
  fs.readFile(fileName2,'utf-8', (err, data) => {
     if (err) throw err;
     const params = {
         Bucket: 'prod-elife-kriya', 
         Key: 'Press_Info_'+date+'.csv', 
        //  Body: JSON.stringify(data, null, 2)
         Body: data
     };
     s3.upload(params, function(s3Err, data) {
         if (s3Err) throw s3Err
         console.log(data);
         console.log(`File uploaded successfully at ${data.Location}`)
     });
  });
};
uploadFilePress();

// Report 3
const fileName3 = 'WIP_Stage_History.csv';
const uploadFileWIPHis = () => {
  fs.readFile(fileName3,'utf-8', (err, data) => {
     if (err) throw err;
     const params = {
         Bucket: 'prod-elife-kriya', 
         Key: 'WIP_Stage_History_'+date+'.csv', 
        //  Body: JSON.stringify(data, null, 2)
         Body: data
     };
     s3.upload(params, function(s3Err, data) {
         if (s3Err) throw s3Err
         console.log(data);
         console.log(`File uploaded successfully at ${data.Location}`)
     });
  });
};
uploadFileWIPHis();

// Report 4
const fileName4 = 'WIP Article summary.csv';
const uploadFileWIP = () => {
  fs.readFile(fileName4,'utf-8', (err, data) => {
     if (err) throw err;
     const params = {
         Bucket: 'prod-elife-kriya', 
         Key: 'WIP_Stage_Summary_'+date+'.csv', 
        //  Body: JSON.stringify(data, null, 2)
         Body: data
     };
     s3.upload(params, function(s3Err, data) {
         if (s3Err) throw s3Err
         console.log(data);
         console.log(`File uploaded successfully at ${data.Location}`)
     });
  });
};
uploadFileWIP();


// Report 5
const fileName5 = 'Published_Stage_History.csv';
const uploadFilePubhis = () => {
  fs.readFile(fileName5,'utf-8', (err, data) => {
     if (err) throw err;
     const params = {
         Bucket: 'prod-elife-kriya', 
         Key: 'Published_Stage_History_'+date+'.csv', 
        //  Body: JSON.stringify(data, null, 2)
         Body: data
     };
     s3.upload(params, function(s3Err, data) {
         if (s3Err) throw s3Err
         console.log(data);
         console.log(`File uploaded successfully at ${data.Location}`)
     });
  });
};
uploadFilePubhis();

// Report 6
const fileName6 = 'Published_Stage_Summary.csv';
const uploadFilePub = () => {
  fs.readFile(fileName6,'utf-8', (err, data) => {
     if (err) throw err;
     const params = {
         Bucket: 'prod-elife-kriya', 
         Key: 'Published_Stage_Summary_'+date+'.csv', 
        //  Body: JSON.stringify(data, null, 2)
         Body: data
     };
     s3.upload(params, function(s3Err, data) {
         if (s3Err) throw s3Err
         console.log(data);
         console.log(`File uploaded successfully at ${data.Location}`)
     });
  });
};
uploadFilePub();

// Download the CSV file from AWS
// const filePath = 'D:\Deepika\Projects\Elife\Elife_Reports';
// const bucketName = 'prod-elife-kriya';
// const key = 'WIP_Stage_Summary_2021-11-19.csv';
// const downloadFile = (filePath, bucketName, key) => {
//     const params = {
//       Bucket: bucketName,
//       Key: key
//     };
//     s3.getObject(params, (err, data) => {
//       if (err) console.error(err);
//       fs.writeFileSync(filePath, data.Body.toString());
//       console.log(`${filePath} has been created!`);
//     });
//   };
  
//   downloadFile(filePath, bucketName, key);
  

