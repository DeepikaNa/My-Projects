const fs = require('fs');
const AWS = require('aws-sdk');

const s3 = new AWS.S3({
    accessKeyId: process.env.AWS_ACCESS_KEY || "AKIAXOXT77XQPYBXCS5H",
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "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"
});

const fileName = 'WIP_Stage_History.csv';

const uploadFile = () => {
  fs.readFile(fileName,'utf-8', (err, data) => {
     if (err) throw err;
     const params = {
         Bucket: 'prod-elife-kriya', 
         Key: 'WIP_Stage_History_2021-11-23.csv', 
        //  Body: JSON.stringify(data, null, 2)
         Body: data
     };
     s3.upload(params, function(s3Err, data) {
         if (s3Err) throw s3Err
         console.log(data);
         console.log(`File uploaded successfully at ${data.Location}`)
     });
  });
};

uploadFile();
// const filePath = 'D:\Deepika\Projects\Elife\Elife_Reports';
// const bucketName = 'prod-elife-kriya';
// const key = 'WIP_Stage_Summary_2021-11-19.csv';
// const downloadFile = (filePath, bucketName, key) => {
//     const params = {
//       Bucket: bucketName,
//       Key: key
//     };
//     s3.getObject(params, (err, data) => {
//       if (err) console.error(err);
//       fs.writeFileSync(filePath, data.Body.toString());
//       console.log(`${filePath} has been created!`);
//     });
//   };
  
//   downloadFile(filePath, bucketName, key);
  
