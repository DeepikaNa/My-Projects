var fs = require('fs');

var libxml = require('libxmljs');      

function PMCVal(frompath,fileName,toPath){
    var xmlData = fs.readFileSync("./bmjopen-2021-053395.xml", "utf8");
    xmlData = xmlData.replace(/xlink:href/g,"xlinkhref")
       var dom = libxml.parseXml(xmlData);
       var supNodes = dom.find('//nlm:pub-date[@pub-type="epub"]');
       if(supNodes.length == 0){
        var epubDate = dom.find('//nlm:pub-date[@pub-type="epub-original"]');
       }
    //    var epubDate = xmlDoc.find('//pub-date[@pub-type="epub"]');
             if (epubDate.length > 0) {
                            var epubMonths = epubDate[0].find('.//nlm:month');
                            if (epubMonths.length > 0) {
                                var epubMonth = epubMonths[0].text();                                
                            }
                            var epubDays = epubDate[0].find('.//nlm:day');
                            if (epubDays.length > 0) {
                                var epubDay = epubDays[0].text();
                            }
                            var epubYears = epubDate[0].find('.//nlm:year');
                            if (epubYears.length > 0) {
                                var epubYear = epubYears[0].text();                                
                            }
                            if(epubDay && epubMonth && epubYear){
                                resObj[dois[i+index]]["epubdate"] = {};
                                resObj[dois[i+index]]["epubdate"] = moment().format("YYYY-MM-DD");
                            }else{
                                resObj[dois[i+index]]["epubdate"] = {};
                                resObj[dois[i+index]]["epubdate"] = "Not published";
                            }
                        }else{
                            resObj[dois[i+index]]["epubdate"] = {};
                            resObj[dois[i+index]]["epubdate"] = "Not published";
                        }                                            
                    }
    



PMCVal();