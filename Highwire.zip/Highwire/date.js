if(epubDay && epubMonth && epubYear){
    var date = epubYear+"-"+epubMonth+"-"+epubDay;
    resObj[dois[i+index]]["epubdate"] = {};
    resObj[dois[i+index]]["epubdate"] = moment(date).format("YYYY-MM-DD");
}else{
    resObj[dois[i+index]]["epubdate"] = {};
    resObj[dois[i+index]]["epubdate"] = "Not published";
}
