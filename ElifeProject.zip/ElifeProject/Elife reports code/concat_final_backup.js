var express = require('express');
var router = express.Router();
var fs = require('fs');
// var parse = require('csv-parse');
// var async = require('async');
//var csv = require("fast-csv");
var path = require('path');
// const csv = require('csv');

function deletecolumn(file,output){
  fs.createReadStream(file)
    .pipe(csv.parse({columns: true}))
    .pipe(csv.transform((input) => {
      //delete input["Waiting for Assets"];
      delete input["Feature Review"];
      delete input["Current Stage"];
      delete input["Assignee"];
      delete input["Archive"];
      delete input["Ready for Publication"];
      delete input["Validation Check"];
      delete input["Final Deliverables"];
      delete input["Times at Support"];
      delete input["Days in Support"];
      delete input["Times at Hold"];
      delete input["Days in Hold"];
      console.log(input);
      return input;
    }))
    .pipe(csv.stringify({header: true}))
    .pipe(fs.createWriteStream(output))
    .on('finish', () => {
      console.log('Done deleted');
    });
  }

function concatCSVAndOutput(csvFilePaths, outputFilePath) {
  var input1 = fs.readFileSync(csvFilePaths, "UTF-8");
  var input2 = fs.readFileSync(outputFilePath, "UTF-8");
  if(input2){
    //input2 = input2.replace(/^(.*)\n/, ''); //To remove heading
    input1 = input1.replace(/^(.*)\n/, ''); //To remove heading
    var rows = input1.split('\n');
    for(var row of rows){
      if(row && row.trim() && row.split(',').length>0){
        var reStr = '^('+row.split(',')[0]+')';
        var re = new RegExp(reStr, 'm');
        if(!re.test(input2)){
          //input2 += row+"\n";
          input2 += "\n"+row;
        }else{
          console.log("duplicate value: "+row);
        }
      }
    }
  }
  
  var output = input2;
  fs.writeFileSync("./combinedCSVFiles/"+path.basename(outputFilePath), output);
  console.log("DONE!");
}


function resolveAfter2Seconds() {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve('resolved');
    }, 2000);
  });
}
async function ConcatTemp(csvFilePaths, outputFilePath) {
  await resolveAfter2Seconds();
  var input1 = fs.readFileSync(csvFilePaths, "UTF-8");
  var input2 = fs.readFileSync(outputFilePath, "UTF-8");
  if(input2){
    input2 = input2.replace("Typesetter Check", 'Typesetter QA'); 
    input2 = input2.replace("Typesetter Review", 'Post Author Validation'); 
    // input2 = input2.replace(/^(.*)\n/, ''); //To remove heading
    input1 = input1.replace(/^(.*)\n/, ''); //To remove heading

    var rows = input1.split('\n');
    for(var row of rows){
      if(row && row.trim() && row.split(',').length>0){
        var reStr = '^('+row.split(',')[0]+')';
        var re = new RegExp(reStr, 'm');
        if(!re.test(input2)){
          //input2 += row+"\n";
          input2 += "\n"+row;
        }else{
          console.log("duplicate value: "+row);
        }
      }
    }
  }
  var output = input2;
  fs.writeFileSync("./combinedCSVFiles/"+path.basename(outputFilePath), output);
  console.log("DONE!");
}

function deletecolumnWIP(file,output){
  fs.createReadStream(file)
    .pipe(csv.parse({columns: true}))
    .pipe(csv.transform((input) => {
      //delete input["Waiting for Assets"];
      delete input["Feature Review"];
      delete input["Ready for Publication"];
      delete input["Validation Check"];
      delete input["Final Deliverables"];
      delete input["addJob"];
      console.log(input);
      return input;
    }))
    .pipe(csv.stringify({header: true}))
    .pipe(fs.createWriteStream(output))
    .on('finish', () => {
      console.log('Done deleted');
    });
  }

  // async function ConcatWIP(csvFilePaths, outputFilePath) {
  //   await resolveAfter2Seconds();
  //   var input1 = fs.readFileSync(csvFilePaths);
  //   var input2 = fs.readFileSync(outputFilePath, "UTF-8");
  //   if(input2){
  //     input2 = input2.replace("Typesetter Check", 'Typesetter QA'); 
  //     input2 = input2.replace("Typesetter Review", 'Post Author Validation'); 
  //     input2 = input2.replace("Waiting for Assets", 'Deliver digest'); 
  //     input2 = input2.replace(/^(.*)\n/, ''); //To remove heading
  //   }
  //   var output = input1+input2;
  //   fs.writeFileSync("./combinedCSVFiles/"+path.basename(outputFilePath), output);
  //   console.log("DONE!");
  // }
  
function concatK2_K1(csvFilePaths, outputFilePath) {
    var input1 = fs.readFileSync(csvFilePaths);
    var input2= fs.readFileSync(outputFilePath, "UTF-8");
    if(input2){
      //input2 = input2.replace(/^(.*)\n/, ''); //To remove heading
      input2 = input2.replace(/^(.*)/, ''); //To remove heading
    }
    var output = input1+input2;
    fs.writeFileSync("./combinedCSVFiles/"+path.basename(outputFilePath), output);
    console.log("DONE!");
  }

  function sort(csvFilePaths){
    var inputContent = fs.readFileSync(csvFilePaths, "UTF-8");
    var rows = inputContent.split('\n');
    if(rows.length > 0){
      var sortedRows = rows.filter(function(ele, i){
        if(i>0) return ele;
      });
      sortedRows.sort();
      var outputData = filterDate(sortedRows, '2017-01-01');
      fs.writeFileSync("./sortedAndFilterOutput.csv", rows[0]+"\n"+outputData);
    }
  }

  function filterDate(inputArr, date){
    var rows = inputArr.filter(function(ele, i){
      var cols = ele.split(',');
      if(cols.length > 4){
        var cleanedDate = cols[5].replace(/^(\s*)(\d{4}-\d{2}-\d{2})(\s*)$/, '$2');
        if(cleanedDate.match(/^(\s*\d{4}-\d{2}-\d{2}\s*)$/) && cleanedDate>=date) 
          return ele;
      }
    })

    var output = '';
    for(var row of rows){
      output += row+"\n";
    }
    return output;
  }

  function addColums(csvFilePaths){
    var inputContent = fs.readFileSync(csvFilePaths, "UTF-8");
    var rows = inputContent.split('\n');
    var outputData = "";
    for(var index in rows){
      if(index == 0){
        outputData += rows[index].replace(/(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)/, "$1$2$3$4$5$6col1,col2,$7")+"\n";
      }else{
        outputData += rows[index].replace(/(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)/, "$1$2$3$4$5$6,,$7")+"\n";
      }    
    }
    fs.writeFileSync(csvFilePaths, outputData);
  }
  
  addColums('/home/tamil/Desktop/sortAndFilter/WIP_Stage_History.csv');

  // concatCSVAndOutput('D:/Deepika/Projects/Elife_Reports/K1/Digest_Sub-article_Info.csv', 'D:/Deepika/Projects/Elife_Reports/K2/DigestSub-article info.csv'); 
  // concatCSVAndOutput('D:/Deepika/Projects/Elife_Reports/K1/Press_Info.csv', 'D:/Deepika/Projects/Elife_Reports/K2/Press Info.csv');
  // concatK2_K1('D:/Deepika/Projects/Elife_Reports/K2/Published Stage summary report.csv', 'D:/Deepika/Projects/Elife_Reports/K1/Published_Stage_History.csv');
  // concatK2_K1('D:/Deepika/Projects/Elife_Reports/K2/WIP Stage summary report.csv', 'D:/Deepika/Projects/Elife_Reports/K1/WIP_Stage_History.csv');
  // deletecolumn('D:/Deepika/Projects/Elife_Reports/K2/Published Article summary.csv','D:/Deepika/Projects/Elife_Reports/Temp/Published Article summary.csv');
  // ConcatTemp('D:/Deepika/Projects/Elife_Reports/Temp/Published Article summary.csv','D:/Deepika/Projects/Elife_Reports/K1/Published_Stage_Summary.csv');
  // deletecolumnWIP('D:/Deepika/Projects/Elife_Reports/K2/WIP Article summary.csv','D:/Deepika/Projects/Elife_Reports/Temp/WIP Article summary.csv');
  // ConcatTemp('D:/Deepika/Projects/Elife_Reports/K1/WIP_Stage_Summary.csv','D:/Deepika/Projects/Elife_Reports/Temp/WIP Article summary.csv');
