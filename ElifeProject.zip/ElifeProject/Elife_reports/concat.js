var express = require('express');
var router = express.Router();
var fs = require('fs');
// var parse = require('csv-parse');
// var async = require('async');
//var csv = require("fast-csv");
var path = require('path');
const csv = require('csv');

function deletecolumn(file, output) {
  fs.createReadStream(file)
    .pipe(csv.parse({ columns: true }))
    .pipe(csv.transform((input) => {
      //delete input["Waiting for Assets"];
      delete input["Feature Review"];
      delete input["Current Stage"];
      delete input["Assignee"];
      delete input["Archive"];
      delete input["Ready for Publication"];
      delete input["Validation Check"];
      delete input["Final Deliverables"];
      // delete input["Times at Support"];
      // delete input["Days in Support"];
      // delete input["Times at Hold"];
      // delete input["Days in Hold"];
      console.log(input);
      return input;
    }))
    .pipe(csv.stringify({ header: true }))
    .pipe(fs.createWriteStream(output))
    .on('finish', () => {
      console.log('Done deleted');
    });
}

function concatCSVAndOutput(csvFilePaths, outputFilePath) {
  var input1 = fs.readFileSync(csvFilePaths, "UTF-8");
  var input2 = fs.readFileSync(outputFilePath, "UTF-8");
  if (input2) {
    //input2 = input2.replace(/^(.*)\n/, ''); //To remove heading
    input1 = input1.replace(/^(.*)\n/, ''); //To remove heading
    var rows = input1.split('\n');
    for (var row of rows) {
      if (row && row.trim() && row.split(',').length > 0) {
        var reStr = '^(' + row.split(',')[0] + ')';
        var re = new RegExp(reStr, 'm');
        if (!re.test(input2)) {
          //input2 += row+"\n";
          input2 += "\n" + row;
        } else {
          console.log("duplicate value: " + row);
        }
      }
    }
  }

  var output = input2;
  fs.writeFileSync("./combinedCSVFiles/" + path.basename(outputFilePath), output);
  console.log("DONE!");
}
function resolveAfter2Seconds() {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve('resolved');
    }, 2000);
  });
}
async function ConcatTemp(csvFilePaths, outputFilePath) {
  await resolveAfter2Seconds();
  var input1 = fs.readFileSync(csvFilePaths, "UTF-8");
  var input2 = fs.readFileSync(outputFilePath, "UTF-8");
  if (input2) {
    input2 = input2.replace("Typesetter Check", 'Typesetter QA');
    input2 = input2.replace("Typesetter Review", 'Post Author Validation');
    input2 = input2.replace("Author Revision", 'Author Review');
    input2 = input2.replace("Deliver digest", 'Waiting for Assets');
    
    // input2 = input2.replace(/^(.*)\n/, ''); //To remove heading
    input1 = input1.replace(/^(.*)\n/, ''); //To remove heading

    var rows = input1.split('\n');
    for (var row of rows) {
      if (row && row.trim() && row.split(',').length > 0) {
        var reStr = '^(' + row.split(',')[0] + ')';
        var re = new RegExp(reStr, 'm');
        if (!re.test(input2)) {
          //input2 += row+"\n";
          input2 += "\n" + row;
        } else {
          console.log("duplicate value: " + row);
        }
      }
    }
  }
  var output = input2;
  fs.writeFileSync("./combinedCSVFiles/" + path.basename(outputFilePath), output);
  console.log("DONE!");
}

function deletecolumnWIP(file, output) {
  fs.createReadStream(file)
    .pipe(csv.parse({ columns: true }))
    .pipe(csv.transform((input) => {
      //delete input["Waiting for Assets"];
      delete input["Feature Review"];
      delete input["Ready for Publication"];
      delete input["Validation Check"];
      delete input["Final Deliverables"];
      delete input["addJob"];
      console.log(input);
      return input;
    }))
    .pipe(csv.stringify({ header: true }))
    .pipe(fs.createWriteStream(output))
    .on('finish', () => {
      console.log('Done deleted');
    });
}
function concatK2_K1(csvFilePaths, outputFilePath) {
  var input1 = fs.readFileSync(csvFilePaths);
  var input2 = fs.readFileSync(outputFilePath, "UTF-8");
  if (input2) {
    //input2 = input2.replace(/^(.*)\n/, ''); //To remove heading
    input2 = input2.replace(/^(.*)/, ''); //To remove heading
    input2 = input2.replace("Author Revision", 'Author Review');
    input2 = input2.replace("Deliver digest", 'Waiting for Assets');
    input2 = input2.replace(/1970-01-01, ([0-9]{4})-([0-9]{2})-([0-9]{2}), completed, ([0-9]{5})/g, '$1-$2-$3,$1-$2-$3,completed, 1');
    input2 = input2.replace(/1970-01-01, ([0-9]{4})-([0-9]{2})-([0-9]{2}), completed,([0-9]{5})/g, '$1-$2-$3,$1-$2-$3,completed, 1');
    input2 = input2.replace(/1970-01-05, ([0-9]{4})-([0-9]{2})-([0-9]{2}), completed,([0-9]{5})/g, '$1-$2-$3,$1-$2-$3,completed, 1');
  }
  var output = input1 + input2;
  fs.writeFileSync("./combinedCSVFiles/" + path.basename(outputFilePath), output);
  console.log("DONE!");
}

function addColumsK1Pub(csvFilePaths) {
  var inputContent = fs.readFileSync(csvFilePaths, "UTF-8");
  var rows = inputContent.split('\n');
  var outputData = "";
  for (var index in rows) {
    if (index == 0) {
      outputData += rows[index].replace(/(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)/, "$1$2$3$4$5Times at Support,Days in Support,Times at Hold,Days in Hold,$6$7") + "\n";
    } else {
      outputData += rows[index].replace(/(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)/, "$1$2$3$4$5,,,,$6$7") + "\n";
    }
  }
  fs.writeFileSync(csvFilePaths, outputData);
  console.log("COLUMNS ADDED !! DONE!");
}
function addColumsK1(csvFilePaths) {
  var inputContent = fs.readFileSync(csvFilePaths, "UTF-8");
  var rows = inputContent.split('\n');
  var outputData = "";
  for (var index in rows) {
    if (index == 0) {
      outputData += rows[index].replace(/(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)/, "$1$2$3$4$5$6$7Times at Support,Days in Support,Times at Hold,Days in Hold,") + "\n";
    } else {
      outputData += rows[index].replace(/(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)/, "$1$2$3$4$5$6$7,,,,") + "\n";
    }
  }
  fs.writeFileSync(csvFilePaths, outputData);
  console.log("COLUMNS ADDED !! DONE!");
}

function SwapColumsK2(csvFilePaths) {
  var inputContent = fs.readFileSync(csvFilePaths, "UTF-8");
  var rows = inputContent.split('\n');
  var outputData = "";
  for (var index in rows) {
    if (index == 0) {
      outputData += rows[index].replace(/(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)/, "$1$2$3$4$5$6$7$8$9$10$11$12$13$14$15$18$17$16") + "\n";
     } 
     else {
      outputData += rows[index].replace(/(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)(.*?,)/, "$1$2$3$4$5$6$7$8$9$10$11$12$13$14$15$18$17$16") + "\n";
    }
  }
  fs.writeFileSync(csvFilePaths, outputData);
  console.log("SWAP COLUMNS ADDED !! DONE!");
}

async function sortWIP(csvFilePaths) {
  var inputContent = fs.readFileSync(csvFilePaths, "UTF-8");
  var rows = inputContent.split('\n');
  var firstRow;
  if (rows.length > 0) {
    var sortedRows = rows.filter(function (ele, i) {
      if (i > 0) {
        return ele;
      } else {
        firstRow = ele;
      }
    });
    var sortedRows = sortedRows.sort();
    var output = firstRow + "\n";
    for (var row of sortedRows) {
      if (!/(Not found)/i.test(row)) {
        output += row + "\n";
      } else {
        var aa;
      }
    }
    fs.writeFileSync("./Sort_files/" + path.basename(csvFilePaths), output);
    console.log("SORTING DONE!");
  }
}

// concatCSVAndOutput('D:/Deepika/Projects/Elife_Reports/K1/Digest_Sub-article_Info.csv', 'D:/Deepika/Projects/Elife_Reports/K2/DigestSub-article info.csv'); 
// concatCSVAndOutput('D:/Deepika/Projects/Elife_Reports/K1/Press_Info.csv', 'D:/Deepika/Projects/Elife_Reports/K2/Press Info.csv');
// concatK2_K1('D:/Deepika/Projects/Elife_Reports/K2/Published Stage summary report.csv', 'D:/Deepika/Projects/Elife_Reports/K1/Published_Stage_History.csv');
// concatK2_K1('D:/Deepika/Projects/Elife_Reports/K2/WIP Stage summary report.csv', 'D:/Deepika/Projects/Elife_Reports/K1/WIP_Stage_History.csv');
// addColumsK1('D:/Deepika/Projects/Elife_Reports/K1/WIP_Stage_Summary.csv');
// SwapColumsK2('D:/Deepika/Projects/Elife_Reports/K2/WIP Article summary.csv');
// deletecolumnWIP('D:/Deepika/Projects/Elife_Reports/K2/WIP Article summary.csv', 'D:/Deepika/Projects/Elife_Reports/Temp/WIP Article summary.csv');
// ConcatTemp('D:/Deepika/Projects/Elife_Reports/K1/WIP_Stage_Summary.csv', 'D:/Deepika/Projects/Elife_Reports/Temp/WIP Article summary.csv');
// addColumsK1Pub('D:/Deepika/Projects/Elife_Reports/K1/Published_Stage_Summary.csv');
// SwapColumsK2('D:/Deepika/Projects/Elife_Reports/K2/Published Article summary.csv');
// deletecolumn('D:/Deepika/Projects/Elife_Reports/K2/Published Article summary.csv', 'D:/Deepika/Projects/Elife_Reports/Temp/Published Article summary.csv');
// ConcatTemp('D:/Deepika/Projects/Elife_Reports/Temp/Published Article summary.csv', 'D:/Deepika/Projects/Elife_Reports/K1/Published_Stage_Summary.csv');

// sortWIP('D:/Deepika/Projects/Elife_Reports/combinedCSVFiles/WIP_Stage_History.csv');
// sortWIP('D:/Deepika/Projects/Elife_Reports/combinedCSVFiles/Press Info.csv');
// sortWIP('D:/Deepika/Projects/Elife_Reports/combinedCSVFiles/Published_Stage_History.csv');
// sortWIP('D:/Deepika/Projects/Elife_Reports/combinedCSVFiles/DigestSub-article info.csv');
// sortWIP('D:/Deepika/Projects/Elife_Reports/combinedCSVFiles/WIP Article summary.csv');
// sortWIP('D:/Deepika/Projects/Elife_Reports/combinedCSVFiles/Published_Stage_Summary.csv');

